<?php

Class Result{

    /*
    #   Search
    */
    public static function search_result_user($name){
        $db = new Framework();

        $result = $db->pdo->prepare("SELECT nick, id FROM ".DB_PREFIX."user WHERE nick LIKE '%$name%'");
        $result->execute();

        return $result; 
    }

    public static function search_result_article($name){
        $db = new Framework();

        $result = $db->pdo->prepare("SELECT name, id FROM ".DB_PREFIX."articles WHERE name LIKE '%$name%';");
        $result->execute();

        return $result; 
    }

    public static function search_result_forum($name){
        $db = new Framework();

        $result = $db->pdo->prepare("SELECT name, id FROM ".DB_PREFIX."forum WHERE name LIKE '%$name%';");
        $result->execute();

        return $result; 
    }

    public static function search_result_news($name){
        $db = new Framework();

        $result = $db->pdo->prepare("SELECT name, id FROM ".DB_PREFIX."news WHERE name LIKE '%$name%';");
        $result->execute();

        return $result; 
    }

    /*
    #   Profile
    */
    public static function User_Profile($id){
        $db = new Framework();


        $result = $db->pdo->prepare("SELECT * FROM `".DB_PREFIX."user` WHERE id=:id OR facebook_id=:id ORDER BY id DESC LIMIT 0,1");
        $result->bindParam(":id", $id);
        $result->execute();

        return $result;   
    }

    /*
    #   Comment
    */
    public static function See_All_Comment($type, $get){
        $db = new Framework();

        $answer = 0;
        $result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."comment WHERE type=:type AND gets=:get AND answer=:answer ORDER BY id ASC;");
        $result->bindParam(":type", $type);
        $result->bindParam(":get", $get);
        $result->bindParam(":answer", $answer);  
        $result->execute();

        return $result;   
    }

    public static function Comment_Count($type, $get){
        $db = new Framework();

        $result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."comment WHERE type=:type AND gets=:get ORDER BY id ASC;");
        $result->bindParam(":type", $type);
        $result->bindParam(":get", $get);
        $result->execute();

        return $result;   
    }

    public static function  Comment_answer($answer, $type, $get){
        $db = new Framework();

        $result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."comment WHERE type=:type AND gets=:get AND answer=:answer ORDER BY id ASC;");
        $result->bindParam(":type", $type);
        $result->bindParam(":get", $get);
        $result->bindParam(":answer", $answer);         
        $result->execute();

        return $result;   
    }


    public static function Delete_Comment($id, $type, $get){
        $db = new Framework();

        $result = $db->pdo->prepare("DELETE FROM ".DB_PREFIX."comment WHERE id=:id AND gets=:get AND type=:type;");
        $result->bindParam(":type", $type);
        $result->bindParam(":get", $get);
        $result->bindParam(":id", $id);         
        $result->execute();

        return $result;    
    }

    public static function Delete_Answer_Comment($id, $type, $get){
        $db = new Framework();

        $result = $db->pdo->prepare("DELETE FROM ".DB_PREFIX."comment WHERE answer=:id AND gets=:get AND type=:type;");
        $result->bindParam(":type", $type);
        $result->bindParam(":get", $get);
        $result->bindParam(":id", $id);         
        $result->execute();

        return $result;    
    }

    /*
    #   Tagwall
    */
    public static function See_All_Tagwall($type, $get){
        $db = new Framework();

        $answer = 0;
        $result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."tagwall WHERE gets=:get AND answer=:answer ORDER BY id DESC;");
        $result->bindParam(":get", $get);
        $result->bindParam(":answer", $answer);  
        $result->execute();

        return $result;   
    }

    public static function Tagwall_Count($type, $get){
        $db = new Framework();

        $result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."tagwall WHERE gets=:get ORDER BY id ASC;");
        $result->bindParam(":get", $get);
        $result->execute();

        return $result;   
    }

    public static function Tagwall_answer($answer, $type, $get){
        $db = new Framework();

        $result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."tagwall WHERE gets=:get AND answer=:answer ORDER BY id ASC;");
        $result->bindParam(":get", $get);
        $result->bindParam(":answer", $answer);         
        $result->execute();

        return $result;   
    }

    public static function Delete_Tagwall($id, $type, $get){
        $db = new Framework();

        $result = $db->pdo->prepare("DELETE FROM ".DB_PREFIX."tagwall WHERE id=:id AND gets=:get;");
        $result->bindParam(":get", $get);
        $result->bindParam(":id", $id);         
        $result->execute();

        return $result;    
    }

    public static function Delete_Answer_Tagwall($id, $type, $get){
        $db = new Framework();

        $result = $db->pdo->prepare("DELETE FROM ".DB_PREFIX."tagwall WHERE answer=:id AND gets=:get;");
        $result->bindParam(":get", $get);
        $result->bindParam(":id", $id);         
        $result->execute();

        return $result;    
    }

    /*
    #   Articles
    */
	public static function Home_Articles(){
		$db = new Framework();

        $home_perPage = ARTICLES_HOME_PERPAGE;
		$result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."articles ORDER BY id DESC LIMIT 0, $home_perPage;");
        $result->execute();

        return $result;
	}

	public static function Articles_Topic(){
		$url = new simpleurl("");
        $page = $url->segment(3) ? (int) $url->segment(3) : 1;
        $perPage = ARTICLES_PAGE_PERPAGE;
        $start = ($page > 1) ? ($page * $perPage) - $perPage : 0;

        $db = new Framework();
        
        $result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."articles ORDER BY id DESC LIMIT $start, $perPage;");
        $result->execute();

        return $result;
	}

    public static function Articles_Category($cat){
        $db = new Framework();

        $result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."articles_category WHERE id=:id;");
        $result->bindParam(":id", $cat);
        $result->execute();

        return $result;
    }

	public static function Articles_Thead($id){
		$db = new Framework();

		$result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."articles WHERE id=:id ORDER BY id DESC LIMIT 0,1");
		$result->bindParam(":id" ,$id);
        $result->execute();

        return $result;
	}

	public static function Articles_pagination(){
		$url = new simpleurl("");
		$db = new Framework();

        $page = $url->segment(3) ? (int) $url->segment(3) : 1;
        $perPage = 6;
        $start = ($page > 1) ? ($page * $perPage) - $perPage : 0;

        $total = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."articles");
        $total->execute();

        if($total->rowCount() == Null){
            $total2 = 1;
        } else{
            $total2 = $total->rowCount();
        }
        
        $pages = ceil($total2 / $perPage);

        echo "   <div class='col-lg-12 text-center' id='pagination'>";
        echo "    <nav>";
        echo "     <ul class='pagination'>";

        if($page >1){
            $matematic = $page - 1;
            
            echo "     <li>";
            echo "      <a href='".WEB."/article/page/".$matematic."#pagination' aria-label='Previous'>";
            echo "       <span aria-hidden='true'>&laquo;</span>";
            echo "      </a>";
            echo "     </li>";
        }

        for($i = 1;$i <= $pages;$i++){
            if($page == $i){
                echo "     <li class='active'>";
                echo "      <a href='".WEB."/article/page/".$i."#pagination'>".$i."</a>";
                echo "     </li>";
            }else{
                echo "     <li>";
                echo "      <a href='".WEB."/article/page/".$i."#pagination'>".$i."</a>";
                echo "     </li>";
            }
        }

        if($page < $pages){
            $matematic = $page + 1;
            
            echo "     <li>";
            echo "      <a href='".WEB."/article/page/".$matematic."#pagination' aria-label='Next'>";
            echo "       <span aria-hidden='true'>&raquo;</span>";
            echo "      </a>";
            echo "     </li>";
        }

        echo "     </ul>";
        echo "    </nav>";
        echo "   </div>";

        //SQL Injection
        if($page > $pages){
            header::location(WEB."/article/page/".$pages);
        }
	}

    /*
    #   News
    */
    public static function Home_News(){
        $db = new Framework();

        $home_perPage = ARTICLES_HOME_PERPAGE;
        $result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."news ORDER BY id DESC LIMIT 0, $home_perPage");
        $result->execute();

        return $result;
    }

    public static function News_Topic(){
        $url = new simpleurl("");
        $page = $url->segment(3) ? (int) $url->segment(3) : 1;
        $perPage = 10;
        $start = ($page > 1) ? ($page * $perPage) - $perPage : 0;

        $db = new Framework();
        
        $result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."news ORDER BY id DESC LIMIT $start, $perPage");
        $result->execute();

        return $result;
    }

    public static function News_Category($cat){
        $db = new Framework();

        $result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."news_category WHERE id=:id");
        $result->bindParam(":id", $cat);
        $result->execute();

        return $result;
    }

    public static function News_Thead($id){
        $db = new Framework();

        $result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."news WHERE id=:id ORDER BY id DESC LIMIT 0,1");
        $result->bindParam(":id" ,$id);
        $result->execute();

        return $result;
    }

    public static function News_pagination(){
        $url = new simpleurl("");
        $db = new Framework();

        $page = $url->segment(3) ? (int) $url->segment(3) : 1;
        $perPage = 6;
        $start = ($page > 1) ? ($page * $perPage) - $perPage : 0;

        $total = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."news");
        $total->execute();

        if($total->rowCount() == Null){
            $total2 = 1;
        } else{
            $total2 = $total->rowCount();
        }
        
        $pages = ceil($total2 / $perPage);

        echo "   <div class='col-lg-12 text-center' id='pagination'>";
        echo "    <nav>";
        echo "     <ul class='pagination'>";

        if($page >1){
            $matematic = $page - 1;
            
            echo "     <li>";
            echo "      <a href='".WEB."/article/page/".$matematic."#pagination' aria-label='Previous'>";
            echo "       <span aria-hidden='true'>&laquo;</span>";
            echo "      </a>";
            echo "     </li>";
        }

        for($i = 1;$i <= $pages;$i++){
            if($page == $i){
                echo "     <li class='active'>";
                echo "      <a href='".WEB."/article/page/".$i."#pagination'>".$i."</a>";
                echo "     </li>";
            }else{
                echo "     <li>";
                echo "      <a href='".WEB."/article/page/".$i."#pagination'>".$i."</a>";
                echo "     </li>";
            }
        }

        if($page < $pages){
            $matematic = $page + 1;
            
            echo "     <li>";
            echo "      <a href='".WEB."/article/page/".$matematic."#pagination' aria-label='Next'>";
            echo "       <span aria-hidden='true'>&raquo;</span>";
            echo "      </a>";
            echo "     </li>";
        }

        echo "     </ul>";
        echo "    </nav>";
        echo "   </div>";

        //SQL Injection
        if($page > $pages){
            header::location(WEB."/article/page/".$pages);
        }
    }

    /*
    #   Eshop
    */
    public static function Product_Result_cat($cat){
        $url = new simpleurl("");
        $page = $url->segment(6) ? (int) $url->segment(6) : 1;
        $perPage = ARTICLES_PAGE_PERPAGE;
        $start = ($page > 1) ? ($page * $perPage) - $perPage : 0;

        $db = new Framework();
        
        $result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."product WHERE category=:cat ORDER BY id DESC LIMIT $start, $perPage");
        $result->bindParam(":cat", $cat);
        $result->execute();

        return $result;
    }


    public static function Product_Result(){
        $url = new simpleurl("");
        $page = $url->segment(3) ? (int) $url->segment(3) : 1;
        $perPage = ARTICLES_PAGE_PERPAGE;
        $start = ($page > 1) ? ($page * $perPage) - $perPage : 0;

        $db = new Framework();
        
        $result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."product ORDER BY id DESC LIMIT $start, $perPage");
        $result->execute();

        return $result;
    }


    public static function Product_Thead($id){
        $db = new Framework();

        $result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."product WHERE id=:id ORDER BY id DESC LIMIT 0,1");
        $result->bindParam(":id" ,$id);
        $result->execute();

        return $result;
    }

    public static function Product_pagination_cat($cat){
        $url = new simpleurl("");
        $db = new Framework();

        $page = $url->segment(6) ? (int) $url->segment(6) : 1;
        $perPage = ARTICLES_PAGE_PERPAGE;
        $start = ($page > 1) ? ($page * $perPage) - $perPage : 0;

        $total = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."product WHERE category=:cat");
        $total->bindParam(":cat", $cat);
        $total->execute();
        
        if($total->rowCount() == Null){
            $total2 = 1;
        } else{
            $total2 = $total->rowCount();
        }
                
        $pages = ceil($total2 / $perPage);

        echo "   <div class='col-lg-12 text-center' id='pagination'>";
        echo "    <nav>";
        echo "     <ul class='pagination'>";

        if($page >1){
            $matematic = $page - 1;
            
            echo "     <li>";
            echo "      <a href='".WEB."/app/shop/cat/".$cat."/page/".$matematic."#pagination' aria-label='Previous'>";
            echo "       <span aria-hidden='true'>&laquo;</span>";
            echo "      </a>";
            echo "     </li>";
        }

        for($i = 1;$i <= $pages;$i++){
            if($page == $i){
                echo "     <li class='active'>";
                echo "      <a href='".WEB."/app/shop/cat/".$cat."/page/".$i."#pagination'>".$i."</a>";
                echo "     </li>";
            }else{
                echo "     <li>";
                echo "      <a href='".WEB."/app/shop/cat/".$cat."/page/".$i."#pagination'>".$i."</a>";
                echo "     </li>";
            }
        }

        if($page < $pages){
            $matematic = $page + 1;
            
            echo "     <li>";
            echo "      <a href='".WEB."/app/shop/cat/".$cat."/page/".$matematic."#pagination' aria-label='Next'>";
            echo "       <span aria-hidden='true'>&raquo;</span>";
            echo "      </a>";
            echo "     </li>";
        }

        echo "     </ul>";
        echo "    </nav>";
        echo "   </div>";

        //SQL Injection
        if($page > $pages){
            header::location(WEB."/app/shop/cat/".$cat."/page/".$pages);
        }
    }

    public static function Product_pagination(){
        $url = new simpleurl("");
        $db = new Framework();

        $page = $url->segment(4) ? (int) $url->segment(4) : 1;
        $perPage = ARTICLES_PAGE_PERPAGE;
        $start = ($page > 1) ? ($page * $perPage) - $perPage : 0;

        $total = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."product");
        $total->execute();
        
        if($total->rowCount() == Null){
            $total2 = 1;
        } else{
            $total2 = $total->rowCount();
        }
                
        $pages = ceil($total2 / $perPage);

echo "   <div class='row'>";
        echo "   <div class='col-lg-12 text-center' id='pagination'>";
        echo "    <nav>";
        echo "     <ul class='pagination'>";

        if($page >1){
            $matematic = $page - 1;
            
            echo "     <li>";
            echo "      <a href='".WEB."/app/shop/page/".$matematic."#pagination' aria-label='Previous'>";
            echo "       <span aria-hidden='true'>&laquo;</span>";
            echo "      </a>";
            echo "     </li>";
        }

        for($i = 1;$i <= $pages;$i++){
            if($page == $i){
                echo "     <li class='active'>";
                echo "      <a href='".WEB."/app/shop/page/".$i."#pagination'>".$i."</a>";
                echo "     </li>";
            }else{
                echo "     <li>";
                echo "      <a href='".WEB."/app/shop/page/".$i."#pagination'>".$i."</a>";
                echo "     </li>";
            }
        }

        if($page < $pages){
            $matematic = $page + 1;
            
            echo "     <li>";
            echo "      <a href='".WEB."/app/shop/page/".$matematic."#pagination' aria-label='Next'>";
            echo "       <span aria-hidden='true'>&raquo;</span>";
            echo "      </a>";
            echo "     </li>";
        }

        echo "     </ul>";
        echo "    </nav>";
        echo "   </div>";
        echo "   </div>";

        //SQL Injection
        if($page > $pages){
            header::location(WEB."/app/shop/page/".$pages);
        }
    }

    /*
    #   Forum
    */
	public static function Forum_Topics(){
		$db = new Framework();

		$result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."forum ORDER BY id DESC");
        $result->execute();

        return $result;	
	}


	public static function Forum_Thead($id){
		$db = new Framework();

		$result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."forum WHERE id=:id ORDER BY id DESC LIMIT 1");
		$result->bindParam(":id" ,$id);
        $result->execute();

        return $result;	
	}

    /*
    #   Downloads
    */
	public static function Downloads_Result(){
		$db = new Framework();

		$result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."downloads ORDER BY id DESC");
        $result->execute();

        return $result;		
	}


	public static function Downloads_Thead($id){
		$db = new Framework();

		$result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."downloads WHERE id=:id ORDER BY id DESC LIMIT 1");
		$result->bindParam(":id" ,$id);
        $result->execute();

        return $result;	
	}

    /*
    #   Forum cat pagination
    */
    public static function Forum_pagination_Result($ids){
        $url = new simpleurl("");
        $page = $url->segment(4) ? (int) $url->segment(4) : 1;
        $perPage = 10;
        $start = ($page > 1) ? ($page * $perPage) - $perPage : 0;

        $db = new Framework();
        
        $result = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."forum ORDER BY id DESC LIMIT $start, $perPage");
        $result->bindParam(":cat", $ids);
        $result->execute();

        return $result;
    }


    /*
    # Forum pagination
    */
    public static function Forum_cat_pagination($ids){
        $url = new simpleurl("");
        $db = new Framework();


        $page = $url->segment(4) ? (int) $url->segment(4) : 1;
        $perPage = 10;
        $start = ($page > 1) ? ($page * $perPage) - $perPage : 0;

        $total = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."forum");
        $total->bindParam(":cat", $ids);
        $total->execute();
        
        if($total->rowCount() == Null){
            $total2 = 1;
        } else{
            $total2 = $total->rowCount();
        }
                
        $pages = ceil($total2 / $perPage);

        echo "   <div class='col-lg-12 text-center' id='pagination'>";
        echo "    <nav>";
        echo "     <ul class='pagination'>";

        if($page >1){
            $matematic = $page - 1;
            
            echo "     <li>";
            echo "      <a href='".WEB."/forum/view/".$ids."/".$matematic."#pagination' aria-label='Previous'>";
            echo "       <span aria-hidden='true'>&laquo;</span>";
            echo "      </a>";
            echo "     </li>";
        }

        for($i = 1;$i <= $pages;$i++){
            if($page == $i){
                echo "     <li class='active'>";
                echo "      <a href='".WEB."/forum/view/".$ids."/".$i."#pagination'>".$i."</a>";
                echo "     </li>";
            }else{
                echo "     <li>";
                echo "      <a href='".WEB."/forum/view/".$ids."/".$i."#pagination'>".$i."</a>";
                echo "     </li>";
            }
        }

        if($page < $pages){
            $matematic = $page + 1;
            
            echo "     <li>";
            echo "      <a href='".WEB."/forum/view/".$ids."/".$matematic."#pagination' aria-label='Next'>";
            echo "       <span aria-hidden='true'>&raquo;</span>";
            echo "      </a>";
            echo "     </li>";
        }

        echo "     </ul>";
        echo "    </nav>";
        echo "   </div>";

        //SQL Injection
        if($page > $pages){
            header::location(WEB."/forum/view/".$ids."/".$pages);
        }
    }
}