<?php

Class Template{


	/*
	# HEAD META TAG TEMPLATE
	*/
	public static function head_tag(){
        //Loading presenter
		Presenter::loading_presenter("Template");

		//Loading newer update xeipo rs system
		Framework::update_framework_version();
	}

	/*
	#	Footer static end
	*/
	public static function footer(){

	?><noscript id="deferred-styles"><?




		echo "<style>";

		    $url = ROOT."/www/media/css/bootstrap.min.css";
		    $css = file_get_contents($url);
		    $buffer = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $css);
		    $buffer = str_replace(': ', ':', $buffer);
		    $buffer = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $buffer);
		    echo $buffer;

		    $url = ROOT."/www/templates/default/css/styles.min.css";
		    $css = file_get_contents($url);
		    $buffer = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $css);
		    $buffer = str_replace(': ', ':', $buffer);
		    $buffer = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $buffer);
		    echo $buffer;

		echo "</style>";
		

    ?></noscript><?
    ?><script>var loadDeferredStyles=function(){var e=document.getElementById("deferred-styles"),t=document.createElement("div");t.innerHTML=e.textContent,document.body.appendChild(t),e.parentElement.removeChild(e)},raf=requestAnimationFrame||mozRequestAnimationFrame||webkitRequestAnimationFrame||msRequestAnimationFrame;raf?raf(function(){window.setTimeout(loadDeferredStyles,0)}):window.addEventListener("load",loadDeferredStyles);</script><?










		echo "<script>";   

		    $url = ROOT."/www/media/js/jquery-v1.12.4.min.js";
		    $css = file_get_contents($url);
		    $buffer = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $css);
		    $buffer = str_replace(': ', ':', $buffer);
		    $buffer = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $buffer);
		    echo $buffer;
		
		echo "</script>";   
		echo "<script>";   

		    $url = ROOT."/www/media/js/bootstrap.min.js";
		    $css = file_get_contents($url);
		    $buffer = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $css);
		    $buffer = str_replace(': ', ':', $buffer);
		    $buffer = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $buffer);
		    echo $buffer;

		echo "</script>";   
		

      	$user = new User();
      	if($user->isLoggedIn()){
	      	echo '<script>function count(){$("#user-online").load("'.WEB.'/ajax/user-online.php");}var auto_refresh = setInterval(count, 5000);count();</script>';
			echo "<div id='user-online'></div>";
		}










		session_write_close();

		return false;
		exit();
	}

	/*
	#	Check left panel
	*/
	public static function Left_panel_check(){
		$db = new Framework();
		
		$enbl = 1;
		$content = 1;
		$lol = 0;

		//Database connect
		$query = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."panel WHERE content=:content AND enabled=:enabled ORDER BY numer ASC");
		$query->bindParam(":content", $content);
		$query->bindParam(":enabled", $enbl);
		$query->execute();

		if($query->rowCount() > 0){ 
			for($i=0;$row=$query->fetch();$i++){ 
				if($row["active"] == 1){
					
						$urls = new simpleurl("home");

						$pole = explode(",", $row["enabled_panel"]);

						foreach ($pole as $cast) {
							if($row["sub_enabled"] == 0){
								if($cast == "all" OR $cast == "/all"){
									$lol ++;
								}else if($urls->segment(1) == $cast AND $urls->segment(2) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2) == $cast AND $urls->segment(3) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3) == $cast AND $urls->segment(4) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4) == $cast AND $urls->segment(5) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4)."/".$urls->segment(5) == $cast AND $urls->segment(6) == NULL){
									$lol ++;
								}else{
									$lol = 0;
								}
							}else{
								if($cast == "all" OR $cast == "/all"){
									$lol ++;
								}else if($urls->segment(1) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4)."/".$urls->segment(5) == $cast){
									$lol ++;
								}else{
									$lol = 0;
								}
							}
						}

						if($lol > 0){
							$pole = explode(",", $row["enabled_panel"]);
							$path = ROOT.DS.'www'.DS.'aps'.DS.$row["name_panel"].DS."panel.php";
							if(file_exists($path)){
								return true;
							}else if($row["content2"] !== NULL){
								return true;
							}
						}
				}
			}
		}else{
			return false;
		}	
	}


	/*
	#	Content Left Panel
	*/
	public static function Left_panel(){
		$db = new Framework();
		
		$enbl = 1;
		$content = 1;
		$lol = 0;

		//Database connect
		$query = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."panel WHERE content=:content AND enabled=:enabled ORDER BY numer ASC");
		$query->bindParam(":content", $content);
		$query->bindParam(":enabled", $enbl);
		$query->execute();

		if($query->rowCount() > 0){ 
			for($i=0;$row=$query->fetch();$i++){ 
				if($row["active"] == 1){
						$urls = new simpleurl("home");

						$pole = explode(",", $row["enabled_panel"]);

						foreach ($pole as $cast) {
							if($row["sub_enabled"] == 0){
								if($cast == "all" OR $cast == "/all"){
									$lol ++;
								}else if($urls->segment(1) == $cast AND $urls->segment(2) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2) == $cast AND $urls->segment(3) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3) == $cast AND $urls->segment(4) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4) == $cast AND $urls->segment(5) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4)."/".$urls->segment(5) == $cast AND $urls->segment(6) == NULL){
									$lol ++;
								}else{
									$lol = 0;
								}
							}else{
								if($cast == "all" OR $cast == "/all"){
									$lol ++;
								}else if($urls->segment(1) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4)."/".$urls->segment(5) == $cast){
									$lol ++;
								}else{
									$lol = 0;
								}
							}
						}

						if($lol > 0){
							$pole = explode(",", $row["enabled_panel"]);
							$path = ROOT.DS.'www'.DS.'aps'.DS.$row["name_panel"].DS."panel.php";
							if(file_exists($path)){
								include_once($path);
							}else if($row["content2"] !== NULL){
								
								echo eval("?>".$row["content2"]."<?");
								Bootstrap::close_table();
							}
						}

				}
			}
		}	
	}

	/*
	#	Content Bottom panel
	*/
	public static function Center_Bottom_panel(){
		$db = new Framework();
		
		$enbl = 1;
		$content = 3;
		$lol = 0;

		//Database connect
		$query = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."panel WHERE content=:content AND enabled=:enabled ORDER BY numer ASC");
		$query->bindParam(":content", $content);
		$query->bindParam(":enabled", $enbl);
		$query->execute();

		if($query->rowCount() > 0){ 
			for($i=0;$row=$query->fetch();$i++){ 
				if($row["active"] == 1){
					
						$urls = new simpleurl("home");

						$pole = explode(",", $row["enabled_panel"]);


						//Povolené
						foreach ($pole as $cast) {
							if($row["sub_enabled"] == 0){
								if($cast == "all" OR $cast == "/all"){
									$lol ++;
								}else if($urls->segment(1) == $cast AND $urls->segment(2) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2) == $cast AND $urls->segment(3) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3) == $cast AND $urls->segment(4) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4) == $cast AND $urls->segment(5) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4)."/".$urls->segment(5) == $cast AND $urls->segment(6) == NULL){
									$lol ++;
								}else{
									$lol = 0;
								}
							}else{
								if($cast == "all" OR $cast == "/all"){
									$lol ++;
								}else if($urls->segment(1) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4)."/".$urls->segment(5) == $cast){
									$lol ++;
								}else{
									$lol = 0;
								}
							}
						}		


						if($lol > 0){
							$pole = explode(",", $row["enabled_panel"]);
							$path = ROOT.DS.'www'.DS.'aps'.DS.$row["name_panel"].DS."panel.php";
							if(file_exists($path)){
								include_once($path);
							}else if($row["content2"] !== NULL){
								
								echo eval("?>".$row["content2"]."<?");
								
							}
						}



				}
			}
		}	
	}
	/*
	#	Content Top panel
	*/
	public static function Center_Top_panel(){
		$db = new Framework();
		
		$enbl = 1;
		$content = 2;
		$lol = 0;

		//Database connect
		$query = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."panel WHERE content=:content AND enabled=:enabled ORDER BY numer ASC");
		$query->bindParam(":content", $content);
		$query->bindParam(":enabled", $enbl);
		$query->execute();

		if($query->rowCount() > 0){ 
			for($i=0;$row=$query->fetch();$i++){ 
				if($row["active"] == 1){



						$urls = new simpleurl("home");

						$pole = explode(",", $row["enabled_panel"]);

						foreach ($pole as $cast) {
							if($row["sub_enabled"] == 0){
								if($cast == "all" OR $cast == "/all"){
									$lol ++;
								}else if($urls->segment(1) == $cast AND $urls->segment(2) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2) == $cast AND $urls->segment(3) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3) == $cast AND $urls->segment(4) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4) == $cast AND $urls->segment(5) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4)."/".$urls->segment(5) == $cast AND $urls->segment(6) == NULL){
									$lol ++;
								}else{
									$lol = 0;
								}
							}else{
								if($cast == "all" OR $cast == "/all"){
									$lol ++;
								}else if($urls->segment(1) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4)."/".$urls->segment(5) == $cast){
									$lol ++;
								}else{
									$lol = 0;
								}
							}
						}

						if($lol > 0){
							$pole = explode(",", $row["enabled_panel"]);
							$path = ROOT.DS.'www'.DS.'aps'.DS.$row["name_panel"].DS."panel.php";
							if(file_exists($path)){
								include_once($path);
							}else if($row["content2"] !== NULL){
								echo eval("?>".$row["content2"]."<?");
							}
						}


				}
			}
		}
	}


	/*
	#	Content Right Panel
	*/
	public static function Right_panel(){
		$db = new Framework();
		
		$enbl = 1;
		$content = 4;
		$lol = 0;

		//Database connect
		$query = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."panel WHERE content=:content AND enabled=:enabled ORDER BY numer ASC");
		$query->bindParam(":content", $content);
		$query->bindParam(":enabled", $enbl);
		$query->execute();

		if($query->rowCount() > 0){ 
			for($i=0;$row=$query->fetch();$i++){ 
				if($row["active"] == 1){
					
						$urls = new simpleurl("home");

						$pole = explode(",", $row["enabled_panel"]);

						foreach ($pole as $cast) {
							if($row["sub_enabled"] == 0){
								if($cast == "all" OR $cast == "/all"){
									$lol ++;
								}else if($urls->segment(1) == $cast AND $urls->segment(2) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2) == $cast AND $urls->segment(3) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3) == $cast AND $urls->segment(4) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4) == $cast AND $urls->segment(5) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4)."/".$urls->segment(5) == $cast AND $urls->segment(6) == NULL){
									$lol ++;
								}else{
									$lol = 0;
								}
							}else{
								if($cast == "all" OR $cast == "/all"){
									$lol ++;
								}else if($urls->segment(1) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4)."/".$urls->segment(5) == $cast){
									$lol ++;
								}else{
									$lol = 0;
								}
							}
						}


						if($lol > 0){
							$pole = explode(",", $row["enabled_panel"]);
							$path = ROOT.DS.'www'.DS.'aps'.DS.$row["name_panel"].DS."panel.php";
							if(file_exists($path)){
								include_once($path);
							}else if($row["content2"] !== NULL){
								echo eval("?>".$row["content2"]."<?");
							}
						}
				}
			}
		}
	}

	/*
	#	Check left panel
	*/
	public static function Right_panel_check(){
		$db = new Framework();
		
		$enbl = 1;
		$content = 4;
		$lol = 0;

		//Database connect
		$query = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."panel WHERE content=:content AND enabled=:enabled ORDER BY numer ASC");
		$query->bindParam(":content", $content);
		$query->bindParam(":enabled", $enbl);
		$query->execute();

		if($query->rowCount() > 0){ 
			for($i=0;$row=$query->fetch();$i++){ 
				if($row["active"] == 1){
					
						$urls = new simpleurl("home");

						$pole = explode(",", $row["enabled_panel"]);

						foreach ($pole as $cast) {
							if($row["sub_enabled"] == 0){
								if($cast == "all" OR $cast == "/all"){
									$lol ++;
								}else if($urls->segment(1) == $cast AND $urls->segment(2) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2) == $cast AND $urls->segment(3) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3) == $cast AND $urls->segment(4) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4) == $cast AND $urls->segment(5) == NULL){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4)."/".$urls->segment(5) == $cast AND $urls->segment(6) == NULL){
									$lol ++;
								}else{
									$lol = 0;
								}
							}else{
								if($cast == "all" OR $cast == "/all"){
									$lol ++;
								}else if($urls->segment(1) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4) == $cast){
									$lol ++;
								}else if($urls->segment(1)."/".$urls->segment(2)."/".$urls->segment(3)."/".$urls->segment(4)."/".$urls->segment(5) == $cast){
									$lol ++;
								}else{
									$lol = 0;
								}
							}
						}


						if($lol > 0){
							$pole = explode(",", $row["enabled_panel"]);
							$path = ROOT.DS.'www'.DS.'aps'.DS.$row["name_panel"].DS."panel.php";
							if(file_exists($path)){
								return true;
							}else if($row["content2"] !== NULL){
								return true;
							}
						}
				}
			}
		}else{
			return false;
		}	
	}

	/*
	#	Minifer folder
	*/
	public static function minifer($text){
	    $buffer = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $text);
	    $buffer = str_replace(': ', ':', $buffer);
	    $buffer = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $buffer);

	    return $buffer;
	}

}