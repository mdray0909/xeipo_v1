<?php

Class update{

  public static function new_version(){
    $feed = new DOMDocument();
        $feed->load('http://plugins.xeipo.com/version.xml');
        $items = $feed->getElementsByTagName('channel')->item(0)->getElementsByTagName('item');

        foreach($items as $key => $item) 
        {
            $version = $item->getElementsByTagName('version')->item(0)->firstChild->nodeValue;
        }

        return $version;
  }

  public static function update_line(){
    echo '<style>
        .navbar-update-inverse{
          border: 0px;
          background: #3f51b5;
          box-sizing: border-box;
          color: #fff;
          font-family: "RobotoDraft","Roboto",sans-serif;
          font-size: 16px;
          text-rendering: optimizelegibility;
          transition-delay: 0s;
          transition-duration: 0.2s;
          border-radius: 0px;
          height: 65px;
          width:100%;
          z-index:5;
          position:fixed;
        }

        /* NAV RIGHT */
        .navright2 > li > a:focus, .navright2 > li > a:hover{
          background: #27359A;
          text-decoration: none;
          font-weight: 400;
          color:#fff;
        }

        .navbar-inverse .navbar-nav2> li > a, .navbar-inverse .navbar-text{
          color:#fff;  
        }

        .navright2 > li, .navright2 > li > a {
          font-size: 14px;
          display: block;
          position: relative;
          text-decoration: none;
          font-weight: 400;
          color:#fff;
        }

        .navright2 > li > a {
            padding: 22px 15px;
        }

        .navbar-brand-update {
            float: left;
            height: 65px;
            padding: 23px 50px;
            font-size: 18px;
            line-height: 20px;
        }

        .navbar2{
            border-radius:0px;
        }
        </style>

        <div class="alert alert-update fade in navbar2 navbar-update-inverse hidden-xs" role="alert" style="padding:0px;margin:0px;margin-bottom: 0px;z-index: 5;position:fixed;">
            <div class="container-fluid">
              <div class="navbar-header2">
                <div class="navbar-brand-update" href="#">Update your system to the new version</div>
              </div>
              <div style="margin-right: 50px;">
                <ul class="navright2 navbar-nav2 navbar-right">
                    <li>
                        <a href="//xeipo.com/">Update</a>
                    </li>  
                    <li style="margin-top:-45px;margin-right: -30px;">
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </li> 
                </ul>
              </div>
            </div>
        </div>';
    }
}