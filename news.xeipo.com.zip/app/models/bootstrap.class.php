<?php

Class Bootstrap{

	public static function open_table($name = NULL){
		echo "<div class='panel panel-default'>";
		echo "<div class='panel-heading'>".$name."</div>";
		echo "<div class='panel-body'>";

		return false;
	}

	public static function close_table(){
		echo "</div>";
		echo "</div>";

		return false;
	}

	public static function Alert($massage, $type = "warning"){
		echo "<br><div class='alert alert-".$type." alert-dismissible fade in' role='alert'>";
		echo "<button type='button' class='close' data-dismiss='alert' aria-label='Close'>";
		echo "<span aria-hidden='true'>×</span></button>";
		echo $massage;
		echo "</div>";

		return false;
	}

	public static function Alert2($massage, $type = "warning"){
		echo "<div class='alert alert-".$type." alert-dismissible fade in' role='alert'>";
		echo "<button type='button' class='close' data-dismiss='alert' aria-label='Close'>";
		echo "<span aria-hidden='true'>×</span></button>";
		echo $massage;
		echo "</div>";

		return false;
	}
}