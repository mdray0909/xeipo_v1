<?php

/**
**********************************************************
* Xeipo FREE VERSION CMS 
* @version FREE CMS BETA
* @author Jozef Vajdiar
* @copyright Copyright (C) 2015 - 2016 
**********************************************************
* Tento program je slobodný softvér: môžete ho šíriť a upravovať podľa ustanovení Všeobecnej verejnej 
* licencie GNU (GNU General Public Licence), vydávanej nadáciou Free Software Foundation a to podľa 3. verzie tejto Licencie
* Tento program je rozširovaný v nádeji, že bude užitočný, avšak BEZ AKEJKOĽVEK ZÁRUKY. 
* Neposkytujú sa ani odvodené záruky PREDAJNOSTI alebo VHODNOSTI PRE URČITÝ ÚČEL. 
* Ďalšie podrobnosti hľadajte vo Všeobecnej verejnej licencii GNU.
**********************************************************
* Kópiu Všeobecnej verejnej licencie GNU ste mali dostať spolu s týmto programom. (license.txt)
* Ak sa tak nestalo, nájdete ju tu: <http://www.gnu.org/licenses/>
* Tento system nájdete ZADARMO na webovej stránke www.xeipo.com
**********************************************************
**/

//HomePage
define("Locale_Theme_1", "дома");

//Articles
define("Locale_Theme_3", "Статьи");
define("Locale_Theme_6", "Нет статей не были включены в нашу базу данных");
define("Locale_Theme_7", "еще статьи");
define("Locale_Theme_13", "Последние статьи");
define("Locale_Theme_14", "Статья старше");
define("Locale_Theme_41", "категория");

//Comments
define("Locale_Theme_10", "Комментарии");
define("Locale_Theme_43", "Для добавления комментария необходимо войти в систему !");
define("Locale_Theme_44", "Сообщение не может быть пустым !");
define("Locale_Theme_45", "Отчет содержит недопустимые символы !");
define("Locale_Theme_11", "Нет комментариев были добавлены . Будьте первым, чтобы комментировать.");
define("Locale_Theme_12", "Для добавления комментария необходимо войти в систему !");
define("Locale_Theme_46", "Ответить на комментарий No.");
define("Locale_Theme_47", "управление...");

//User
define("Locale_Theme_15", "В форме развивать скорость по лагу");
define("Locale_Theme_16", "Ник");
define("Locale_Theme_17", "Введите ник");
define("Locale_Theme_18", "пароль");
define("Locale_Theme_19", "Вводить пароль");
define("Locale_Theme_20", "войти в систему");
define("Locale_Theme_21", "Пароль не правильно !");
define("Locale_Theme_22", "Вы не заполнили все поля !");
define("Locale_Theme_23", "Offline");
define("Locale_Theme_24", "онлайн");
define("Locale_Theme_25", "5 мин");
define("Locale_Theme_8", "автор");
define("Locale_Theme_9", "Počet komentárov");
define("Locale_Theme_34", "администрация");
define("Locale_Theme_35", "Отказаться от подписки ");
define("Locale_Theme_36", "профиль");

//Panely
define("Locale_Theme_48", "Последние темы на форуме");
define("Locale_Theme_49", "Самые популярные темы на форуме");

//Forum
define("Locale_Theme_2", "форум");
define("Locale_Theme_26", "Все темы форума");
define("Locale_Theme_27", "ответить");
define("Locale_Theme_28", "нет ни одной темы в форуме не включаются в нашу базу данных.");
define("Locale_Theme_50", "Сообщение не может быть пустым и должен содержать 8 макс 400 знаков !");
define("Locale_Theme_51", "Тема содержит nepovoelé символы или не соответствует символы должны быть между 3-40 ! ");
define("Locale_Theme_52", "Добавить тему");
define("Locale_Theme_53", "Удалить тему");
define("Locale_Theme_54", "ответить");
define("Locale_Theme_55", "В этой категории , так как нет ни одной темыa !");
define("Locale_Theme_56", "написал / а");
define("Locale_Theme_57", " Ответить");
define("Locale_Theme_58", "Стена пуста");
define("Locale_Theme_59", "послать");
define("Locale_Theme_60", "Для проводок доски объявлений , вам придется зарегистрироваться !");
define("Locale_Theme_61", "скачать");


//Downloads
define("Locale_Theme_4", "скачать");
define("Locale_Theme_29", "все файлы");
define("Locale_Theme_30", "Нет загрузки не включаются в нашу базу данных!");

//Addons
define("Locale_Theme_31", "Эта база данных пуста !");

//Eshop
define("Locale_Theme_5", "для продажи");
define("Locale_Theme_32", "Интернет-магазин");
define("Locale_Theme_33", "НДС :");

//Administration
define("Locale_Theme_37", "Вернуться на главную страницу");
define("Locale_Theme_38", "резервное копирование сайта");
define("Locale_Theme_39", "Общие настройки");


//News
define("Locale_Theme_40", "новости");
define("Locale_Theme_42", "Нет новостей не включена в нашу базу данных");

//Contact
define("Locale_Theme_62", "После обработки вашего сообщения , я отвечу на ваш адрес электронной почты , который вы вводите в форму контакта . Поэтому ожидать ответа в вашей электронной почты почтовый ящик.
Я не буду связываться с другими , чем электронная почта . Для более тесного контакта мы можем организовать в индивидуальном порядке по электронной почте связь.V событие, которое вы нашли ошибку в системе xeipe , пожалуйста, свяжитесь с нами через наш веб-сайт
<a href='//xeipo.com/' target='blank_'>Xeipo.com</a> Ďakujeme.");

define("Locale_Theme_63", "Имя и фамилия");
define("Locale_Theme_64", "ваш электронный адрес");
define("Locale_Theme_65", "Название Вашего сообщения");
define("Locale_Theme_66", "управления контентом");

//Edit profile
define("Locale_Theme_67", "аватар");
define("Locale_Theme_68", "Вы не выбрали файл для загрузки.");
define("Locale_Theme_69", "Не удалось загрузить файлы , пожалуйста, обратитесь к администратору сервера.");
define("Locale_Theme_70", "Расширение файла должно быть одним из:");
define("Locale_Theme_71", "Тип изображения должны быть JPG, PNG или GIF.");
define("Locale_Theme_72", "Загруженный файл не изображение !");
define("Locale_Theme_73", "Был ошибка с базой данных");
define("Locale_Theme_74", "Не выбран файл");
define("Locale_Theme_75", "запись");
define("Locale_Theme_76", "Общие настройки");
define("Locale_Theme_77", "изменить свой пароль");
define("Locale_Theme_78", "неприкосновенность частной жизни");
define("Locale_Theme_79", "O mne");
define("Locale_Theme_80", "Основные возможности");
define("Locale_Theme_81", "Был ошибка с базой данных");
define("Locale_Theme_82", "Ник должен содержать как минимум 3-30 символов и может содержать только - z0-9");
define("Locale_Theme_83", "Электронная почта не является действительным");
define("Locale_Theme_84", "Все данные были отправлены !");
define("Locale_Theme_85", "кличка");
define("Locale_Theme_86", "эмаль");
define("Locale_Theme_87", "изменение");
define("Locale_Theme_88", "Измените свой пароль , заполнив форму ниже");
define("Locale_Theme_89", "Пароль пользователя был изменен !");
define("Locale_Theme_90", "Пароль должен содержать гостиницы первыми Должен содержать по крайней мере одну цифру <br> 2 . Должен содержать по крайней мере одну заглавную букву <br> треть Должно быть, по крайней мере 8-40 символов отели 4-ый Разрешенные символы просто -Z A-Z 0-9 " ) ;
define("Locale_Theme_91", "Пароли не совпадают !");
define("Locale_Theme_92", "Все данные были отправлены !");
define("Locale_Theme_93", "Они были посланы ко всем данным !");
define("Locale_Theme_94", "Показать по электронной почте общественности");
define("Locale_Theme_95", "Текст содержит недопустимые символы");
define("Locale_Theme_96", "Текст мне должно быть , от 100 - 1200 символов и может содержать только и - z0-9");
define("Locale_Theme_97", "экономить");
define("Locale_Theme_98", "Ошибка Свяжитесь с владельцем через контактную форму.");
define("Locale_Theme_105", "Редактировать профиль");
define("Locale_Theme_106", "Контактная информация");
define("Locale_Theme_107", "Пользователь не хочет быть опубликована по электронной почте.");
define("Locale_Theme_108", "стена");

//Footer
define("Locale_Theme_99", "О компании");
define("Locale_Theme_100", "контакт");
define("Locale_Theme_101", "поиск");

//Login
define("Locale_Theme_102", "Создать учетную запись");
define("Locale_Theme_103", "Введите имя или адрес электронной почты");
define("Locale_Theme_104", "Забыли пароль");
define("Locale_Theme_109", "регистрация ");
define("Locale_Theme_110", "VОЗДАНИЕ новой учетной записи пользователя");
define("Locale_Theme_111", "Вы должны отправить все поля !");
define("Locale_Theme_112", "E-mail еще раз");
define("Locale_Theme_113", "пароль еще раз");
define("Locale_Theme_114", "Регистрация отключена!");

//Search
define("Locale_Theme_115", "поиск...");
define("Locale_Theme_116", "прогноз");
define("Locale_Theme_117", "пользователи");
define("Locale_Theme_118", "Статьи");
define("Locale_Theme_119", "форум");
define("Locale_Theme_120", "Эта поисковая система выполняет поиск для пользователей, тем и статей с форума.");
define("Locale_Theme_121", "Ничего не было найдено");

?>