﻿<?php

/**
**********************************************************
* Xeipo FREE VERSION CMS 
* @version FREE CMS BETA
* @author Jozef Vajdiar
* @copyright Copyright (C) 2015 - 2016 
**********************************************************
* Tento program je slobodný softvér: môžete ho šíriť a upravovať podľa ustanovení Všeobecnej verejnej 
* licencie GNU (GNU General Public Licence), vydávanej nadáciou Free Software Foundation a to podľa 3. verzie tejto Licencie
* Tento program je rozširovaný v nádeji, že bude užitočný, avšak BEZ AKEJKOĽVEK ZÁRUKY. 
* Neposkytujú sa ani odvodené záruky PREDAJNOSTI alebo VHODNOSTI PRE URČITÝ ÚČEL. 
* Ďalšie podrobnosti hľadajte vo Všeobecnej verejnej licencii GNU.
**********************************************************
* Kópiu Všeobecnej verejnej licencie GNU ste mali dostať spolu s týmto programom. (license.txt)
* Ak sa tak nestalo, nájdete ju tu: <http://www.gnu.org/licenses/>
* Tento system nájdete ZADARMO na webovej stránke www.xeipo.com
**********************************************************
**/

//Setup.php
$locale["setup_1"] = "установка CHMOD";
$locale["setup_2"] = "Установить соединение с базой данных";
$locale["setup_3"] = "Хостинг";
$locale["setup_4"] = "пользователь";
$locale["setup_5"] = "пароль";
$locale["setup_6"] = "имя базы данных";
$locale["setup_7"] = "Все поля обязательные для заполнения !";
$locale["setup_8"] = "Нам не удалось подключиться к базе данных , пожалуйста, установите эти поля снова.";
$locale["setup_9"] = "Все было успешным.";
$locale["setup_10"] = "Настройка учетной записи";
$locale["setup_11"] = "Все было успешным";
$locale["setup_12"] = "Heslá sa nezhodujú prosím skontrolujte tento formulár !";
$locale["setup_13"] = "Все поля обязательные для заполнения";
$locale["setup_14"] = "Наполните ник - псевдоним";
$locale["setup_15"] = "Введите свой адрес электронной почты účtuVyplnte новый ник - псевдоним";
$locale["setup_16"] = "Установить пароль";
$locale["setup_17"] = "Установить пароль еще раз";
$locale["setup_18"] = "лицензия";
$locale["setup_19"] = "Прочитайте условия лицензионного соглашения";
$locale["setup_20"] = "Если вы согласны с условиями ниже , нажмите на стрелку в нужном направлении !";
$locale["setup_21"] = "<h4>Free License (AGPL) </h4> 
Отели xeipe выпущен в соответствии с условиями версии 3 GNU Affero General Public License.
Для получения дополнительной информации посетите <a href='http://www.gnu.org/licenses/agpl-3.0.html'> http://www.gnu.org/licenses/agpl-3.0.html или </a>
Прочитайте файл license.txt, который входит в пакет установки.
Вы можете изменить кодовую страницу, как вам нравится, единственное условие, что вы оставите в своей странице колонтитула авторского права 'Работает на xeipe', как указано в лицензии AGPL.
Авторское право авторских прав на человека, который создал какую-то работу, в нашей системе случай xeipe. Коллектив авторов Иосиф Vajdiar.
Copyright xeipe на сайте колонтитула строго запрещается изменять или удалять.
Удаление или перезапись авторских прав на их сайтах, нарушающих autora.Copyright на сайте колонтитула должен выглядеть следующим образом (ссылки должны быть официальным, таким образом, www.xeipo.com)
Работает на <a href='//xeipo.com' target='blank_'>xeipe</a> © Copyright 2015 - ".date("Y", time())." . Освобожденные как свободное программное обеспечение под v3 
<a href='https://www.gnu.org/licenses/agpl-3.0.html' target='blank_'> GNU Affero GPL. </a> Гостиницы <br><br>
<h4> Удалить авторские права </h4> Гостиницы
Авторское право может юридически удалить, но только если у вас есть письменное разрешение по электронной почте о выплате суммы требовали. Отели
Плата для каждого домена отдельно. Отели
<strong> Для получения дополнительной информации свяжитесь с нами по адресу r3w0lut10ns@gmail.com</strong>";
$locale["setup_23"] = "Благодарим Вас за использование нашей системы управления контентом.";	
$locale["setup_24"] = "Akutalizácie необходимо, пожалуйста";	
$locale["setup_25"] = "Перейти к Сети";	
$locale["setup_26"] = "Для вашего сервера не найден файл config.php FTP , пожалуйста, создайте его, нажав на кнопку ниже ! ";	
$locale["setup_27"] = "Создать файл";	
$locale["setup_28"] = "создать config.php";	
$locale["setup_29"] = "Перейти к установке";	

?>