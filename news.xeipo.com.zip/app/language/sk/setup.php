<?php

/**
**********************************************************
* Xeipo FREE VERSION CMS 
* @version FREE CMS BETA
* @author Jozef Vajdiar
* @copyright Copyright (C) 2015 - 2016 
**********************************************************
* Tento program je slobodný softvér: môžete ho šíriť a upravovať podľa ustanovení Všeobecnej verejnej 
* licencie GNU (GNU General Public Licence), vydávanej nadáciou Free Software Foundation a to podľa 3. verzie tejto Licencie
* Tento program je rozširovaný v nádeji, že bude užitočný, avšak BEZ AKEJKOĽVEK ZÁRUKY. 
* Neposkytujú sa ani odvodené záruky PREDAJNOSTI alebo VHODNOSTI PRE URČITÝ ÚČEL. 
* Ďalšie podrobnosti hľadajte vo Všeobecnej verejnej licencii GNU.
**********************************************************
* Kópiu Všeobecnej verejnej licencie GNU ste mali dostať spolu s týmto programom. (license.txt)
* Ak sa tak nestalo, nájdete ju tu: <http://www.gnu.org/licenses/>
* Tento system nájdete ZADARMO na webovej stránke www.xeipo.com
**********************************************************
**/

//Setup.php
$locale["setup_1"] = "Nastavenie chmodu";
$locale["setup_2"] = "Nastavte spojenie s databázov";
$locale["setup_3"] = "Hosting";
$locale["setup_4"] = "Užívateľ";
$locale["setup_5"] = "Heslo";
$locale["setup_6"] = "Názov databázy";
$locale["setup_7"] = "Všetky polia sú povinné !";
$locale["setup_8"] = "Nepodarilo sa nám spojiť s databázov, prosím nastavte tieto polia ešte raz.";
$locale["setup_9"] = "Všetko prebehlo úspešne.";
$locale["setup_10"] = "Nastavenie Vášho účtu";
$locale["setup_11"] = "Všetko prebehlo úspešne";
$locale["setup_12"] = "Heslá sa nezhodujú prosím skontrolujte tento formulár !";
$locale["setup_13"] = "Všetky polia sú povinné";
$locale["setup_14"] = "Vyplnte nick - prezívku";
$locale["setup_15"] = "Vyplnte email Vášho nového účtu";
$locale["setup_16"] = "Nastavte heslo";
$locale["setup_17"] = "Nastavte heslo ešte raz";
$locale["setup_18"] = "Licencia";
$locale["setup_19"] = "Prečítajte si licenčné podmienky";
$locale["setup_20"] = "Ak súhlasite s podmienkami uvedenými nižšie kliknite na šípku smerom do prava !";
$locale["setup_21"] = "<h4>Voľná licencia (AGPL)</h4><br>Xeipo je uvoľnené pod podmienkami verzie 3 GNU Affero General Public License. 
Pre ďalšie informácie navštívte <a href='http://www.gnu.org/licenses/agpl-3.0.html'>http://www.gnu.org/licenses/agpl-3.0.html</a> alebo si prečítajte súbor license.txt, ktorý je súčasťou inštalačného balíčka.
Kód stránky môžete zmeniť ako len chcete, jedinou podmienkou je, že si necháte vo footeri svojej stránky copyright 'Powered by Xeipo' ako je uvedené v licencii AGPL.
Copyright je autorské právo osoby ktorá vytvorila určité dielo, v našom prípade systém Xeipo. Tým autorom je Jozef Vajdiar. 
Autorské práva Xeipo vo footeri stránky, je prísne zakázané zmeniť alebo vymazať. 
Odstránením alebo prepísaním copyrightu zo svojej stránky, porušujete autorské právo autora.Copyright vo footeri stránky má vyzerať nasledovne (odkaz musí odkazovať na oficiálnu stránku čiže www.xeipo.com):
Powered by <a href='//xeipo.com' target='blank_'>Xeipo</a> copyright © 2015 - ".date("Y", time()).". Released as free software without warranties under <a href='https://www.gnu.org/licenses/agpl-3.0.html' target='blank_'>GNU Affero GPL v3</a>.<br><br>
<h4>Odstránenie copyrightu</h4><br>
Copyright môžete legálne odstrániť len v prípade ak máte písomné povolenie prostredníctvom e-mailu o zaplatení požadovanej čiastky.<br>
Poplatok je za každú doménu samostatne.<br>
<strong>Pre viac informácií nás kontaktujte na r3w0lut10ns@gmail.com</strong>";
$locale["setup_22"] = "Inštalácia prebehla úspešne";	
$locale["setup_23"] = "Ďakujeme za použitie nášho redakčného systému.";	
$locale["setup_24"] = "Potrebné akutalizácie nájdete na";	
$locale["setup_25"] = "Prejsť na web";	
$locale["setup_26"] = "Na Vašom FTP servery sa nenašiel súbor config.php prosím vytvorte ho kliknutím na tlačítko nižšie !";	
$locale["setup_27"] = "Vytvoriť tento súbor";	
$locale["setup_28"] = "Vytvorte config.php";	
$locale["setup_29"] = "Prejsť na inštaláciu systému";	

?>