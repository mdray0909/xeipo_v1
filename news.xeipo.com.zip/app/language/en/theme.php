<?php

/**
**********************************************************
* Xeipo FREE VERSION CMS 
* @version FREE CMS BETA
* @author Jozef Vajdiar
* @copyright Copyright (C) 2015 - 2016 
**********************************************************
* Tento program je slobodný softvér: môžete ho šíriť a upravovať podľa ustanovení Všeobecnej verejnej 
* licencie GNU (GNU General Public Licence), vydávanej nadáciou Free Software Foundation a to podľa 3. verzie tejto Licencie
* Tento program je rozširovaný v nádeji, že bude užitočný, avšak BEZ AKEJKOĽVEK ZÁRUKY. 
* Neposkytujú sa ani odvodené záruky PREDAJNOSTI alebo VHODNOSTI PRE URČITÝ ÚČEL. 
* Ďalšie podrobnosti hľadajte vo Všeobecnej verejnej licencii GNU.
**********************************************************
* Kópiu Všeobecnej verejnej licencie GNU ste mali dostať spolu s týmto programom. (license.txt)
* Ak sa tak nestalo, nájdete ju tu: <http://www.gnu.org/licenses/>
* Tento system nájdete ZADARMO na webovej stránke www.xeipo.com
**********************************************************
**/

//HomePage
define("Locale_Theme_1", "Home page");

//Articles
define("Locale_Theme_3", "Articles");
define("Locale_Theme_6", "No articles were not included in our database");
define("Locale_Theme_7", "more Articles");
define("Locale_Theme_13", "Recent Article");
define("Locale_Theme_14", "older Article");
define("Locale_Theme_41", "category");

//Comments
define("Locale_Theme_10", "Comments");
define("Locale_Theme_43", "To add a comment you must log !");
define("Locale_Theme_44", "Message can not be empty !");
define("Locale_Theme_45", "The report contains illegal characters !");
define("Locale_Theme_11", "No Comments have been added . Be the first to comment.");
define("Locale_Theme_12", "To add a comment you must log !");
define("Locale_Theme_46", "Reply to comment No.");
define("Locale_Theme_47", "A message...");

//User
define("Locale_Theme_15", "Log in form");
define("Locale_Theme_16", "Nick");
define("Locale_Theme_17", "Enter a nickname");
define("Locale_Theme_18", "Password");
define("Locale_Theme_19", "Enter the password");
define("Locale_Theme_20", "Log in");
define("Locale_Theme_21", "The password is not correct !");
define("Locale_Theme_22", "You have not filled all the fields !");
define("Locale_Theme_23", "Offline");
define("Locale_Theme_24", "Online");
define("Locale_Theme_25", "5 min");
define("Locale_Theme_8", "Author");
define("Locale_Theme_9", "comments posted");
define("Locale_Theme_34", "Administration");
define("Locale_Theme_35", "Log out");
define("Locale_Theme_36", "profile");

//Panely
define("Locale_Theme_48", "The latest forum topics");
define("Locale_Theme_49", "Most popular forum topics");










//Forum
define("Locale_Theme_2", "Forum");
define("Locale_Theme_26", "All topics Forum");
define("Locale_Theme_27", "reply");
define("Locale_Theme_28", "no topics in the forum are not in our database.");
define("Locale_Theme_50", "Message can not be empty and must contain 8 max 400 characters !");
define("Locale_Theme_51", "Topic contains invalid characters or does not meet the characters must be between 3-40!");
define("Locale_Theme_52", "Add a theme");
define("Locale_Theme_53", "Remove theme");
define("Locale_Theme_54", "reply");
define("Locale_Theme_55", "In this category, as no issue !");
define("Locale_Theme_56", "wrote ");
define("Locale_Theme_57", "To respond");
define("Locale_Theme_58", "The Wall is empty");
define("Locale_Theme_59", "To send");
define("Locale_Theme_60", "For postings to message boards you will have to sign up !");
define("Locale_Theme_61", "Download file");


//Downloads
define("Locale_Theme_4", "For download");
define("Locale_Theme_29", "all files");
define("Locale_Theme_30", "No downloads are not included in our database !");

//Addons
define("Locale_Theme_31", "This database is empty !");

//Eshop
define("Locale_Theme_5", "For sale");
define("Locale_Theme_32", "E-shop");
define("Locale_Theme_33", "Price with VAT :");

//Administration
define("Locale_Theme_37", "Back to home page");
define("Locale_Theme_38", "backup site");
define("Locale_Theme_39", "General settings");


//News
define("Locale_Theme_40", "News");
define("Locale_Theme_42", "No news is not included in our database");

//Contact
define("Locale_Theme_62", "After processing your message , I will reply to your e-mail address that you enter in the contact form. Therefore expect an answer in your e - mail inbox .
I will not contact other than e -mail. For closer contact we can arrange individually through e -mail komunikácie.V the event that you find a bug in the system xeipe please contact us via our website
<a href='//xeipo.com/' target='blank_'>Xeipo.com</a> Thanks.");

define("Locale_Theme_63", "Name and surname");
define("Locale_Theme_64", "Your e-mail");
define("Locale_Theme_65", "Title of your message");
define("Locale_Theme_66", "content management");

//Edit profile
define("Locale_Theme_67", "Avatar");
define("Locale_Theme_68", "Did you select the file you want to upload.");
define("Locale_Theme_69", "The upload failed , please contact the server administrator.");
define("Locale_Theme_70", "The file extension must be one of:");
define("Locale_Theme_71", "Type of picture must be JPG , PNG or GIF.");
define("Locale_Theme_72", "The uploaded file is not image !");
define("Locale_Theme_73", "Formed chyba with database");
define("Locale_Theme_74", "Not selected a file");
define("Locale_Theme_75", "record");
define("Locale_Theme_76", "General settings");
define("Locale_Theme_77", "Change Password");
define("Locale_Theme_78", "privacy");
define("Locale_Theme_79", "about me");
define("Locale_Theme_80", "Key features");
define("Locale_Theme_81", "There was an error with the database");
define("Locale_Theme_82", "Nick must contain at least 3-30 characters long and can contain only a -z0-9");
define("Locale_Theme_83", "Email is not valid");
define("Locale_Theme_84", "All data have been sent !");
define("Locale_Theme_85", "Nickname");
define("Locale_Theme_86", "Email");
define("Locale_Theme_87", "Change");
define("Locale_Theme_88", "Change your password by filling the form below");
define("Locale_Theme_89", "User password has been changed !");
define("Locale_Theme_90", "The password must contain hotels first Must contain at least one digit <br> 2. Must contain at least one uppercase letter <br> third Must have at least 8-40 characters hotels 4th Allowed characters are just a-z A -Z 0-9 " );
define("Locale_Theme_91", "Passwords do not match !");
define("Locale_Theme_92", "I was sent to all data!");
define("Locale_Theme_93", "They were sent to all data !");
define("Locale_Theme_94", "Show email public");
define("Locale_Theme_95", "The text contains invalid characters");
define("Locale_Theme_96", "Text of me must have, from 100 - 1200 characters and can only contain and -z0-9");
define("Locale_Theme_97", "Save");
define("Locale_Theme_98", "An error has occurred Contact the owner via the contact form.");
define("Locale_Theme_105", "Edit profile");
define("Locale_Theme_106", "Contact Information");
define("Locale_Theme_107", "The user does not want to be published email.");
define("Locale_Theme_108", "Bulletin board");

//Footer
define("Locale_Theme_99", "About us");
define("Locale_Theme_100", "contact");
define("Locale_Theme_101", "search");

//Login
define("Locale_Theme_102", "Create an account");
define("Locale_Theme_103", "Enter a nickname or email");
define("Locale_Theme_104", "Forgotten password");
define("Locale_Theme_109", "Registration");
define("Locale_Theme_110", "Create a new user account");
define("Locale_Theme_111", "You must send all fields!");
define("Locale_Theme_112", "Email again");
define("Locale_Theme_113", "password again");
define("Locale_Theme_114", "Registration is disabled !");

//Search
define("Locale_Theme_115", "Search...");
define("Locale_Theme_116", "Seek out");
define("Locale_Theme_117", "users");
define("Locale_Theme_118", "Articles");
define("Locale_Theme_119", "Fórum");
define("Locale_Theme_120", "This search engine searches for users , topics and articles from the forum.");
define("Locale_Theme_121", "Nothing has been found");

?>