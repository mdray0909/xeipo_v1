<?php

/**
**********************************************************
* Xeipo FREE VERSION CMS 
* @version FREE CMS BETA
* @author Jozef Vajdiar
* @copyright Copyright (C) 2015 - 2016 
**********************************************************
* Tento program je slobodný softvér: môžete ho šíriť a upravovať podľa ustanovení Všeobecnej verejnej 
* licencie GNU (GNU General Public Licence), vydávanej nadáciou Free Software Foundation a to podľa 3. verzie tejto Licencie
* Tento program je rozširovaný v nádeji, že bude užitočný, avšak BEZ AKEJKOĽVEK ZÁRUKY. 
* Neposkytujú sa ani odvodené záruky PREDAJNOSTI alebo VHODNOSTI PRE URČITÝ ÚČEL. 
* Ďalšie podrobnosti hľadajte vo Všeobecnej verejnej licencii GNU.
**********************************************************
* Kópiu Všeobecnej verejnej licencie GNU ste mali dostať spolu s týmto programom. (license.txt)
* Ak sa tak nestalo, nájdete ju tu: <http://www.gnu.org/licenses/>
* Tento system nájdete ZADARMO na webovej stránke www.xeipo.com
**********************************************************
**/

//Setup.php
$locale["setup_1"] = "Einstellung chmod";
$locale["setup_2"] = "Stellen Sie die Datenbankverbindung";
$locale["setup_3"] = "Hosting";
$locale["setup_4"] = "Benutzer";
$locale["setup_5"] = "Kennwort";
$locale["setup_6"] = "Datenbankname";
$locale["setup_7"] = "Alle Felder sind erforderlich !";
$locale["setup_8"] = "Wir waren nicht in der Lage zu Datenbank zu verbinden , setzen Sie bitte diese Felder wieder.";
$locale["setup_9"] = "Alles war erfolgreich.";
$locale["setup_10"] = "Konto einrichten";
$locale["setup_11"] = "Alles war erfolgreich";
$locale["setup_12"] = "Passwörter stimmen nicht überein , bitte dieses Formular überprüfen !";
$locale["setup_13"] = "Alle Felder sind erforderlich";
$locale["setup_14"] = "Füllen Sie Spitznamen - Spitznamen";
$locale["setup_15"] = "Füllen Sie Ihr neues Konto E-Mail";
$locale["setup_16"] = "Passwort setzen";
$locale["setup_17"] = "Legen Sie das Kennwort erneut";
$locale["setup_18"] = "Lizenz";
$locale["setup_19"] = "Lesen Sie die Lizenzbedingungen";
$locale["setup_20"] = "Wenn Sie die Bedingungen unten akzeptieren, klicken Sie auf den Pfeil in die richtige Richtung !";
$locale["setup_21"] = "<h4> Free License (AGPL) </h4> Hotels xeipe ist unter den Bedingungen der Version freigegeben 3 der GNU Affero General Public License.
Für weitere Informationen besuchen Sie <a href='http://www.gnu.org/licenses/agpl-3.0.html'> http://www.gnu.org/licenses/agpl-3.0.html oder </a> Lesen Sie die license.txt-Datei, die im Installationspaket enthalten ist.
Sie können die Codepage zu ändern, wie Sie möchten, ist die einzige Bedingung, dass Sie in Ihrer Fußleiste copyright 'Angetrieben durch xeipe' verlassen, wie in AGPL Lizenz bezeichnet.
Das Urheberrecht ist Urheberrecht die Person, die etwas Arbeit geschaffen, in unserem Fall xeipe System. Team der Autoren ist Joseph Vajdiar.
Urheberrecht xeipe in der Fußzeile Website ist streng zu ändern oder zu löschen verboten.
Löschen oder Überschreiben des Copyright ihrer Websites autora.Copyright in der Fußzeile Website zu verletzen sollte wie folgt aussehen (Referenzen muss offiziell sein so www.xeipo.com)
Angetrieben von <a href='//xeipo.com' target='blank_'> xeipe </a> © Copyright 2015 - ".date("Y", time()).". Erschienen als freie Software unter der 
<a href='https://www.gnu.org/licenses/agpl-3.0.html' target='blank_'> GNU Affero GPL v3. </a> Hotels <br ><br >
<h4> Entfernen copyright </h4> Hotels
Urheberrecht kann rechtlich entfernen, aber nur, wenn Sie die Erlaubnis per E-Mail über die Zahlung des Betrags gefordert geschrieben haben. Hotels
Die Gebühr ist für jeden separat Domain. Hotels
<strong> Für weitere Informationen kontaktieren Sie uns unter r3w0lut10ns@gmail.com </strong>";	
$locale["setup_22"] = "Erfolgreich installiert";	
$locale["setup_23"] = "Vielen Dank für unser Content Management System.";	
$locale["setup_24"] = "Akutalizácie erforderlich, bitte";	
$locale["setup_25"] = "Zum Web";	
$locale["setup_26"] = "Um Ihren FTP-Server nicht config.php Datei gefunden , erstellen Sie bitte durch den Button klicken !";	
$locale["setup_27"] = "Datei erstellen";	
$locale["setup_28"] = "erstellen config.php";	
$locale["setup_29"] = "Gehen Sie auf die Installation von";	

?>