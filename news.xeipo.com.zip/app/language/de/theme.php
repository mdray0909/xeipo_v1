<?php

/**
**********************************************************
* Xeipo FREE VERSION CMS 
* @version FREE CMS BETA
* @author Jozef Vajdiar
* @copyright Copyright (C) 2015 - 2016 
**********************************************************
* Tento program je slobodný softvér: môžete ho šíriť a upravovať podľa ustanovení Všeobecnej verejnej 
* licencie GNU (GNU General Public Licence), vydávanej nadáciou Free Software Foundation a to podľa 3. verzie tejto Licencie
* Tento program je rozširovaný v nádeji, že bude užitočný, avšak BEZ AKEJKOĽVEK ZÁRUKY. 
* Neposkytujú sa ani odvodené záruky PREDAJNOSTI alebo VHODNOSTI PRE URČITÝ ÚČEL. 
* Ďalšie podrobnosti hľadajte vo Všeobecnej verejnej licencii GNU.
**********************************************************
* Kópiu Všeobecnej verejnej licencie GNU ste mali dostať spolu s týmto programom. (license.txt)
* Ak sa tak nestalo, nájdete ju tu: <http://www.gnu.org/licenses/>
* Tento system nájdete ZADARMO na webovej stránke www.xeipo.com
**********************************************************
**/

//HomePage
define("Locale_Theme_1", "Zuhause");

//Articles
define("Locale_Theme_3", "Artikel");
define("Locale_Theme_6", "Es wurden keine Artikel nicht in unserer Datenbank enthalten");
define("Locale_Theme_7", "mehr Artikel");
define("Locale_Theme_13", "Neueste Artikel");
define("Locale_Theme_14", "ältere Artikel");
define("Locale_Theme_41", "Kategorie");

//Comments
define("Locale_Theme_10", "Kommentare");
define("Locale_Theme_43", "Um einen Kommentar hinzufügen Sie müssen sich !");
define("Locale_Theme_44", "Das Management kann nicht leer sein !");
define("Locale_Theme_45", "Der Bericht enthält ungültige Zeichen !");
define("Locale_Theme_11", "Keine Kommentare wurden hinzugefügt. Schreiben Sie den ersten Kommentar.");
define("Locale_Theme_12", "Um einen Kommentar hinzufügen Sie müssen sich !");
define("Locale_Theme_46", "Auf Kommentar antworten Nein.");
define("Locale_Theme_47", "Management...");

//User
define("Locale_Theme_15", "Melden Sie sich in Form");
define("Locale_Theme_16", "Kerbe");
define("Locale_Theme_17", "Geben Sie einen Spitznamen");
define("Locale_Theme_18", "Kennwort");
define("Locale_Theme_19", "Geben Sie das Kennwort");
define("Locale_Theme_20", "registrieren");
define("Locale_Theme_21", "Das Passwort ist nicht korrekt !");
define("Locale_Theme_22", "Sie haben nicht alle Felder gefüllt !");
define("Locale_Theme_23", "Offline");
define("Locale_Theme_24", "Online");
define("Locale_Theme_25", "5 min");
define("Locale_Theme_8", "Autor");
define("Locale_Theme_9", "Kommentare geschrieben");
define("Locale_Theme_34", "Verwaltung");
define("Locale_Theme_35", "überprüfen");
define("Locale_Theme_36", "Profil");

//Panely
define("Locale_Theme_48", "Die neuesten Forenthemen");
define("Locale_Theme_49", "Die beliebtesten Themen in");










//Forum
define("Locale_Theme_2", "Forum");
define("Locale_Theme_26", "Alle Themen Forum");
define("Locale_Theme_27", "antworten");
define("Locale_Theme_28", "keine Themen im Forum sind nicht in unserer Datenbank enthalten.");
define("Locale_Theme_50", "Nachricht kann nicht leer sein und 8 maximal 400 Zeichen enthalten !");
define("Locale_Theme_51", "Thema enthält ungültige Zeichen oder erfüllt nicht die Zeichen zwischen 3-40 sein muss ! !");
define("Locale_Theme_52", "Fügen Sie ein Thema");
define("Locale_Theme_53", "entfernen Thema");
define("Locale_Theme_54", "antworten");
define("Locale_Theme_55", "In dieser Kategorie , da kein Problem !");
define("Locale_Theme_56", "schrieb");
define("Locale_Theme_57", "antworten");
define("Locale_Theme_58", "Die Mauer ist leer");
define("Locale_Theme_59", "senden");
define("Locale_Theme_60", "Für Nachrichten an Message Boards müssen Sie sich registrieren !");
define("Locale_Theme_61", "Download");


//Downloads
define("Locale_Theme_4", "Download");
define("Locale_Theme_29", "Alle Dateien");
define("Locale_Theme_30", "Keine Downloads sind nicht in unserer Datenbank enthalten !");

//Addons
define("Locale_Theme_31", "Diese Datenbank ist leer !");

//Eshop
define("Locale_Theme_5", "zu verkaufen");
define("Locale_Theme_32", "E-shop");
define("Locale_Theme_33", "Mehrwertsteuer :");

//Administration
define("Locale_Theme_37", "Zurück zur Hauptseite");
define("Locale_Theme_38", "Backup-Site");
define("Locale_Theme_39", "Allgemeine Einstellungen");


//News
define("Locale_Theme_40", "Nachrichten");
define("Locale_Theme_42", "Keine Nachricht ist nicht in unserer Datenbank enthalten");

//Contact
define("Locale_Theme_62", "Nach der Bearbeitung Ihrer Nachricht , werde ich auf Ihre E- Mail-Adresse antworten , die Sie in der Kontakt-Formular eingeben. Daher erwarten eine Antwort in Ihrer E- Mail-Posteingang .
Ich werde nicht berühren als E-Mail. Für einen engeren Kontakt können wir individuell per E- Mail komunikácie.V die Veranstaltung organisieren , dass Sie einen Fehler im System xeipe finden kontaktieren Sie uns bitte über unsere Website
<a href='//xeipo.com/' target='blank_'>Xeipo.com</a> Danke.");

define("Locale_Theme_63", "Name und Vorname");
define("Locale_Theme_64", "Ihr email");
define("Locale_Theme_65", "Betreff der Nachricht");
define("Locale_Theme_66", "Content-Management");

//Edit profile
define("Locale_Theme_67", "Avatar");
define("Locale_Theme_68", "Sie nicht ausgewählt haben , eine Datei hochzuladen.");
define("Locale_Theme_69", "Fehler beim Hochladen von Dateien , wenden Sie sich an den Serveradministrator.");
define("Locale_Theme_70", "Die Dateierweiterung muss eine der:");
define("Locale_Theme_71", "Bildtyp muss JPG, PNG oder GIF.");
define("Locale_Theme_72", "Die hochgeladene  Datei ist kein Bild !");
define("Locale_Theme_73", "Es gab einen Fehler mit der Datenbank !");
define("Locale_Theme_74", "Nicht eine Datei ausgewählt");
define("Locale_Theme_75", "Rekord");
define("Locale_Theme_76", "Allgemeine Einstellungen");
define("Locale_Theme_77", "Ihr Passwort ändern");
define("Locale_Theme_78", "Privatleben");
define("Locale_Theme_79", "über");
define("Locale_Theme_80", "Die wichtigsten Funktionen");
define("Locale_Theme_81", "Es gab einen Fehler mit der Datenbank");
define("Locale_Theme_82", "Nick muss mindestens 3-30 Zeichen lang enthalten und nur ein - z0-9 enthalten");
define("Locale_Theme_83", "E-Mail ist nicht gültig");
define("Locale_Theme_84", "Alle Daten wurden gesendet !");
define("Locale_Theme_85", "Spitzname");
define("Locale_Theme_86", "Emaille");
define("Locale_Theme_87", "Veränderung");
define("Locale_Theme_88", "Ändern Sie Ihr Passwort , indem Sie das untenstehende  Formular ausfüllen");
define("Locale_Theme_89", "User-Passwort wurde geändert !");
define("Locale_Theme_90", "Kennwort Das muss Enthalten Hotels 1.Es Muss mindestens Eine Ziffer Hotels Enthalten zweite Es muss mindestens einen Großbuchstaben <br> dritte enthalten Muss mindestens 8-40 Zeichen Hotels 4. haben Erlaubte Zeichen sind nur a-z A-Z 0-9 ");
define("Locale_Theme_91", "Passwörter stimmen nicht überein !");
define("Locale_Theme_92", "Alle Daten wurden gesendet !");
define("Locale_Theme_93", "Sie wurden auf alle Daten gesendet !");
define("Locale_Theme_94", "Anzeigen E-Mail Öffentlichkeit");
define("Locale_Theme_95", "Der Text enthält ungültige Zeichen");
define("Locale_Theme_96", "Text von mir muss von 100 - 1200 Zeichen und kann nur enthalten und - z0-9");
define("Locale_Theme_97", "speichern");
define("Locale_Theme_98", "Ein Fehler ist aufgetreten , die Eigentümer über das Kontaktformular Kontakt.");
define("Locale_Theme_105", "Profil bearbeiten");
define("Locale_Theme_106", "Kontaktinformationen");
define("Locale_Theme_107", "Der Benutzer möchte nicht E-Mail veröffentlicht werden.");
define("Locale_Theme_108", "Wand");

//Footer
define("Locale_Theme_99", "wir über uns");
define("Locale_Theme_100", "Kontakt");
define("Locale_Theme_101", "Suche");

//Login
define("Locale_Theme_102", "erstellen Sie ein Konto");
define("Locale_Theme_103", "Geben Sie einen Spitznamen oder E-Mail");
define("Locale_Theme_104", "Passwort vergessen");
define("Locale_Theme_109", "Anmeldung");
define("Locale_Theme_110", "Erstellen Sie ein neues Benutzerkonto");
define("Locale_Theme_111", "Sie müssen alle Felder senden !");
define("Locale_Theme_112", "E-Mail wieder");
define("Locale_Theme_113", "Kennwort erneut");
define("Locale_Theme_114", "Die Registrierung ist deaktiviert !");

//Search
define("Locale_Theme_115", "Suche...");
define("Locale_Theme_116", "Ausblick");
define("Locale_Theme_117", "Benutzer");
define("Locale_Theme_118", "Artikel");
define("Locale_Theme_119", "Forum");
define("Locale_Theme_120", "Tente Suchmaschine Suche nach Benutzer Thema und Foren Artikel.");
define("Locale_Theme_121", "Es wurde nichts gefunden");

?>