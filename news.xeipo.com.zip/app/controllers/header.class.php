<?php

Class Header{

	public static function location($url){
	  	if(!headers_sent($path, $lineno)){
	    	header("location: $url");	  	
	   	}else{
	    	echo '<pre>Debug: output started at ', $path, ':', $lineno, "</pre>\n";
	  	}

	  	exit();
	}

	public static function refresh($url,$time = 5){
		Header("refresh:".$time.";url=".$url); 
		exit();
	}

	public static function refresh2($time = 0){
		Header("refresh:".$time); 
		exit();
	}
}