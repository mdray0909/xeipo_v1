<?php

Class Exeption{

	public function __construct($err_massage, $err_code){
		if($err_code == "2002"){
			Exeption::setup();
        }else if($err_code == "1045"){    
        	Exeption::setup();
        }else if($err_code == "42S02"){    
			$url = new simpleurl("");
			$lang = $url->segment(2);
			$page = $url->segment(3);

        	if($lang == NULL OR $page == NULL){
            	$this->setup_error($err_massage, $err_code);
        	}else{
        		Exeption::setup();
        	}        	
        }else{	
            $this->setup_error($err_massage, $err_code);
        }

        return false;
	}

	public static function setup(){
        Setup::Install();

        exit();
	}

	private function setup_error($err_msg, $err_code){
		Setup::Error($err_msg, $err_code);

		exit();
	}
}