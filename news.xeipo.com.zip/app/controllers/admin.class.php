<?php

Class Admin{

	public function __construct(){
		echo "test";
	}


}