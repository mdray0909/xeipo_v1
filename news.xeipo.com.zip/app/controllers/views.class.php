<?php

//VISIT WEB
Class Views{

	public function __construct(){
        $this->save();
	}

	public function save(){
		$db = new Framework();

		//Conversion
		$ip = $_SERVER['REMOTE_ADDR'];
      	$browser = $this->get_browser();
	    $os = $this->get_os();

	    //DATABASE
	    $query = $db->pdo->prepare("SELECT * FROM ".DB_PREFIX."views WHERE ip=:ip");
	    $query ->bindParam(':ip', $ip);
	    $query->execute();
	    $row = $query->fetch();

	    if($query->rowCount()>0){
	        if($ip !== $row["ip"]){     
		        //INSERT (THIS IS FIRST VISIT USER)
		        $this->Views_INSERT();
	        }else if(date("Y-m-d") >= date('Y-m-d', strtotime(date($row["timestamp_update"]).' + 24 hours'))){
       
		        //TIME REALING (THIS TIME IS USER SEE WEB)
		        $hours = date('G', strtotime(date($row["timestamp"]).' + 24 hours') ); 	// 24-hour format of an hour without leading zeros
		        $day = date('j', strtotime(date($row["timestamp"]).' + 24 hours')); 	// Day of the month without leading zeros
		        $month = date('n', strtotime(date($row["timestamp"]).' + 24 hours')); 	// Numeric representation of a month, without leading zeros

		        //ADD NEW TABLE TO DATABASE
			    $this->Views_INSERT();	 

			    //UPDATE ALL TIMESTAMP
			    $this->Views_UPDATE_Timestamp();
	       	}
	    }else{      
	        //INSERT (THIS IS FIRST VISIT USER)
	        $this->Views_INSERT();
	    }
	}


	public function Views_INSERT() {

		$db = new Framework();

		//Conversion
		$ip = $_SERVER['REMOTE_ADDR'];
      	$browser = $this->get_browser();
	    $os = $this->get_os();

		//INSERT
	    $query2 = $db->pdo->prepare("INSERT INTO ".DB_PREFIX."views (`ip`, `timestamp`, `timestamp_update`, `browser`, `os`) VALUES (:ip, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, :browser, :os);");
	    $query2-> bindParam(':ip', $ip);
	    $query2-> bindParam(':os', $os);	    
	    $query2-> bindParam(':browser', $browser);
	    $query2->execute();
	}


	public function Views_UPDATE_Timestamp(){
		$db = new Framework();

		//Conversion
		$ip = $_SERVER['REMOTE_ADDR'];
      	$browser = $this->get_browser();
	    $os = $this->get_os();

		//UPDATE TIMESTAMP
	    $query2 = $db->pdo->prepare("UPDATE ".DB_PREFIX."views SET `timestamp_update` = CURRENT_TIMESTAMP  WHERE ip=:ip;");
	    $query2->bindParam(':ip', $ip); 
	    $query2->execute();		
	}

	/*
	#	GET OS
	*/
	public function get_os(){
		$agent = $_SERVER['HTTP_USER_AGENT'];

		if(preg_match('/Linux/',$agent)) {
			$os = 'Linux';
		}elseif(preg_match('/Win/',$agent)) {
			$os = 'Windows';
		}elseif(preg_match('/Mac/',$agent)) {
			$os = 'Mac';
		}else {
			$os = 'UnKnown';
		}

		return $os;
	}

	/*
	# GET BROWSER
	*/
	public function get_browser(){
		$user_agent = $_SERVER['HTTP_USER_AGENT'];

	    if (strpos($user_agent, 'Opera') || strpos($user_agent, 'OPR/')) {
	    	return 'Opera';
	    }elseif (strpos($user_agent, 'Edge')) {
	    	return 'Edge';
	    }elseif (strpos($user_agent, 'Chrome')) {
	    	return 'Chrome';
	    }elseif (strpos($user_agent, 'Safari')) {
	    	return 'Safari';
	    }elseif (strpos($user_agent, 'Firefox')) {
	    	return 'Firefox';
	    }elseif (strpos($user_agent, 'MSIE') || strpos($user_agent, 'Trident/7'))  {
	    	return 'Internet Explorer';
	   	}else{
	   		return 'Other';
	   	}
	}
}