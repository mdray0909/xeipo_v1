<?php

/*
#	Define root web
*/
define('DS', DIRECTORY_SEPARATOR);
define('ROOT', dirname(dirname(__FILE__)));

/*
#	Loading file loader
*/
include_once(ROOT.DS.'loader.php');

$user = new User();
$urls = new simpleurl("");

if(!$urls->segment(1)){ 
	$page2 = "home"; 
}else{
	$page2 = $urls->segment(1); 
}

/*
#	ALL PAGE
*/
switch ($page2) {
	case 'home':
		Presenter::loading_presenter("HomePage");
	break;
	case 'profil':
		Presenter::loading_presenter("profil");
	break;
	case 'forum':
		Presenter::loading_presenter("Forum");
	break;
	case 'article':
		Presenter::loading_presenter("Article");
	break;
	case 'news':
		Presenter::loading_presenter("News");
	break;
	case 'downloads':
		Presenter::loading_presenter("Downloads");
	break;
	case 'shop':
		Presenter::loading_presenter("Shop");
	break;
	case 'editprofile':
		Presenter::loading_presenter("editprofile");
	break;
	case 'cookies':
		Presenter::loading_presenter("cookies");
	break;
	case 'search':
		Presenter::loading_presenter("search");
	break;
	case 'about':
		Presenter::loading_presenter("about");
	break;
	case 'app':
		Presenter::loading_presenter("app");
	break;
	case 'contact':
		Presenter::loading_presenter("contact");
	break;	
	case 'lostpw':
		Presenter::loading_presenter("lostpw");
	break;
	case 'admin':
		if ($user->isInRole('admin') AND $user->isLoggedIn()) {
			Presenter::loading_presenter("admin");
		}else{
			Presenter::loading_presenter("admin_login");
		}
	break;
	case "register":
		Presenter::loading_presenter("register");
	break;		
	case "setup":
		Presenter::loading_presenter("Setup");
	break;	
	case 'logout':
		$user->Logout();
	break;
	case 'adminlogout':
		$user->AdminLogout();
	break;
	default:
		Presenter::loading_presenter("404");
	break;
}


return false;
exit();


?>