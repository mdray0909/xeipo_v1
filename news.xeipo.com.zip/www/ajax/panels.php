<?php

	define('DS', DIRECTORY_SEPARATOR);
	define('ROOT', dirname(dirname(dirname(__FILE__))));
	 
	include (ROOT.DS.'loader.php');

	$db = new Framework();
	$user = new User();
	
	if($user->isLoggedIn()){
		if(User::user_right2("panels")){
			if(!empty($_POST["ordered"])&&empty($_POST["ordered2"])&&empty($_POST["ordered3"])&&empty($_POST["ordered4"])){
				$post = $_POST["ordered"];
			}else if(empty($_POST["ordered"])&&!empty($_POST["ordered2"])&&empty($_POST["ordered3"])&&empty($_POST["ordered4"])){
				$post = $_POST["ordered2"];
			}else if(empty($_POST["ordered"])&&empty($_POST["ordered2"])&&!empty($_POST["ordered3"])&&empty($_POST["ordered4"])){
				$post = $_POST["ordered3"];
			}else if(empty($_POST["ordered"])&&empty($_POST["ordered2"])&&empty($_POST["ordered3"])&&!empty($_POST["ordered4"])){
				$post = $_POST["ordered4"];
			}else{
				$post = $_POST["ordered4"];
			}

			$sorter = $post;
			for ($i=0; $i < count($sorter); $i++) { 
				$numer = $i;
				$id = $sorter[$i];

			    $result = $db->pdo->prepare("UPDATE ".DB_PREFIX."panel SET `numer`=:numer WHERE `id`=:id");
			    $result->bindparam(":numer", $numer);    
			    $result->bindparam(":id", $id);
			    $result->execute();
			}
		}else{
			Header::location(WEB);
		}
	}else{
		Header::location(WEB);
	}








?>