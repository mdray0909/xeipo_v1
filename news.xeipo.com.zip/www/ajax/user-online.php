<?php

	define('DS', DIRECTORY_SEPARATOR);
	define('ROOT', dirname(dirname(dirname(__FILE__))));
	 
	include_once (ROOT.DS.'loader.php');

  $user = new User();

  /*
  # Automatics logout user
  */  
  $user->user_time_logout();
      
?>