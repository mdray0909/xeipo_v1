<?php
session_start();
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="A front-end template that helps you build fast, modern mobile web apps.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <title>Xeipo Corporation</title>
    <link rel='shortcut icon' href='//xeipo.com/media/img/other/favicon.ico' type='image/x-icon'>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href='//fonts.googleapis.com/css?family=Open+Sans:300,400,600,900,300italic,400italic' rel='stylesheet' type='text/css'>

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://code.getmdl.io/1.2.0/material.indigo-pink.min.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/mdb.css" rel="stylesheet">

    <!-- New Font -->
    <link href="https://fonts.googleapis.com/css?family=Baloo+Bhaina|David+Libre|Lato|Open+Sans|Roboto|Source+Sans+Pro&subset=latin-ext,oriya,vietnamese" rel="stylesheet"> 


    <!-- Template style -->
    <link href="css/style.css" rel="stylesheet">
</head>


<body class="fixed-header">


    <!-- 
      Reklama
      <a id="biglink" href="#" target="_blank" style="display:block;background:url('https://img.static.lagardere.cz/europa2sk/body-bg-default.jpg') no-repeat top center;height:100%;width:100%;position:fixed;left:0; top:0; z-index:0"></a>
     -->



    <header>
      <div class="navbar line-none navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
          <div class="row">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <i class="material-icons">&#xE8EE;</i>
              </button>
            <a class="navbar-brand" href="/">
             <img src="img/logo.png" alt="logo" class="logo">
            </a>
            </div>
            <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">

                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Podmienky</a>
                  <ul class="dropdown-menu">   
                    <li><a href="#">Podmienky používania redakčného systému</a></li>
                    <li><a href="#">Podmienky používania tohoto webu</a></li>
                    <li><a href="#">Podmienky licencie</a></li>      
                  </ul>
                </li>  

                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Nahlásiť webstránku</a>
                  <ul class="dropdown-menu">   
                    <li><a href="#">Nahlásiť webstránku</a></li>
                    <li><a href="#">Nahlásené webstránky</a></li>      
                  </ul>
                </li> 

                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Viac informácii</a>
                  <ul class="dropdown-menu">
                    <li><a href="#">Časté otázky</a></li>     
                    <li><a href="#">Ako postupovať pri kúpe licencie</a></li>    
                  </ul>
                </li>  

              </ul>
              <ul class="nav navbar-nav pull-right">
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                      <span class="glyphicon glyphicon-user"></span> Účet
                    <span class="caret"></span>
                  </a>
                  <ul class="dropdown-menu">
                      <li><a href="#">Prihlásiť sa</a></li>
                      <li><a href="#">Vytvoriť nový účet</a></li>
                      <li><a href="#">Obnovenie účtu</a></li>
                  </ul>
                </li>  
              </ul>
            </div><!--/.nav-collapse -->
          </div>
        </div>
      </div>
    </header>





    <div class="contentss container">



        <div class="sliders">
              <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">

                <!-- Wrapper for slides -->
                <div class="carousel-inner" role="listbox">
                  <div class="item active">
                    
                      <img src="img/slider.png" alt="">
                    
                  </div>
                  <div class="item">
                    
                      <img src="img/slider.png" alt="">
                   
                  </div>
                  <div class="item">
                    
                      <img src="img/slider.png" alt="">
                   
                  </div>
                </div>

                <!-- Controls -->
                <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                  <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                  <span class="sr-only">Previous</span>
                </a>
                <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                  <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                  <span class="sr-only">Next</span>
                </a>
              </div>
        </div>



      <div class="row">
        <div class="col-lg-3" style="border-right: 2px solid rgb(243, 243, 243);">



          <div class="panel panel-default">
            <div class="panel-heading">Aktualizácia FREE CMS</div>
            <div class="panel-body">
              <div class="text-center">
                <div class="row">
                  <div class="col-lg-12">
                    <span style="color: #798893;font-size:12px;">Je dostupná verzia 5.0.2fb</span>
                  </div>
                  <div class="col-lg-12"><br>
                    <!-- Colored raised button -->
                    <button class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored mdl-js-ripple-effect">
                      Aktualizovať
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>


          <div class="panel panel-default">
            <div class="panel-heading">Top modifikácie</div>
            <div class="list-group">
                <a class="list-group-item">
                  <span class="badge" data-toggle="tooltip" data-placement="top" title="Počet stiahnutí">14K</span>
                  Cras justo odio
                </a>
                <a class="list-group-item">
                  <span class="badge" data-toggle="tooltip" data-placement="top" title="Počet stiahnutí">2K</span>
                  Cras justo odio
                </a>
                <a class="list-group-item">
                  <span class="badge" data-toggle="tooltip" data-placement="top" title="Počet stiahnutí">1M</span>
                  Cras justo odio
                </a>
            </div>
          </div>


          <div class="panel panel-default">
            <div class="panel-heading">Posledné nákupy</div>
            <div class="panel-body">
              <div class="row">


                <div class="col-lg-12">
                  <div style="float:left;margin-bottom:20px;">
                    <img src="http://img0.mxstatic.com/wallpapers/0b854defd2c03849759ab68485475943_large.jpeg" alt="" style="width:40px;height:40px;">
                  </div>
                  <div style="float:left;padding-left:10px;">
                    Licencia [Advanced] <br>
                    <span style="font-size:10px;">Kúpil/a <a href="#">Rado</a></span>
                  </div>
                </div>

                <div class="col-lg-12">
                  <div style="float:left;margin-bottom:20px;">
                    <img src="http://img0.mxstatic.com/wallpapers/0b854defd2c03849759ab68485475943_large.jpeg" alt="" style="width:40px;height:40px;">
                  </div>
                  <div style="float:left;padding-left:10px;">
                    Licencia [Advanced] <br>
                    <span style="font-size:10px;">Kúpil/a <a href="#">Rado</a></span>
                  </div>
                </div>

                <div class="col-lg-12">
                  <div style="float:left;">
                    <img src="http://img0.mxstatic.com/wallpapers/0b854defd2c03849759ab68485475943_large.jpeg" alt="" style="width:40px;height:40px;">
                  </div>
                  <div style="float:left;padding-left:10px;">
                    Licencia [Advanced] <br>
                    <span style="font-size:10px;">Kúpil/a <a href="#">Rado</a></span>
                  </div>
                </div>


              </div>
            </div>
          </div>



          <div class="panel panel-default">
            <div class="panel-heading">Naše daľšie projekty</div>
            <div class="list-group">
                <a class="list-group-item">
                  <span class="badge" data-toggle="tooltip" data-placement="top" title="Počet stiahnutí">14K</span>
                  Xeipo License
                </a>
                <a class="list-group-item">
                  <span class="badge" data-toggle="tooltip" data-placement="top" title="Počet stiahnutí">2K</span>
                  Xeipo Plugins
                </a>
                <a class="list-group-item">
                  <span class="badge" data-toggle="tooltip" data-placement="top" title="Počet stiahnutí">1M</span>
                  Xeipo Documentation
                </a>
            </div>
          </div>





      <?php

      //Facebook
      $json = file_get_contents("https://graph.facebook.com/v2.7/386698614844797/?fields=fan_count&access_token=1683356771991389|e7cef5d837f3c144267176fb37f5fe25");
      $obj = json_decode($json);

      //Twitter
      $tw_username = 'stackoverflow'; 
      $data = file_get_contents('https://cdn.syndication.twimg.com/widgets/followbutton/info.json?screen_names='.$tw_username); 
      $parsed =  json_decode($data,true);
      $tw_followers =  $parsed[0]['followers_count'];





      ?>
          <div class="panel panel-default">
            <div class="panel-heading">Komunity</div>
            <div class="panel-body">
              <div class="row">
                <div class="col-lg-12" style="margin-bottom:15px;">
                  <div style="width:100%;">
                    <a href="//facebook.com/<?php print_r($obj->{'id'}); ?>" target="blank_">
                      <div style="float:left;">
                        <i class="fa fa-facebook-official" aria-hidden="true" style="font-size: 52px; padding: 0px 28px 0px 0px; color: rgb(54, 88, 153);"></i>
                      </div>
                      <div style="float:left;text-align:left">
                        <div style="font-size:15px;color:rgb(121, 136, 147);font-weight: normal;">@xeipo.fanpage</div>
                        <div style="font-size:25px;color:rgb(121, 136, 147);font-weight: normal;"><?php print_r($obj->{'fan_count'}); ?></div>
                      </div>
                    </a>
                  </div>
                </div>
                <div class="col-lg-12" style="margin-bottom:15px;">
                  <div style="width:100%;margin-bottom:20px;">
                    <a href="https://twitter.com/<?php echo $tw_username; ?>" target="blank_">
                      <div style="float:left;">
                        <i class="fa fa-twitter-square" aria-hidden="true" style="font-size: 52px; padding: 0px 28px 0px 0px; color: rgb(26, 139, 240);"></i>
                      </div>
                      <div style="float:left;text-align:left">
                        <div style="font-size:15px;color:rgb(121, 136, 147);font-weight: normal;">@<?php echo $tw_username; ?></div>
                        <div style="font-size:25px;color:rgb(121, 136, 147);font-weight: normal;"><?php echo $tw_followers; ?></div>
                      </div>
                    </a>
                  </div>
                </div>
                <div class="col-lg-12">
                  <div style="width:100%;margin-bottom:20px;">
                    <a href="#" target="blank_">
                      <div style="float:left;">
                        <i class="fa fa-youtube-square" aria-hidden="true" style="font-size: 52px; padding: 0px 28px 0px 0px; color: rgb(204, 24, 30);"></i>
                      </div>
                      <div style="float:left;text-align:left">
                        <div style="font-size:15px;color:rgb(121, 136, 147);">@xeipo.fanpage</div>
                        <div style="font-size:25px;color:rgb(121, 136, 147);">250 000</div>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>










          <!--  visible-sm visible-md visible-xs  -->
          <div class="panel panel-default">
            <div class="panel-heading">Reklama</div>
            <div class="panel-body">
              <img src="http://new.xeipo.com/img/reklamas.png" class="img-responsive">
            </div>
          </div>




























        </div>
        <div class="col-lg-9">



          <div class="row">
            <div class="col-lg-12">
              <table class="table table-hover"> 
                <thead> 
                  <tr> 
                    <th style="padding: 20px 0px;"></th> 
                    <th style="padding: 20px 0px;">Free CMS</th> 
                    <th style="padding: 20px 0px;">Premium CMS</th> 
                    <th style="padding: 20px 0px;">Advanced CMS</th>                   
                  </tr> 
                </thead> 
                <tbody> 

                  <tr> 
                    <th>Možnosť mazať copyright</th> 
                    <td>---</td> 
                    <td>---</td> 
                    <td>Yes</td>
                  </tr> 

                </tbody>
              </table>
            </div>
          </div>




          <div class="page-header"><span>Články</span></div>
          <div class="row">

            <div class="col-lg-6">
              <div class="demo-card-wide mdl-card">
                <div class="mdl-card__title">
                  <h2 class="mdl-card__title-text">Vitajte</h2>
                </div>
                <div class="mdl-card__supporting-text">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Mauris sagittis pellentesque lacus eleifend lacinia...
                </div>
                <div class="mdl-card__actions mdl-card--border">
                  <a class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect pull-right">
                    Prečítať
                  </a>
                </div>
                <div class="mdl-card__menu">
                  <button class="mdl-button mdl-button--icon mdl-js-button mdl-js-ripple-effect">
                    <i class="material-icons">share</i>
                  </button>
                </div>
              </div>
            </div>

            <div class="col-lg-6">
              <div class="demo-card-wide mdl-card">
                <div class="mdl-card__title">
                  <h2 class="mdl-card__title-text">Vitajte</h2>
                </div>
                <div class="mdl-card__supporting-text">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Mauris sagittis pellentesque lacus eleifend lacinia...
                </div>
                <div class="mdl-card__actions mdl-card--border">
                  <a class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect  pull-right">
                    Prečítať
                  </a>
                </div>
                <div class="mdl-card__menu">
                  <button class="mdl-button mdl-button--icon mdl-js-button mdl-js-ripple-effect">
                    <i class="material-icons">share</i>
                  </button>
                </div>
              </div>
            </div>

            <div class="col-lg-6">
              <div class="demo-card-wide mdl-card">
                <div class="mdl-card__title">
                  <h2 class="mdl-card__title-text">Vitajte</h2>
                </div>
                <div class="mdl-card__supporting-text">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Mauris sagittis pellentesque lacus eleifend lacinia...
                </div>
                <div class="mdl-card__actions mdl-card--border">
                  <a class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect pull-right">
                    Prečítať
                  </a>
                </div>
                <div class="mdl-card__menu">
                  <button class="mdl-button mdl-button--icon mdl-js-button mdl-js-ripple-effect">
                    <i class="material-icons">share</i>
                  </button>
                </div>
              </div>
            </div>

            <div class="col-lg-6">
              <div class="demo-card-wide mdl-card">
                <div class="mdl-card__title">
                  <h2 class="mdl-card__title-text">Vitajte</h2>
                </div>
                <div class="mdl-card__supporting-text">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Mauris sagittis pellentesque lacus eleifend lacinia...
                </div>
                <div class="mdl-card__actions mdl-card--border">
                  <a class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect pull-right">
                    Prečítať
                  </a>
                </div>
                <div class="mdl-card__menu">
                  <button class="mdl-button mdl-button--icon mdl-js-button mdl-js-ripple-effect">
                    <i class="material-icons">share</i>
                  </button>
                </div>
              </div>
            </div>            

          </div>







          <div id="carousel-example-generic23" class="carousel slide" data-ride="carousel23">
            <div class="panel panel-default">
              <div class="panel-heading">
                <div class="row">
                  <div class="pull-left">Na stiahnutie</div>
                  <div class="pull-right">
                    <a href="#carousel-example-generic23" role="button" data-slide="prev">
                      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                    </a>
                    <a href="#carousel-example-generic23" role="button" data-slide="next">
                      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                    </a>
                  </div>
                </div>
              </div>
              <div class="panel-body">
                <div class="row">
                  <div class="carousel-inner" role="listbox">
                    <div class="item active">
                      <ul class="list-group">
                        <li class="list-group-item">Cras justo odio</li>
                        <li class="list-group-item">Dapibus ac facilisis in</li>
                        <li class="list-group-item">Morbi leo risus</li>
                        <li class="list-group-item">Porta ac consectetur ac</li>
                        <li class="list-group-item">Vestibulum at eros</li>
                      </ul>
                    </div>
                    <div class="item">
                      <ul class="list-group">
                        <li class="list-group-item">Cras justo odio</li>
                        <li class="list-group-item">Dapibus ac facilisis in</li>
                        <li class="list-group-item">Morbi leo risus</li>
                        <li class="list-group-item">Porta ac consectetur ac</li>
                        <li class="list-group-item">Vestibulum at eros</li>
                      </ul>
                    </div>
                    <div class="item">
                      <ul class="list-group">
                        <li class="list-group-item">Cras justo odio</li>
                        <li class="list-group-item">Dapibus ac facilisis in</li>
                        <li class="list-group-item">Morbi leo risus</li>
                        <li class="list-group-item">Porta ac consectetur ac</li>
                        <li class="list-group-item">Vestibulum at eros</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>





        </div>


      </div>




        <div style="background:#eee;color:#000;padding:30px;text-align:center;box-shadow: 0px 0px 20px 0px rgba(213, 206, 206, 0.7);" class="row">
          <div class="row">

            <div class="col-lg-12">
              <div style="font-size:15px;font-weight:bold;">Naši sponzory</div>
            </div>

            <div class="col-lg-12">




             <div style="margin-top:30px;">

                <span style="padding-left:20px;padding-right:20px;">
                  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/98/YouTube_Logo.svg/2000px-YouTube_Logo.svg.png" alt="intel" style="height: 25px; margin-top: 0px;">
                </span>

                <span style="padding-left:20px;padding-right:20px;">
                  <img src="http://laserlive.sk/wp-content/uploads/2013/06/markiza.png" alt="intel" style="height: 25px; margin-top: 0px;">
                </span>
                

                <span style="padding-left:20px;padding-right:20px;">
                  <img src="https://img.joj.sk/rx/logojoj.png" alt="intel" style="height: 25px; margin-top: 0px;">
                </span>
                
                <span style="padding-left:20px;padding-right:20px;">
                  <img src="https://upload.wikimedia.org/wikipedia/en/7/7e/GeForce_newlogo.png" alt="intel" style="height: 25px; margin-top: 0px;">
                </span>

                <span style="padding-left:20px;padding-right:20px;">
                  <img src="http://orig02.deviantart.net/b1c6/f/2014/035/3/e/_original_logo__republic_of_gamers_by_18cjoj-d7522td.png" alt="intel" style="height: 50px; margin-top: 0px;">
                </span>

                <span style="padding-left:20px;padding-right:20px;">
                  <img src="http://mediaboom.sk/wp-content/uploads/2013/11/plus-logo-2103.png" alt="intel" style="height: 25px; margin-top: 0px;">
                </span>
                

                <span style="padding-left:20px;padding-right:20px;">
                  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7c/AMD_Logo.svg/1000px-AMD_Logo.svg.png" alt="intel" style="height: 25px; margin-top: 0px;">
                </span>


                <span style="padding-left:20px;padding-right:20px;">
                  <img src="http://www.secret-item-games.com/images/sponsor/Powered-by-Razer-Scaled.png" alt="intel" style="height: 47px; margin-top: 0px;">
                </span>


                <span style="padding-left:20px;padding-right:20px;">
                  <img src="http://i998.photobucket.com/albums/af107/NiteMaaRez/Logos/steelserieslogocopy.png" alt="intel" style="height: 25px; margin-top: 0px;">
                </span>









              </div>


               <div style="margin-top:30px;">

                <span style="padding-left:20px;padding-right:20px;">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c9/Intel-logo.svg/2000px-Intel-logo.svg.png" alt="intel" style="height: 39px;">
                </span>

                <span style="padding-left: 20px; padding-right: 20px;">
                  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Google_2015_logo.svg/1000px-Google_2015_logo.svg.png" alt="intel" style="height: 28px;">
                </span>

                <span style="padding-left:20px;padding-right:20px;">
                  <img src="http://www.szolmusz.hu/epfa/images/2015_2016_tanev/facebook-ads1.png" alt="intel" style="height:60px">
                </span>

                <span style="padding-left:20px;padding-right:20px;">
                  <img src="http://vignette1.wikia.nocookie.net/logopedia/images/5/54/Twitter_logo_with_bird.svg/revision/latest?cb=20141122090331" alt="intel" style="height: 25px; margin-top: 0px;">
                </span>


                <span style="padding-left:20px;padding-right:20px;">
                  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Samsung_Logo.svg/800px-Samsung_Logo.svg.png" alt="intel" style="height: 25px; margin-top: 0px;">
                </span>

                <span style="padding-left:20px;padding-right:20px;">
                  <img src="http://vignette3.wikia.nocookie.net/logopedia/images/f/f2/Google-adsense-logo-2015-transparent.png/revision/latest?cb=20151209082825" alt="intel" style="height: 51px; margin-top: 0px;">
                </span>


              </div>      
 





            </div>
          </div>
        </div>



        <br><br>

    <div class="row">
      <div class="col-xs-12 col-sm-8 col-sm-offset-2 b-newsletter-wrap">
        <div class="c">
          <div class="title-wrap">
            <h3 class="title">Newsletter</h3>
          </div>
          <p>Zaregistrujte sa do newslettera xeipo systému.</p>


          <form action="#">
            <div class="row col-lg-12">
              <input type="email" class="form-control" placeholder="Zadajte Email" style="border: 1px solid rgb(230, 230, 230);padding: 0px 14px;width: 100%;height: 40px;">
            </div> 

            <!-- Accent-colored raised button with ripple -->
            <button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent" style="width: 100%; margin-bottom: 26px; border-radius: 3px; padding: 6px 0px 42px;background:#12c48b;">
              REGISTROVAŤ
            </button>
          </form>


        </div>
      </div>
    </div>






    </div>



    <div style="background:#4285F4;width:100%;">
      <div class="container">
        
        <div class="row">


          <div class="pull-left">
            <img src="https://cdn2.f-cdn.com/build/img/footer-sitestat-twentymillion.svg?v=32255da5a92e44f1a9a341e37ef4394a&amp%3Bm=6" alt="" style="height: 160px; width: 160px;">
          </div> 


          <div style="color:rgb(255, 255, 255);padding: 53px 0px;" class="col-lg-10">
            <div style="padding-left:20px;padding-right:20px;float:left;">
              <span style="font-size: 25px;line-height: 1.33;text-align: left;text-transform: uppercase;">25.000.000</span><br>
              <span style="font-size: 15px;line-height: 1.33;text-align: left;text-transform: uppercase;">Registration users</span>
            </div> 

            <div style="padding-left:20px;padding-right:20px;float:left;">
              <span style="font-size: 25px;line-height: 1.33;text-align: left;text-transform: uppercase;">25.000.000</span><br>
              <span style="font-size: 15px;line-height: 1.33;text-align: left;text-transform: uppercase;">Registration users</span>
            </div> 
          </div> 

        
        </div> 

      </div>
    </div>











      <footer class="mdl-mega-footer footer">
        <div class="container">
          <div class="row">
            <div class="">
              <div class="mdl-mega-footer__middle-section">
                <div class="row">
                  <div class="col-lg-2">
                    <input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
                    <h1 class="mdl-mega-footer__heading">Features</h1>
                    <ul class="mdl-mega-footer__link-list">
                      <li><a href="#">About</a></li>
                      <li><a href="#">Terms</a></li>
                      <li><a href="#">Partners</a></li>
                      <li><a href="#">Updates</a></li>
                    </ul>
                  </div>

                  <div class="col-lg-2">
                    <input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
                    <h1 class="mdl-mega-footer__heading">Details</h1>
                    <ul class="mdl-mega-footer__link-list">
                      <li><a href="#">Specs</a></li>
                      <li><a href="#">Tools</a></li>
                      <li><a href="#">Resources</a></li>
                    </ul>
                  </div>

                  <div class="col-lg-2">
                    <input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
                    <h1 class="mdl-mega-footer__heading">Technology</h1>
                    <ul class="mdl-mega-footer__link-list">
                      <li><a href="#">How it works</a></li>
                      <li><a href="#">Patterns</a></li>
                      <li><a href="#">Usage</a></li>
                      <li><a href="#">Products</a></li>
                      <li><a href="#">Contracts</a></li>
                    </ul>
                  </div>

                  <div class="col-lg-2">
                    <input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
                    <h1 class="mdl-mega-footer__heading">FAQ</h1>
                    <ul class="mdl-mega-footer__link-list">
                      <li><a href="#">Questions</a></li>
                      <li><a href="#">Answers</a></li>
                      <li><a href="#">Contact us</a></li>
                    </ul>
                  </div>





                  <div class="col-lg-4">
                    <div class="row">

                      <div class="col-lg-6">
                        <img src="https://cdn3.f-cdn.com/build/img/footer-mobile.png?v=5a53edddcb2f44fba7a382cf78a54780&m=6" style="width:140px;height:133px;">
                      </div>
                      <div class="col-lg-6">

                        


                        <div class="ramceks">
                          <svg version="1.1" id="US_UK_Download_on_the" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 174.2 50" enable-background="new 0 0 174.2 50" xml:space="preserve" class="app-store-link-badge-ios">
                          <g>
                              <g>
                                  <g>
                                      <g>
                                          <path d="M38.2,24.7c0-4.2,3.5-6.3,3.6-6.4c-1.9-2.8-5-3.3-6.2-3.3c-2.6-0.3-5.1,1.5-6.4,1.5s-3.3-1.5-5.5-1.4
                                              c-2.8,0-5.4,1.7-6.8,4.2C14,24.5,16.2,32.1,19,36.2c1.4,2.1,3.1,4.4,5.3,4.2c2.2-0.1,2.9-1.4,5.5-1.4s3.3,1.4,5.5,1.3
                                              c2.3,0,3.7-2.1,5.1-4.1c1.7-2.3,2.3-4.6,2.3-4.7C42.7,31.4,38.3,29.7,38.2,24.7z"></path>
                                          <path d="M34.1,12.3c1.2-1.4,1.9-3.3,1.7-5.4c-1.7,0.1-3.7,1.2-4.9,2.6c-1,1.3-2.1,3.2-1.8,5.1
                                              C31,14.9,32.8,13.7,34.1,12.3z"></path>
                                      </g>
                                  </g>
                                  <g>
                                      <path d="M69.1,40.1h-2.9L64.5,35h-5.6l-1.5,5.1h-2.9L60,22.7h3.5L69.1,40.1z M64,32.8l-1.4-4.5
                                          c-0.1-0.5-0.4-1.5-0.9-3.3l0,0c-0.1,0.8-0.4,1.8-0.8,3.3l-1.7,4.5H64z"></path>
                                      <path d="M83.5,33.6c0,2.2-0.6,3.8-1.8,5c-1,1.2-2.3,1.7-3.8,1.7c-1.7,0-2.8-0.6-3.6-1.8l0,0v6.7h-2.8V31.7
                                          c0-1.3,0-2.7-0.1-4.1h2.4l0.1,2.1l0,0c0.9-1.5,2.3-2.3,4.2-2.3c1.5,0,2.7,0.6,3.7,1.8C82.9,30.1,83.5,31.7,83.5,33.6z M80.6,33.7
                                          c0-1.3-0.3-2.2-0.8-3.1c-0.6-0.8-1.4-1.3-2.4-1.3c-0.6,0-1.3,0.3-1.9,0.6c-0.5,0.5-0.9,1-1.2,1.8c-0.1,0.4-0.1,0.6-0.1,0.9v2.1
                                          c0,0.9,0.3,1.7,0.9,2.3c0.5,0.6,1.3,0.9,2.2,0.9c1,0,1.9-0.4,2.4-1.2C80.4,36.2,80.6,35.1,80.6,33.7z"></path>
                                      <path d="M97.9,33.6c0,2.2-0.6,3.8-1.8,5c-1,1.2-2.3,1.7-3.8,1.7c-1.7,0-2.8-0.6-3.6-1.8l0,0v6.7h-2.8V31.7
                                          c0-1.3,0-2.7-0.1-4.1h2.4l0.1,2.1l0,0c0.9-1.5,2.3-2.3,4.2-2.3c1.5,0,2.7,0.6,3.7,1.8C97.4,30.1,97.9,31.7,97.9,33.6z M95,33.7
                                          c0-1.3-0.3-2.2-0.8-3.1c-0.6-0.8-1.4-1.3-2.4-1.3c-0.6,0-1.3,0.3-1.9,0.6c-0.5,0.5-0.9,1-1.2,1.8c-0.1,0.4-0.1,0.6-0.1,0.9v2.1
                                          c0,0.9,0.3,1.7,0.9,2.3c0.5,0.6,1.3,0.9,2.2,0.9c1,0,1.9-0.4,2.4-1.2C94.7,36.2,95,35.1,95,33.7z"></path>
                                      <path d="M114.1,35.1c0,1.5-0.5,2.7-1.5,3.6c-1.2,1-2.7,1.5-4.7,1.5c-1.9,0-3.3-0.4-4.5-1l0.6-2.3
                                          c1.3,0.8,2.6,1.2,4,1.2c1,0,1.9-0.3,2.4-0.8c0.6-0.5,0.9-1.2,0.9-1.9c0-0.8-0.3-1.3-0.8-1.8c-0.5-0.5-1.3-0.9-2.4-1.4
                                          c-3.1-1.2-4.6-2.8-4.6-5c0-1.4,0.5-2.6,1.7-3.5c1-0.9,2.4-1.4,4.2-1.4c1.5,0,2.9,0.3,4,0.8l-0.6,2.3c-1-0.5-2.1-0.8-3.3-0.8
                                          c-1,0-1.8,0.3-2.3,0.8c-0.5,0.4-0.6,0.9-0.6,1.5s0.3,1.3,0.8,1.7c0.5,0.4,1.3,0.9,2.6,1.3c1.5,0.6,2.6,1.3,3.3,2.2
                                          C113.7,32.9,114.1,34,114.1,35.1z"></path>
                                      <path d="M123.3,29.6h-3.1v6.2c0,1.5,0.5,2.3,1.7,2.3c0.5,0,0.9,0,1.3-0.1l0.1,2.2c-0.5,0.3-1.3,0.3-2.2,0.3
                                          c-1.2,0-1.9-0.4-2.6-1c-0.6-0.6-0.9-1.8-0.9-3.3v-6.3h-2.1v-2.1h1.8v-2.3l2.7-0.8v3.1h3.1C123.3,27.6,123.3,29.6,123.3,29.6z"></path>
                                      <path d="M137.2,33.7c0,1.9-0.5,3.5-1.7,4.7c-1.2,1.3-2.7,1.9-4.6,1.9c-1.8,0-3.3-0.6-4.4-1.8
                                          c-1.2-1.3-1.7-2.8-1.7-4.6c0-1.9,0.5-3.6,1.7-4.7c1.2-1.3,2.7-1.9,4.6-1.9c1.8,0,3.3,0.6,4.5,1.8
                                          C136.7,30.3,137.2,31.8,137.2,33.7z M134.2,33.8c0-1.2-0.3-2.2-0.8-2.9c-0.6-1-1.4-1.5-2.6-1.5s-1.9,0.5-2.6,1.5
                                          c-0.5,0.8-0.8,1.8-0.8,3.1c0,1.2,0.3,2.2,0.8,2.9c0.6,1,1.4,1.5,2.6,1.5c1,0,1.9-0.5,2.6-1.5C134,35.9,134.2,35,134.2,33.8z"></path>
                                      <path d="M146.2,30c-0.3,0-0.5-0.1-0.9-0.1c-1,0-1.8,0.4-2.3,1.2c-0.5,0.6-0.6,1.5-0.6,2.4V40h-2.8v-8.6
                                          c0-1.4,0-2.8-0.1-4h2.4l0.1,2.4h0.1c0.3-0.8,0.8-1.5,1.4-2.1c0.6-0.5,1.3-0.6,2.1-0.6c0.3,0,0.5,0,0.6,0
                                          C146.2,27.3,146.2,30,146.2,30z"></path>
                                      <path d="M158.7,33.2c0,0.5,0,0.9-0.1,1.3h-8.3c0,1.3,0.4,2.2,1.2,2.8c0.8,0.6,1.7,0.9,2.7,0.9
                                          c1.3,0,2.3-0.3,3.3-0.6l0.4,1.9c-1.2,0.5-2.6,0.8-4.2,0.8c-1.9,0-3.5-0.5-4.6-1.7c-1.2-1.2-1.7-2.7-1.7-4.6s0.5-3.5,1.5-4.7
                                          c1-1.3,2.6-2.1,4.4-2.1c1.8,0,3.2,0.6,4.1,2.1C158.3,30.3,158.7,31.7,158.7,33.2z M156,32.4c0-0.8-0.1-1.5-0.5-2.2
                                          c-0.5-0.8-1.3-1.2-2.2-1.2s-1.7,0.4-2.2,1.2c-0.5,0.6-0.8,1.3-0.8,2.2H156L156,32.4z"></path>
                                  </g>
                                  <g>
                                      <g>
                                          <path d="M63.1,11.9c0,1.5-0.5,2.7-1.4,3.5c-0.9,0.8-2.1,1-3.6,1c-0.8,0-1.4,0-2.1-0.1V7.8
                                              c0.8-0.1,1.5-0.1,2.3-0.1c1.5,0,2.6,0.4,3.3,1C62.6,9.5,63.1,10.5,63.1,11.9z M61.5,11.9c0-1-0.3-1.8-0.8-2.3s-1.3-0.8-2.3-0.8
                                              c-0.4,0-0.8,0-1.2,0.1v6.4c0.1,0,0.5,0,0.9,0c1,0,1.9-0.3,2.4-0.9C61.3,14,61.5,13.1,61.5,11.9z"></path>
                                          <path d="M70.6,13.3c0,0.9-0.3,1.7-0.8,2.3c-0.5,0.6-1.3,0.9-2.3,0.9c-0.9,0-1.7-0.3-2.2-0.9
                                              c-0.5-0.6-0.8-1.4-0.8-2.3s0.3-1.8,0.8-2.3c0.5-0.6,1.3-0.9,2.2-0.9s1.7,0.3,2.2,0.9C70.4,11.7,70.6,12.3,70.6,13.3z M69.2,13.3
                                              c0-0.5-0.1-1-0.4-1.4c-0.3-0.5-0.6-0.8-1.3-0.8c-0.5,0-1,0.3-1.3,0.8c-0.3,0.4-0.4,0.9-0.4,1.5c0,0.5,0.1,1,0.4,1.4
                                              c0.3,0.5,0.8,0.8,1.3,0.8s0.9-0.3,1.3-0.8C69.1,14.4,69.2,13.8,69.2,13.3z"></path>
                                          <path d="M81,10.3l-1.9,6.2h-1.3l-0.8-2.7c-0.3-0.6-0.4-1.3-0.5-2.1l0,0c-0.1,0.6-0.3,1.3-0.5,2.1l-0.9,2.7h-1.3
                                              l-1.8-6.2h1.4l0.6,2.9c0.1,0.6,0.3,1.4,0.4,1.9l0,0c0.1-0.5,0.3-1.2,0.5-1.9l0.9-2.9h1.2l0.9,2.8c0.3,0.6,0.4,1.4,0.5,2.1l0,0
                                              c0.1-0.6,0.3-1.3,0.4-2.1l0.8-2.8H81L81,10.3z"></path>
                                          <path d="M88.1,16.4h-1.4v-3.5c0-1-0.4-1.7-1.3-1.7c-0.4,0-0.8,0.1-1,0.5c-0.3,0.3-0.4,0.6-0.4,1v3.7h-1.4v-4.5
                                              c0-0.5,0-1.2,0-1.8h1.2l0.1,1l0,0c0.1-0.3,0.4-0.5,0.8-0.8c0.4-0.3,0.8-0.4,1.3-0.4s1,0.1,1.4,0.5c0.5,0.5,0.8,1.2,0.8,2.1
                                              C88.1,12.7,88.1,16.4,88.1,16.4z"></path>
                                          <path d="M91.9,16.4h-1.4v-9h1.4V16.4z"></path>
                                          <path d="M100,13.3c0,0.9-0.3,1.7-0.8,2.3c-0.5,0.6-1.3,0.9-2.3,0.9c-0.9,0-1.7-0.3-2.2-0.9
                                              C94.2,15,94,14.2,94,13.3s0.3-1.8,0.8-2.3c0.5-0.6,1.3-0.9,2.2-0.9c0.9,0,1.7,0.3,2.2,0.9C99.6,11.7,100,12.3,100,13.3z
                                               M98.5,13.3c0-0.5-0.1-1-0.4-1.4c-0.3-0.5-0.6-0.8-1.3-0.8c-0.5,0-1,0.3-1.3,0.8c-0.3,0.4-0.4,0.9-0.4,1.5c0,0.5,0.1,1,0.4,1.4
                                              c0.3,0.5,0.8,0.8,1.3,0.8s0.9-0.3,1.3-0.8C98.3,14.4,98.5,13.8,98.5,13.3z"></path>
                                          <path d="M106.5,16.4h-1.3l-0.1-0.8l0,0c-0.4,0.5-1,0.9-1.8,0.9c-0.6,0-1-0.1-1.4-0.5c-0.4-0.4-0.5-0.8-0.5-1.3
                                              c0-0.8,0.3-1.3,0.9-1.7c0.6-0.4,1.5-0.6,2.7-0.6v-0.1c0-0.8-0.4-1.3-1.3-1.3c-0.6,0-1.2,0.1-1.7,0.5l-0.3-0.9
                                              c0.5-0.4,1.3-0.5,2.2-0.5c1.7,0,2.4,0.9,2.4,2.6V15C106.5,15.5,106.5,16,106.5,16.4z M105.1,14.4v-1c-1.5,0-2.3,0.4-2.3,1.3
                                              c0,0.4,0.1,0.5,0.3,0.8c0.1,0.1,0.4,0.3,0.6,0.3c0.3,0,0.6-0.1,0.9-0.3c0.3-0.1,0.4-0.4,0.5-0.8
                                              C105.1,14.5,105.1,14.4,105.1,14.4z"></path>
                                          <path d="M114.4,16.4h-1.2l-0.1-1l0,0c-0.4,0.8-1,1.2-1.9,1.2c-0.8,0-1.4-0.3-1.8-0.9c-0.5-0.6-0.8-1.3-0.8-2.3
                                              s0.3-1.8,0.8-2.4c0.5-0.5,1.2-0.9,1.9-0.9c0.8,0,1.4,0.3,1.8,0.9l0,0V7.3h1.4v7.3C114.4,15.4,114.4,15.9,114.4,16.4z
                                               M112.9,13.8v-1c0-0.1,0-0.4,0-0.4c-0.1-0.4-0.3-0.6-0.5-0.8c-0.3-0.3-0.5-0.4-0.9-0.4c-0.5,0-0.9,0.3-1.2,0.6
                                              c-0.3,0.4-0.4,0.9-0.4,1.5s0.1,1.2,0.4,1.5s0.6,0.6,1.2,0.6c0.5,0,0.8-0.1,1-0.5C112.8,14.6,112.9,14.2,112.9,13.8z"></path>
                                          <path d="M126.2,13.3c0,0.9-0.3,1.7-0.8,2.3c-0.5,0.6-1.3,0.9-2.3,0.9c-0.9,0-1.7-0.3-2.2-0.9
                                              c-0.5-0.6-0.8-1.4-0.8-2.3s0.3-1.8,0.8-2.3s1.3-0.9,2.2-0.9c0.9,0,1.7,0.3,2.2,0.9C125.9,11.7,126.2,12.3,126.2,13.3z
                                               M124.6,13.3c0-0.5-0.1-1-0.4-1.4c-0.3-0.5-0.6-0.8-1.3-0.8c-0.5,0-1,0.3-1.3,0.8c-0.3,0.4-0.4,0.9-0.4,1.5c0,0.5,0.1,1,0.4,1.4
                                              c0.3,0.5,0.8,0.8,1.3,0.8s0.9-0.3,1.3-0.8C124.5,14.4,124.6,13.8,124.6,13.3z"></path>
                                          <path d="M133.5,16.4h-1.4v-3.5c0-1-0.4-1.7-1.3-1.7c-0.4,0-0.8,0.1-1,0.5c-0.3,0.3-0.4,0.6-0.4,1v3.7h-1.4v-4.5
                                              c0-0.5,0-1.2,0-1.8h1.2l0.1,1l0,0c0.1-0.3,0.4-0.5,0.8-0.8c0.4-0.3,0.8-0.4,1.3-0.4s1,0.1,1.4,0.5c0.5,0.5,0.8,1.2,0.8,2.1V16.4
                                              z"></path>
                                          <path d="M142.7,11.3h-1.5v2.9c0,0.8,0.3,1.2,0.8,1.2c0.3,0,0.5,0,0.6-0.1v1c-0.3,0.1-0.6,0.1-1,0.1
                                              c-0.5,0-1-0.1-1.3-0.5s-0.5-0.9-0.5-1.7v-2.9h-0.9v-1h0.9V9.1l1.3-0.4v1.5h1.5L142.7,11.3L142.7,11.3z"></path>
                                          <path d="M150,16.4h-1.4v-3.5c0-1.2-0.4-1.7-1.3-1.7c-0.6,0-1,0.4-1.3,1c0,0.1-0.1,0.3-0.1,0.5v3.7h-1.4v-9h1.4
                                              v3.7l0,0c0.4-0.6,1-1,1.8-1c0.5,0,1,0.1,1.4,0.5c0.5,0.5,0.6,1.2,0.6,2.1C150,12.8,150,16.4,150,16.4z"></path>
                                          <path d="M157.4,13.1c0,0.3,0,0.5,0,0.6h-4.1c0,0.6,0.3,1,0.6,1.4c0.4,0.3,0.8,0.4,1.4,0.4c0.6,0,1.2-0.1,1.7-0.3
                                              l0.3,0.9c-0.6,0.3-1.3,0.4-2.1,0.4c-0.9,0-1.7-0.3-2.3-0.9c-0.5-0.5-0.8-1.3-0.8-2.3c0-0.9,0.3-1.7,0.8-2.3c0.5-0.6,1.3-1,2.2-1
                                              s1.5,0.4,2.1,1C157.3,11.7,157.4,12.3,157.4,13.1z M156.2,12.7c0-0.4-0.1-0.8-0.3-1c-0.3-0.4-0.6-0.5-1.2-0.5
                                              c-0.4,0-0.8,0.1-1.2,0.5c-0.3,0.3-0.4,0.6-0.4,1C153.3,12.7,156.2,12.7,156.2,12.7z"></path>
                                      </g>
                                  </g>
                              </g>
                          </g>
                          </svg>
                        </div>
                        <div class="ramceks">
                          <img src="https://cdn2.f-cdn.com/build/css/images/app-badges/google-play-store-alt.png?v=cf63421e7d4c46202fba3059e356fdf8&amp%3Bm=6" alt="" class="img-responsive">
                        </div>
                      </div>


                      <div class="col-lg-12">


                        <span style="font-size: 14px;font-size: .875rem;line-height: 1.43;margin-top: 20px;font-weight: 900;text-transform: uppercase;">Stiahni si našu xeipo app</span>

                        <p>Stiahni si našu xeipo appku do tvojho smartfónu !</p>



                      </div>










                    </div>
                  </div>
                </div>
              </div>


              <div class="mdl-mega-footer__bottom-section">

                  <div class="row">
                    <div class="col-lg-10">
                      <ul class="mdl-mega-footer__link-list">
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Terms and Conditions</a></li>
                        <li><a href="#">Copyright Infringement Policy</a></li>
                        <li><a href="#">Code of Conduct </a></li>
                      </ul> 
                      <div class="row">
                        <div class="col-lg-8"><br>
                        Copyright © 2015 - 2016 Xeipo
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-2 text-right">
                      <!-- Expandable Textfield -->
                      <form action="#">
                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--expandable">
                          <label class="mdl-button mdl-js-button mdl-button--icon" for="sample6">
                            <i class="material-icons">search</i>
                          </label>
                          <div class="mdl-textfield__expandable-holder">
                            <input class="mdl-textfield__input" type="text" id="sample6">
                            <label class="mdl-textfield__label" for="sample-expandable">Vyhľadávanie</label>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>

              </div>





            </div>
          </div>    
        </div>
      </footer>






  <script defer src="https://code.getmdl.io/1.2.0/material.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>!function(a){"use strict";function e(e){var t="webkitAnimationEnd animationend";e.each(function(){var e=a(this),n=e.data("animation");e.addClass(n).one(t,function(){e.removeClass(n)})})}a("[data-toggle='tooltip']").tooltip({container:"body"}),a("[data-toggle='popover']").popover(),a(window).scroll(function(){a(this).scrollTop()>40?a("body").addClass("header-scroll"):a("body").removeClass("header-scroll")}),a("[data-toggle='modal-search']").click(function(){return a("body").toggleClass("search-open"),!1}),a(".modal-search .close").click(function(){return a("body").removeClass("search-open"),!1}),a("[data-toggle='fixed-header']").click(function(){return a("body").toggleClass("fixed-header"),!1}),setTimeout(function(){a(".progress-animation .progress-bar").each(function(){var e=a(this),t=e.attr("aria-valuenow"),n=0,i=setInterval(function(){n>=t?clearInterval(i):(n+=1,e.css("width",n+"%"))},0)})},0),a(".modal").on("shown.bs.modal",function(e){var t=a(this).data("effect");t&&a(this).find(".modal").addClass("animated "+t)}),a(".modal").on("hidden.bs.modal",function(e){var t=a(this).data("effect");t&&a(this).find(".modal").removeClass("animated "+t)}),a(".bar").click(function(){a("body").toggleClass("nav-open"),a("#wrapper").click(function(){a("body").removeClass("nav-open")})}),a("section.background-image.full-height").each(function(){a(this).css("height",a(window).height())}),a(window).resize(function(){a("section.background-image.full-height").each(function(){a(this).css("height",a(window).height())})}),a(document).ready(function(){var e=a(window);a(".parallax").each(function(){var t=a(this);a(window).scroll(function(){var a=-(e.scrollTop()/"3"),n="50% "+a+"px";t.css({backgroundPosition:n})})})}),a("nav .dropdown > a").click(function(){return!1}),a("nav .dropdown-submenu > a").click(function(){return!1}),a("nav ul li.dropdown").hover(function(){a(this).addClass("open");var e=a(this).data("effect");e?a(this).find(".dropdown-menu").addClass("animated "+e):a(this).find(".dropdown-menu").addClass("animated fast fadeIn")},function(){a(this).removeClass("open");var e=a(this).data("effect");e?a(this).find(".dropdown-menu").removeClass("animated "+e):a(this).find(".dropdown-menu").removeClass("animated fast fadeIn")}),a("nav .dropdown-submenu").hover(function(){a(this).addClass("open")},function(){a(this).removeClass("open")});var t=a("#full-carousel"),n=t.find(".item:first").find("[data-animation ^= 'animated']");e(n),t.carousel("pause"),t.on("slide.bs.carousel",function(t){var n=a(t.relatedTarget).find("[data-animation ^= 'animated']");e(n)}),a(".full-carousel .item").each(function(){a(this).css("height",a(window).height()-a("header").outerHeight())}),a(window).resize(function(){a(".full-carousel .item").each(function(){a(this).css("height",a(window).height()-a("header").outerHeight())})}),a(".inactiveUntilOnLoad").removeClass("inactiveUntilOnLoad"),a(".full-height").each(function(){a(this).css("height",a(window).height()-a("header").outerHeight())}),a(window).resize(function(){a(".full-height").each(function(){a(this).css("height",a(window).height()-a("header").outerHeight())})}),a("#icons ul li i").each(function(){a(this).tooltip({title:a(this).attr("class"),container:"body"})}),a(".modal-sample").click(function(){var e=a("#modal-select").val(),t='<div class="modal myModalSample" tabindex="-1" data-effect="fadeIn" role="dialog" aria-labelledby="myModalSample" aria-hidden="true"><div class="modal-dialog"><div class="modal-content  animated '+e+'"><div class="modal-header"><button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><h4 class="modal-title" id="myModalSampleLabel">'+e+' modal effect</h4></div><div class="modal-body">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent nec mattis odio. In hac habitasse platea dictumst.</div><div class="modal-footer"><button type="button" class="btn btn-warning" data-dismiss="modal">Close</button><button type="button" class="btn btn-primary">Save changes</button></div></div></div></div>';a(".modal-sample").after(t),a(".myModalSample").on("hidden.bs.modal",function(e){a(this).remove()})})}(jQuery);</script>
</body>
</html>