<?php

echo "administrácia video galérie !";

?>