<?php


//Setting
define("NAME_ADDONS", "videogalery");
$id_app = 11815;

//Create Database (INSTALL ADDONS)
$create_db = "CREATE TABLE IF NOT EXISTS `".DB_PREFIX."product` (
				  `id` INT(11) AUTO_INCREMENT PRIMARY KEY,
				  `name` varchar(255) COLLATE utf8_slovak_ci NOT NULL,
				  `category` varchar(255) COLLATE utf8_slovak_ci NOT NULL,
				  `price` varchar(255) COLLATE utf8_slovak_ci NOT NULL,
				  `picture` varchar(255) COLLATE utf8_slovak_ci NOT NULL,
				  `image_on_web` int(1) NOT NULL DEFAULT '0',
				  `autor` varchar(255) COLLATE utf8_slovak_ci NOT NULL,
				  `name_file` varchar(255) COLLATE utf8_slovak_ci NOT NULL,
				  `count_download` bigint(20) NOT NULL DEFAULT '0',
				  `visible` int(1) NOT NULL DEFAULT '1',
				  `text` mediumtext COLLATE utf8_slovak_ci NOT NULL,
				  `buy` int(11) NOT NULL,
				  `count_product` varchar(255) COLLATE utf8_slovak_ci NOT NULL,
				  `disposable_product` int(1) NOT NULL,
				  `file_product` int(1) NOT NULL,
				  `description` varchar(255) COLLATE utf8_slovak_ci NOT NULL,
				  `akcia` varchar(255) COLLATE utf8_slovak_ci NOT NULL,
				  `buy_user_id` varchar(255) COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB;

				INSERT INTO `".DB_PREFIX."product` (`id`, `name`, `category`, `price`, `picture`, `image_on_web`, `autor`, `name_file`, `count_download`, `visible`, `text`, `buy`, `count_product`, `disposable_product`, `file_product`, `description`, `akcia`, `buy_user_id`) 

				VALUES (NULL, 'Name first product', '1', '100', 'http://xeipo.com/img/logo.png', '0', '1', '', '0', '1', 'This is text product :)', '0', '10', '0', '0', 'This is description product', '', '');

				CREATE TABLE IF NOT EXISTS `".DB_PREFIX."product_category` (
				  `id` INT(11) AUTO_INCREMENT PRIMARY KEY,
				  `name` varchar(255) COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB;

				INSERT INTO `".DB_PREFIX."product_category` (`id`, `name`) VALUES ('1', 'Firt cattegory');

				INSERT INTO `".DB_PREFIX."panel` (`id`, `enabled`, `numer`, `content`, `active`, `name_panel`, `enabled_panel`, `name`) VALUES 
				($id_app, '1', '1', '1', '1', 'shop-panel', 'app/shop', 'Video panel');
";

//Delete database (Uinstall Addons)
$delete_db = "DROP TABLE ".DB_PREFIX."product;
DROP TABLE ".DB_PREFIX."product_category;
DELETE FROM ".DB_PREFIX."panel WHERE id=".$id_app.";
";


?>