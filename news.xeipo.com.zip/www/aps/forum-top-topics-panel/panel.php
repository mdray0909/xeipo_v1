<?php


//Content
Bootstrap::open_table("Najnovšie témy fóra");
echo "News témy fóra";
Bootstrap::close_table();


?>