<?php





Bootstrap::open_table("Custom");
echo "Obsah vlastného panela";
Bootstrap::close_table();


?>