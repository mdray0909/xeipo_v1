<?php











Bootstrap::open_table("Nákupný košík");
echo "Obsah tejto modifikácie :)";
Bootstrap::close_table();








?>