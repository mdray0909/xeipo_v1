<?php


echo "toto je administrácia !";

?>