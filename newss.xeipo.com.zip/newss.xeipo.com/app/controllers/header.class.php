<?php

Class Header
{

    public static function location($url)
    {
        if (!headers_sent($path, $lineno)) {
            echo Header("location: $url");

            exit();
        } else {
            echo '<pre>Debug: output started at ', $path, ':', $lineno, "</pre>\n";
        }
    }

    public static function refresh($url, $time = 5)
    {
        echo header("refresh:" . $time . ";url=" . $url);

        exit();
    }

    public static function refresh2($time = 0)
    {
        echo header("refresh:" . $time);

        exit();
    }
}