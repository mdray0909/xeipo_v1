<?php

Class Functions
{
    private $hash;

    /*
    #	Encript password and session
    */
    public static function EnCript($q)
    {
        $hash = "04949asgdfdihdfshsdfhdh0800fc577294c34e0b28ad2839435945";
        $cryptKey = md5($hash);
        $qEncoded = base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, md5($cryptKey), $q, MCRYPT_MODE_CBC, md5(md5($cryptKey))));

        return $qEncoded;
    }

    /*
    #	Decript password and session
    */
    public static function DeCript($q)
    {
        $hash = "04949asgdfdihdfshsdfhdh0800fc577294c34e0b28ad2839435945";
        $cryptKey = md5($hash);
        $qDecoded = rtrim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, md5($cryptKey), base64_decode($q), MCRYPT_MODE_CBC, md5(md5($cryptKey))), "\0");

        return $qDecoded;
    }


    /*
    #	SQL Injection url
    */
    public static function cleanurl($url)
    {
        $bad_entities = array("&", "\"", "'", '\"', "\'", "<", ">", "(", ")", "*");
        $safe_entities = array("&amp;", "", "", "", "", "", "", "", "", "");
        $url = str_replace($bad_entities, $safe_entities, $url);

        return $url;
    }

    /*
    #	BBcode
    */
    public static function bbcode($text)
    {

        // BBcode array
        $find = array(
            '~\[b\](.*?)\[/b\]~s',
            '~\[i\](.*?)\[/i\]~s',
            '~\[code\](.*?)\[/code\]~s',
            '~\[u\](.*?)\[/u\]~s',
            '~\[quote\](.*?)\[/quote\]~s',
            '~\[img\](.*?)\[/img\]~s',
            '~\[url\]((?:ftp|https?)://.*?)\[/url\]~s',
            '~\[url=(.*?)\](.*?)\[/url\]~s',
            '~\[size=(.*?)\](.*?)\[/size\]~s',
            '/https?:\/\/(?:www\.)?youtube\.com\/watch\?v=(.+?)(?:&|\s|$)/',
            '/http(s)?:\/\/youtu\.be\/([^\40\t\r\n\<]+)/i',
            '~\[youtube\](.*?)\[/youtube\]~s'
        );

        // HTML tags to replace BBcode
        $replace = array(
            '<b>\'.$1.\'</b>',
            '<i>\'.$1.\'</i>',
            '<pre style="line-height: 1;">\'.$1.\'</pre>',
            '<span style="text-decoration:underline;">\'.$1.\'</span>',
            '<blockquote><footer>\'.$1.\'</footer></blockquote>',
            '<div class="small-box"><div class="img-responsive"><img src="$1" alt="Obrázok nexistuje" class="img-responsive"></div></div>',
            '<a href="$1" target="_Blank">\'.$1.\'</a>',
            '<a href="$1" target="_Blank">$1</a>',
            '<span style="font-size: $1%;">\'.$2.\'</span>',
            'https://www.youtube.com/embed/$1',
            'https://www.youtube.com/embed/$1.',
            '<div class="embed-responsive embed-responsive-16by9"><iframe class="embed-responsive-item" src="$1"></iframe></div>',
        );

        // Replacing the BBcodes with corresponding HTML tags
        return preg_replace($find, $replace, $text);
    }

    /*
    #	Define smalley
    */
    public static function emoticons($text)
    {
        $icons = array(
            ':)' => '<img src="' . WEB . '/media/img/emoticons/smile.png" 			alt=":)"  data-toggle="tooltip" data-placement="right" 	title="Smyle :)">',
            ':D' => '<img src="' . WEB . '/media/img/emoticons/grin.png" 			alt=":D"  data-toggle="tooltip" data-placement="right" 	title="Smyle :D">',
            ';)' => '<img src="' . WEB . '/media/img/emoticons/wink.png" 			alt=";)"  data-toggle="tooltip" data-placement="right" 	title="Smyle ;)">',
            '3:)' => '<img src="' . WEB . '/media/img/emoticons/devil.png" 			alt="3:)"  data-toggle="tooltip" data-placement="right" 	title="Smyle 3:)">',
            '3:-)' => '<img src="' . WEB . '/media/img/emoticons/devil.png" 			alt="3:-)"  data-toggle="tooltip" data-placement="right" 	title="Smyle 3;-)">',
            '<3' => '<img src="' . WEB . '/media/img/emoticons/devil.png" 			alt="<3"  data-toggle="tooltip" data-placement="right"  	title="Smyle <3">',
            ':(' => '<img src="' . WEB . '/media/img/emoticons/frown.png" 			alt=":("  data-toggle="tooltip" data-placement="right"  	title="Smyle :(">',
            ';(' => '<img src="' . WEB . '/media/img/emoticons/cry.png" 			alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle :´(">',
            '(y)' => '<img src="' . WEB . '/media/img/emoticons/like.png" 			alt="(y)"  data-toggle="tooltip" data-placement="right" 	title="Smyle (y)">',
            '(Y)' => '<img src="' . WEB . '/media/img/emoticons/like.png" 			alt="(Y)"  data-toggle="tooltip" data-placement="right" 	title="Smyle (y)">',
            '(n)' => '<img src="' . WEB . '/media/img/emoticons/dislike.png" 		alt="(n)"  data-toggle="tooltip" data-placement="right" 	title="Smyle (n)">',
            '(N)' => '<img src="' . WEB . '/media/img/emoticons/dislike.png" 		alt="(N)"  data-toggle="tooltip" data-placement="right" 	title="Smyle (n)">',
            'o.O' => '<img src="' . WEB . '/media/img/emoticons/gasp.png" 			alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle o.O">',
            'O.o' => '<img src="' . WEB . '/media/img/emoticons/gasp.png" 			alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle O.o">',
            ':p' => '<img src="' . WEB . '/media/img/emoticons/tongue.png" 			alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle :p">',
            '=p' => '<img src="' . WEB . '/media/img/emoticons/tongue.png" 			alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle =p">',
            ':-p' => '<img src="' . WEB . '/media/img/emoticons/tongue.png" 			alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle :-p">',
            ':P' => '<img src="' . WEB . '/media/img/emoticons/tongue.png" 			alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle :-P">',
            ':-P' => '<img src="' . WEB . '/media/img/emoticons/tongue.png" 			alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle >:(">',
            '>:(' => '<img src="' . WEB . '/media/img/emoticons/upset.png" 			alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle >:-(">',
            '>:-(' => '<img src="' . WEB . '/media/img/emoticons/upset.png" 			alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle :-/">',
            ':-/' => '<img src="' . WEB . '/media/img/emoticons/unsure.png" 			alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle ">',
            '-_-' => '<img src="' . WEB . '/media/img/emoticons/squint.png" 			alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle -_-">',
            ':v' => '<img src="' . WEB . '/media/img/emoticons/pacman.png" 			alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle :v">',
            ':V' => '<img src="' . WEB . '/media/img/emoticons/pacman.png" 			alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle :V">',
            ':3' => '<img src="' . WEB . '/media/img/emoticons/curlylips.png" 		alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle :3">',
            'O:)' => '<img src="' . WEB . '/media/img/emoticons/angel.png" 			alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle O:)">',
            'O:-)' => '<img src="' . WEB . '/media/img/emoticons/angel.png" 			alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle O:-)">',
            '8-)' => '<img src="' . WEB . '/media/img/emoticons/glasses.png" 		alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle 8-)">',
            '8)' => '<img src="' . WEB . '/media/img/emoticons/glasses.png" 		alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle 8-)">',
            'B-)' => '<img src="' . WEB . '/media/img/emoticons/glasses.png" 		alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle 8-)">',
            'B)' => '<img src="' . WEB . '/media/img/emoticons/glasses.png" 		alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle 8-)">',
            ':*' => '<img src="' . WEB . '/media/img/emoticons/kiss.png" 			alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle :*">',
            ':-*' => '<img src="' . WEB . '/media/img/emoticons/kiss.png" 			alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle :*">',
            '8-|' => '<img src="' . WEB . '/media/img/emoticons/sunglasses.png" 		alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle 8-|">',
            '8|' => '<img src="' . WEB . '/media/img/emoticons/sunglasses.png" 		alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle 8|">',
            'B-|' => '<img src="' . WEB . '/media/img/emoticons/sunglasses.png" 		alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle B-|">',
            'B|' => '<img src="' . WEB . '/media/img/emoticons/sunglasses.png" 		alt=":´("  data-toggle="tooltip" data-placement="right" 	title="Smyle B|">'
        );

        return strtr($text, $icons);
    }


    public static function w1250_to_utf8($text)
    {
        $map = array(
            chr(0x8A) => chr(0xA9),
            chr(0x8C) => chr(0xA6),
            chr(0x8D) => chr(0xAB),
            chr(0x8E) => chr(0xAE),
            chr(0x8F) => chr(0xAC),
            chr(0x9C) => chr(0xB6),
            chr(0x9D) => chr(0xBB),
            chr(0xA1) => chr(0xB7),
            chr(0xA5) => chr(0xA1),
            chr(0xBC) => chr(0xA5),
            chr(0x9F) => chr(0xBC),
            chr(0xB9) => chr(0xB1),
            chr(0x9A) => chr(0xB9),
            chr(0xBE) => chr(0xB5),
            chr(0x9E) => chr(0xBE),
            chr(0x80) => '&euro;',
            chr(0x82) => '&sbquo;',
            chr(0x84) => '&bdquo;',
            chr(0x85) => '&hellip;',
            chr(0x86) => '&dagger;',
            chr(0x87) => '&Dagger;',
            chr(0x89) => '&permil;',
            chr(0x8B) => '&lsaquo;',
            chr(0x91) => '&lsquo;',
            chr(0x92) => '&rsquo;',
            chr(0x93) => '&ldquo;',
            chr(0x94) => '&rdquo;',
            chr(0x95) => '&bull;',
            chr(0x96) => '&ndash;',
            chr(0x97) => '&mdash;',
            chr(0x99) => '&trade;',
            chr(0x9B) => '&rsquo;',
            chr(0xA6) => '&brvbar;',
            chr(0xA9) => '&copy;',
            chr(0xAB) => '&laquo;',
            chr(0xAE) => '&reg;',
            chr(0xB1) => '&plusmn;',
            chr(0xB5) => '&micro;',
            chr(0xB6) => '&para;',
            chr(0xB7) => '&middot;',
            chr(0xBB) => '&raquo;',
        );

        return html_entity_decode(mb_convert_encoding(strtr($text, $map), 'UTF-8', 'ISO-8859-2'), ENT_QUOTES, 'UTF-8');
    }

    public static function form_action()
    {
        $urls = new simpleurl("");

        $t = NULL;
        for ($i = 0; $i < 10; $i++) {
            # code...
            if ($urls->segment($i)) {
                $t .= "/" . $urls->segment($i);
            }
        }

        $form_action = WEB . $t;
        return $form_action;
    }

    public static function trim_link($text, $length)
    {
        $dec = array("&", "\"", "'", "\\", '\"', "\'", "<", ">");
        $enc = array("&;", "&quot;", "&#39;", "&#92;", "&quot;", "&#39;", "&lt;", "&gt;");
        $text = str_replace($enc, $dec, $text);

        if (strlen($text) > $length) {
            $text = substr($text, 0, ($length - 3)) . "...";
        }
        $text = str_replace($dec, $enc, $text);

        return $text;
    }

    public static function arihmetic_average($array, $zakruhlit = 2)
    {
        if (is_array($array)) {

            $num = count($array);
            $sum = array_sum($array);

            return round(($sum / $num), $zakruhlit);
        } else {
            return false;
        }
    }


    public static function Img_Resize($path, $widths, $heights)
    {
        $x = getimagesize($path);
        $width = $x['0'];
        $height = $x['1'];

        $rs_width = $widths;  //resize to half of the original width.
        $rs_height = $heights; //resize to half of the original height.

        switch ($x['mime']) {
            case "image/gif":
                $img = imagecreatefromgif($path);
                break;
            case "image/jpeg":
                $img = imagecreatefromjpeg($path);
                break;
            case "image/png":
                $img = imagecreatefrompng($path);
                break;
        }

        $img_base = imagecreatetruecolor($rs_width, $rs_height);
        imagecopyresized($img_base, $img, 0, 0, 0, 0, $rs_width, $rs_height, $width, $height);

        $path_info = pathinfo($path);
        switch ($path_info['extension']) {
            case "gif":
                imagegif($img_base, $path);
                break;
            case "jpeg":
                imagejpeg($img_base, $path, 90);
                break;
            case "png":
                imagepng($img_base, $path);
                break;
        }

        return false;
    }

    public static function compress_image($source_url, $destination_url, $quality)
    {
        $info = getimagesize($source_url);
        if ($info['mime'] == 'image/jpeg') $image = imagecreatefromjpeg($source_url);
        elseif ($info['mime'] == 'image/gif') $image = imagecreatefromgif($source_url);
        elseif ($info['mime'] == 'image/png') $image = imagecreatefrompng($source_url);
        imagejpeg($image, $destination_url, $quality);
        return $destination_url;
    }
}