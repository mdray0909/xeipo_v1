<?php

Class Rating
{

    public function __construct()
    {
        echo "toto je hodnotenie";
    }

}