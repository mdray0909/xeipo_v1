<?php

Class Framework
{
    var $pdo;

    /*
    #   Framework Construct
    */
    public function __construct()
    {
        $this->connectDb();

        return false;
    }

    /*
    #   CONNECT WITH DATABASE
    */
    public function connectDb()
    {
        if (file_exists(ROOT . DS . 'config' . DS . 'config.php')) {
            try {
                if (defined("DB_USER") OR defined("DB_PASSWORD") OR defined("DB_NAME") OR defined("DB_HOST")) {

                    $this->pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASSWORD);

                    $this->setting();
                    $this->api_setting();
                    $this->get_developer_mod();
                    $this->database_diagnostics();
                    $this->change_utf8();

                    return false;
                } else {
                    $this->global_settings();
                    Exeption::setup();

                    return false;
                }
            } catch (PDOException $e) {
                $this->global_settings();

                $url = new simpleurl("");
                if ($url->segment(1) !== "setup") {
                    new Exeption($e->getMessage(), $e->getCode());
                }

                return false;
            }
        } else {

            $this->global_settings();
            Setup::Install();

            return false;
        }
    }

    /*
    #   GET DEVELOPER STATUS
    */
    private function get_developer_mod()
    {
        if (DEVELOPER_MOD == 1) {
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }

        return false;
    }

    /*
    #   CHANGE CHARSET IN DATABASE - UTF-8
    */
    private function change_utf8()
    {
        $sql = "SET 
        character_set_results = 'utf8',  
        character_set_client = 'utf8',  
        character_set_connection = 'utf8', 
        character_set_database = 'utf8', 
        character_set_server = 'utf8'";

        $query2 = $this->pdo->prepare($sql);
        $query2->execute();

        return false;
    }

    /*
    #   DATABASE DIAGNOSTICS
    */
    private function database_diagnostics()
    {
        /*
        $database_diag_array = array(
            "addon",
            "api_settings",
            "articles",
            "articles_category",
            "banned",
            "comment",
            "forum",
            "forum_category",
            "massage",
            "navigation",
            "news",
            "news_category",
            "notification",
            "panel",
            "present",
            "rating",
            "settings",
            "shoutbox",
            "user",
            "user_basket",
            "user_buy_product",
            "user_data",
            "user_group",
            "user_online",
            "user_reset_pw",
            "user_right",
            "views",
        );



        for ($i=0; $i < count($database_diag_array); $i++) {

            $db = $this->pdo->prepare("SELECT * FROM ".DB_PREFIX.$database_diag_array[$i].";");

            if(!$db->execute()) {
                $this->global_settings();
                new Exeption(DB_PREFIX.$key." no exist !", "42S02");

                return false;
            }


        }
*/

    }

    /*
    #   DEFINE WEB URL
    */
    public static function web_link_define()
    {

        if (isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||
            isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https'
        ) {
            $http_client = 'https://';
        } else {
            $http_client = 'http://';
        }

        $web_url = $http_client . $_SERVER['SERVER_NAME'];

        if (!defined('WEB')) {
            define("WEB", $web_url);
        }

        return false;
    }

    /*
    #   DEFINE NAME FROM SETTINGS DATABASE
    */
    public function setting()
    {
        try {
            $query = $this->pdo->prepare("SELECT * FROM " . DB_PREFIX . "settings");
            $query->execute();

            for ($i = 0; $row = $query->fetch(); $i++) {
                $text = Functions::w1250_to_utf8($row["value"]);

                if (!defined($row["name"])) {
                    define($row["name"], $text);
                }
            }
        } catch (PDOException $e) {
            $this->global_settings();
            new Exeption($e->getMessage(), $e->getCode());
        }

        return false;
    }

    /*
    #   DEFINE NAME FROM API SETTINGS DATABASE
    */
    public function api_setting()
    {
        try {
            $query = $this->pdo->prepare("SELECT * FROM " . DB_PREFIX . "api_settings");
            $query->execute();

            for ($i = 0; $row = $query->fetch(); $i++) {
                $text = Functions::w1250_to_utf8($row["value"]);

                if (!defined($row["name"])) {
                    define($row["name"], $text);
                }
            }
        } catch (PDOException $e) {
            $this->global_settings();
            new Exeption($e->getMessage(), $e->getCode());
        }

        return false;
    }

    /*
    #   SETTING SESSION
    */
    public static function session()
    {
        ob_start();
        session_cache_expire(30);
        session_save_path(ROOT . DS . '/temp/sessions/');
        session_name("user_login");
        session_start();
    }

    /*
    #   GLOBAL SETTING FOR INSTALLATION SYSTEM
    */
    private function global_settings()
    {
        if (!defined("TEMPLATES")) {
            define("TEMPLATES", "default");
        }

        if (!defined("LANG")) {
            define("LANG", "en");
        }

        if (!defined("TITLE")) {
            define("TITLE", "Xeipo Corporation");
        }

        if (!defined("DESCRIPTION")) {
            define("DESCRIPTION", "descriptions");
        }

        if (!defined("GLOBAL_LANG")) {
            define("GLOBAL_LANG", "sk");
        }

        if (!defined("DEVELOPER_MOD")) {
            define("DEVELOPER_MOD", false);
        }

        if (!defined("COPYRIGHT")) {
            define("COPYRIGHT", "SS");
        }

        if (!defined("GOOGLE_PLUS_COMMUNITY")) {
            define("GOOGLE_PLUS_COMMUNITY", "S");
        }

        if (!defined("ADMIN_TEMPLATES")) {
            define("ADMIN_TEMPLATES", "admin_template");
        }

        if (!defined("KEYWORDS")) {
            define("KEYWORDS", "");
        }

        if (!defined("VERSION_WEB")) {
            define("VERSION_WEB", "1.0.1");
        }

        return false;
    }


    /*
    #   Update framework version
    */
    public static function updateFrameworkVersion()
    {
        $version = Update::new_version();

        if ($version > "1.0.0") {
            Update::update_line();
        }

        return false;
    }

    /*
    #   Framework license
    */
    public static function copyright()
    {
        # Apologized but the license can not be deleted!
        # Learn more in the Copyright Act of 1976 at 17 U.S.C. § 102(b) and on https://www.gnu.org/licenses/gpl-3.0.html

        # Ospravedlnujeme sa ale túto licenciu nemôžete zmazať !
        # Viac sa dozviete v autorskom zákone - Zákon č. 618/2003 a na https://www.gnu.org/licenses/gpl-3.0.html

        if (date("Y", time()) > "2016") {
            $overenie = "2016 - " . date("Y", time());
        } else {
            $overenie = date("Y", time());
        }

        $txt = "© All right reversed - Copyright " . $overenie . ".";

        echo $txt;

        return false;
    }
}