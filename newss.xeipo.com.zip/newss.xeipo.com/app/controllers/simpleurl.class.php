<?php

Class simpleurl{
    var $site_path;

    public function __construct($site_path){
        $this->site_path = $this->removeSlash("home");

        return false;
    }

    public function __toString(){
        return $this->site_path;
    }

    private function removeSlash($string){
        if (substr($this->site_path, -1, 1) == "/")
        {
            $this->url = substr($this->url, 0, strlen($this->url) - 1);
        }

        return $string;
    }

    public function segment($segment){
        $url = str_replace($this->site_path, "", $_SERVER["REQUEST_URI"]);
        $url = explode('/', $url);

        if(isset($url[$segment])){
            return $url[$segment];
        }else{
            return false;
        }
    }

    public static function SEO_Url($url){

        $seo_url = trim($url);
        $seo_url = html_entity_decode($seo_url);
        $seo_url = strip_tags($seo_url);
        $seo_url = setlocale(LC_CTYPE, 'cs_CZ');
        $seo_url = iconv("utf-8", "us-ascii//TRANSLIT", $url);
        $seo_url = preg_replace('~ ~', '-', $seo_url);
        $seo_url = preg_replace('~-+~', '-', $seo_url);
        $seo_url = preg_replace("/[^a-zA-Z0-9]/i", "-", $seo_url);
        $seo_url = utf8_encode($seo_url);
        $seo_url = strtolower($seo_url);

        if($seo_url == NULL){
            $seo_url = "-";
        }

        return $seo_url;
    }
}