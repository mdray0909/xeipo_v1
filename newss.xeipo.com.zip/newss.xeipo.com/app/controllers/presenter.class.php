<?php

Class Presenter
{

    public static function loading_presenter($name_presenter)
    {
        $presenter_path = ROOT . DS . 'www' . DS . 'templates' . DS . TEMPLATES . DS . strtolower($name_presenter) . '.phtml';
        $default_path = ROOT . DS . 'www' . DS . 'templates' . DS . TEMPLATES . DS . strtolower('homepage.phtml');
        $static_path = ROOT . DS . 'app' . DS . 'presenter' . DS . strtolower($name_presenter) . '.phtml';
        $presenter_path2 = ROOT . DS . 'www' . DS . 'templates' . DS . ADMIN_TEMPLATES . DS . strtolower($name_presenter) . '.phtml';

        if (file_exists($presenter_path)) {
            include_once $presenter_path;
        } elseif (file_exists($presenter_path2)) {
            include_once $presenter_path2;
        } elseif (file_exists($static_path)) {
            include_once $static_path;
        } else {
            include_once $default_path;
        }
    }

    public static function loading_presenter_app($name_app, $name_presenter)
    {
        $presenter_path = ROOT . DS . 'www' . DS . 'aps' . DS . $name_app . DS . strtolower($name_presenter) . '.phtml';

        if (file_exists($presenter_path)) {
            include_once $presenter_path;
        }
    }
}