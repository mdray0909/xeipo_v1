<?php

Class Language
{

    public static function lang_load()
    {
        //Get Settings
        if (LANG !== NULL) {
            $lang = LANG;
        } else {
            if (GLOBAL_LANG !== NULL) {
                $lang = GLOBAL_LANG;
            } else {
                $lang = "sk";
            }
        }

        $array1 = array("setup.php", "global.php", "theme.php");

        if (is_array($array1)) {
            foreach ($array1 as $keys) {
                include(ROOT . DS . 'app' . DS . 'language' . DS . $lang . DS . $keys);
            }
        }

        return false;
    }

    /*
    #   Define language
    */
    public static function lang_define()
    {
        $value = array(
            "en" => "English",
            "af" => "Afganistan",
            "al" => "Albánsko",
            "dz" => "Alžírsko",
            "ao" => "Angola",
            "ar" => "Argentína",
            "am" => "Arménsko",
            "au" => "Austrália",
            "az" => "Azerbajdžan",
            "be" => "Belgicko",
            "bz" => "Belize",
            "by" => "Bielorusko",
            "bo" => "Bolívia",
            "ba" => "Bosna a Hercegovina",
            "br" => "Brazília",
            "bg" => "Bulhársko",
            "cy" => "Cyprus",
            "td" => "Čad",
            "cz" => "Česká republika",
            "cs" => "Česká republika",
            "me" => "Čierna Hora",
            "cl" => "Čile",
            "cn" => "Čína",
            "dk" => "Dánsko",
            "dm" => "Dominika",
            "do" => "Domikinánska republika",
            "eg" => "Egypt",
            "ec" => "Ekvádor",
            "ee" => "Estónsko",
            "et" => "Etiópia",
            "fj" => "Fidži",
            "ph" => "Filipíny",
            "fi" => "Fínsko",
            "fr" => "Francúzsko",
            "gh" => "Ghana",
            "gi" => "Gibraltar",
            "gr" => "Grécko",
            "gd" => "Grenada",
            "gl" => "Grónsko",
            "ge" => "Gruzínsko",
            "gt" => "Guatemala",
            "gn" => "Guinea",
            "gw" => "Guinea – Bissau",
            "gy" => "Guyana",
            "ht" => "Haiti ",
            "nl" => "Holandsko",
            "hn" => "Honduras ",
            "hr" => "Chorvátsko",
            "in" => "India",
            "id" => "Indonézia",
            "iq" => "Irak",
            "ir" => "Irán",
            "ie" => "Írsko",
            "is" => "Island",
            "il" => "Izrael",
            "jm" => "Jamajka",
            "jp" => "Japonsko",
            "ye" => "Jemen",
            "za" => "Južná Afrika",
            "jo" => "Jordánsko",
            "kh" => "Kambodža",
            "cm" => "Kamerun",
            "ca" => "Kanada",
            "qa" => "Katar",
            "kz" => "Kazachstan",
            "ke" => "Keňa",
            "kg" => "Kirgizstan",
            "co" => "Kolumbia",
            "cd" => "Kongo",
            "kr" => "Kórea južná",
            "kp" => "Kórea severna",
            "cr" => "Kostarika",
            "cu" => "Kuba",
            "kw" => "Kuvajt",
            "la" => "Laos",
            "ls" => "Lesotho",
            "lb" => "Libanon",
            "lr" => "Libéria",
            "ly" => "Líbya",
            "li" => "Lichtenštajnsko",
            "lt" => "Litva",
            "lv" => "Lotyšsko",
            "lu" => "Luxembursko",
            "mk" => "Macedónsko",
            "mg" => "Madagaskar",
            "hu" => "Maďarsko",
            "my" => "Malajzia",
            "mw" => "Malawi",
            "ml" => "Mali",
            "mt" => "Malta",
            "ma" => "Maroko",
            "mx" => "Mexio",
            "md" => "Moldavsko",
            "mc" => "Monako",
            "mn" => "Mongolsko",
            "mz" => "Mozambik",
            "na" => "Namíbia",
            "de" => "Nemecko",
            "np" => "Nepál",
            "ne" => "Niger",
            "ng" => "Nigéria",
            "ni" => "Nikaragua",
            "no" => "Nórsko",
            "nz" => "Nový Zéland",
            "om" => "Omán",
            "pk" => "Pakistan",
            "pa" => "Panama",
            "py" => "Paraguay",
            "pe" => "Peru",
            "pl" => "Poľsko",
            "pr" => "Portoriko",
            "pt" => "Portugalsko",
            "at" => "Rakúsko",
            "ro" => "Rumunsko",
            "ru" => "Rusko",
            "rw" => "Rwanda",
            "sv" => "Salvador",
            "sm" => "San Marino",
            "sa" => "Saudská Arábia",
            "sn" => "Senegal",
            "sc" => "Seychely",
            "sl" => "Sierra Leone",
            "sg" => "Singapur",
            "sk" => "Slovensko",
            "si" => "Slovinsko",
            "so" => "Somalsko",
            "us" => "Spojené státy americké",
            "rs" => "Srbsko",
            "lk" => "Srí Lanka",
            "cf" => "Stredoafrická Republika",
            "sd" => "Sudán",
            "sr" => "Surinam",
            "sz" => "Svazijsko",
            "sy" => "Sýria",
            "es" => "Španielsko",
            "ch" => "Švajčiarsko",
            "se" => "Švédsko",
            "tj" => "Tadžikistan",
            "it" => "Taliansko",
            "tz" => "Tabzánia",
            "th" => "Tunijsko",
            "tr" => "Turecko",
            "tm" => "Tuzemsko",
            "ug" => "Uganda",
            "ua" => "Ukrajina",
            "uy" => "Uruguay",
            "uz" => "Uzbekistan",
            "va" => "Vatikán",
            "gb" => "Veľká Británia",
            "ve" => "Venezuela",
            "vn" => "Vietnam",
            "zm" => "Zambia",
            "zw" => "Zimbabwe",
        );

        return $value;
    }
}