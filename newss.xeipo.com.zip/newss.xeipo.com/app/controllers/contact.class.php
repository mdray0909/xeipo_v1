<?php

Class Contact
{

    /*
    #	Contact form post
    */
    public static function contact_form()
    {
        if (isset($_POST["submit"]) && !empty($_POST["name"]) && !empty($_POST["email"]) && !empty($_POST["subject"]) && !empty($_POST["content"])) {

            //Transform
            $massage = $_POST["content"];
            $email = $_POST["email"];
            # $name = $_POST["name"];
            $subject = $_POST["subject"];
            $regex = "/[a-zA-Z0-9]{8,40}$/";
            $regex2 = "/[a-zA-Z0-9]{8,400}$/";

            if (preg_match($regex2, $massage)) {
                if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    if (preg_match($regex, $subject)) {

                        $to = CONTACT_EMAIL;
                        $subject = strip_tags($_POST["subject"]);
                        $message = strip_tags($_POST["content"]);

                        $headers = 'MIME-Version: 1.0' . "\r\n";
                        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                        $headers .= 'To:' . "\r\n";
                        $headers .= 'From: Admin<' . $email . '>' . "\r\n";

                        mail($to, $subject, $message, $headers);

                        Bootstrap::Alert("Kontaktný email odoslaný !", "success");
                    } else {
                        Bootstrap::Alert("Nadpis obsahuje nepovolené znaky - minimálna dlžka 8 znakov až 40 !"
                            , "warning");
                    }
                } else {
                    Bootstrap::Alert("Email obsahuje nepovolené znaky - minimálna dlžka 8 znakov až 40 !", "warning");
                }
            } else {
                Bootstrap::Alert("Správa obsahuje nepovolené znaky - minimálna dlžka 8 znakov až 400 !", "warning");
            }

        } else {
            if (isset($_POST["submit"])) {
                Bootstrap::Alert("Všetky údaje sú povinné");
            }
        }

        return false;
    }

}