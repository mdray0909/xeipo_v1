<?php

Class Administration{

	public function __construct(){
		echo "test";
	}


}