<?php

Class User
{

    /*
    #   This function is used to find user session id logged user
    */
    public function me_id()
    {
        if (isset($_SESSION['user_id'])) {
            $me_id = Functions::DeCript($_SESSION["user_id"]);
        } else {
            $me_id = NULL;
        }

        return $me_id;
    }

    /*
    #   This function is used to define the time after which the user logs off
    */
    public function time_to_offline()
    {
        $time_offline = 500;

        return $time_offline;
    }

    /*
    #   Check banned user
    */
    public static function banned_check($ip)
    {
        $db = new Framework();

        $result_banned = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "banned WHERE address=:ip ORDER BY id DESC LIMIT 0,1");
        $result_banned->bindParam(":ip", $ip);
        $result_banned->execute();

        if ($result_banned->rowCount() > 0) {
            return true;
        } else {
            return false;
        }
    }

    /*
    #	Reason banned user
    */
    public static function banned_reason($ip)
    {
        $db = new Framework();

        $result_banned = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "banned WHERE address=:ip ORDER BY id DESC LIMIT 0,1");
        $result_banned->bindParam(":ip", $ip);
        $result_banned->execute();
        $row = $result_banned->fetch();

        if ($result_banned->rowCount() > 0) {
            return $row["reason"];
        }
    }

    /*
    # 	Check user right file
    */
    public static function user_right($right_name)
    {
        $db = new Framework();
        $user = new User();
        $me_id = $user->me_id();

        $error = 0;

        $result = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user WHERE id=:id ORDER BY id DESC LIMIT 0,1");
        $result->bindParam(":id", $me_id);
        $result->execute();

        if ($result->rowCount() > 0) {
            for ($i = 0; $row = $result->fetch(); $i++) {

                $result = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user_right WHERE id=:id ORDER BY id DESC LIMIT 0,1");
                $result->bindParam(":id", $row["user_right"]);
                $result->execute();

                for ($i = 0; $row = $result->fetch(); $i++) {

                    $rs23 = explode(".", $row["value"]);

                    foreach ($rs23 as $value) {
                        if ($value == $right_name) {
                            $error++;
                        }
                    }

                }

                if (!$error > 0) {
                    Header::location(WEB . "/admin");
                }
            }
        } else {
            Header::location(WEB . "/admin");
        }

        return false;
    }

    /*
    # 	Check user right2
    */
    public static function user_right2($right_name)
    {
        $db = new Framework();
        $user = new User();
        $me_id = $user->me_id();

        $error = 0;

        $result = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user WHERE id=:id");
        $result->bindParam(":id", $me_id);
        $result->execute();

        if ($result->rowCount() > 0) {
            for ($i = 0; $row = $result->fetch(); $i++) {

                $result = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user_right WHERE id=:id");
                $result->bindParam(":id", $row["user_right"]);
                $result->execute();

                for ($i = 0; $row2 = $result->fetch(); $i++) {

                    $rs23 = explode(".", $row2["value"]);

                    foreach ($rs23 as $value) {
                        if ($value == $right_name) {
                            $error++;
                        }
                    }

                }

                if ($error > 0) {
                    return true;
                } else {
                    return false;
                }
            }
        } else {
            return false;
        }
        return false;
    }


    /*
    # 	User exist
    */
    public function user_exist($id_user)
    {
        $db = new Framework();

        $result = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user WHERE id=:id OR facebook_id=:facebookid");
        $result->bindParam(':id', $id_user);
        $result->bindParam(':facebookid', $id_user);
        $result->execute();

        if ($result->rowCount() > 0) {
            return true;
        } else {
            return false;
        }
    }

    /*
    #	User Online time for logout
    */
    public function user_time_logout()
    {
        $db = new Framework();

        if ($this->isLoggedIn()) {
            //Transform
            $id = $this->me_id();

            //Result database
            $result = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user_online WHERE user_id=:id");
            $result->bindParam(':id', $id);
            $result->execute();

            if ($result->rowCount() > 0) {
                for ($i = 0; $row = $result->fetch(); $i++) {
                    if (LOGIN_USE_ALL_BROWSER == 1) {
                        if ($row["time"] + 500 > time()) {
                            //Update time
                            $this->update_online_time_database($row["user_id"]);
                        } else {
                            # Delete from user_online
                            $this->user_online_delete_user();

                            # User is loggout !
                            $this->Logout();
                        }
                    } else {
                        if ($row["salt"] == $this->salt_cript($row["user_id"])) {
                            if (!$i > 0) {
                                if ($row["time"] + 500 > time()) {
                                    //Update time
                                    $this->update_online_time_database($row["user_id"]);
                                } else {
                                    # Delete from user_online
                                    $this->user_online_delete_user();

                                    # User is loggout !
                                    $this->Logout();
                                }
                            } else {
                                # Delete from user_online
                                $this->user_online_delete_user();

                                # User is loggout !
                                $this->Logout();
                            }
                        } else {
                            # Delete from user_online
                            $this->user_online_delete_user();

                            # User is loggout !
                            $this->Logout();
                        }
                    }
                }
            } else {
                $id_user = $this->me_id();
                $time = time();
                $salt = $this->salt_cript($id_user);

                $query2 = $db->pdo->prepare("INSERT INTO " . DB_PREFIX . "user_online (`user_id`, `time`, `salt`) VALUES (:id, :time, :salt);");
                $query2->bindParam(':id', $id_user);
                $query2->bindParam(':time', $time);
                $query2->bindParam(':salt', $salt);
                $query2->execute();
            }
        }

        return false;
    }

    /*
    #	Delete user from user_online
    */
    private function user_online_delete_user()
    {
        $db = new Framework();

        $user_id = $this->me_id();

        $result = $db->pdo->prepare("DELETE FROM " . DB_PREFIX . "user_online WHERE `user_id`=:id");
        $result->bindParam(':id', $user_id);
        $result->execute();

        return false;
    }


    /*
    #	Update time to user online database
    */
    private function update_online_time_database($id)
    {
        $db = new Framework();

        $time = time();

        //Result database
        $result = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user_online WHERE user_id=:id");
        $result->bindParam(':id', $id);
        $result->execute();

        if ($result->rowCount() > 0) {
            for ($i = 1; $row = $result->fetch(); $i++) {
                if ($row["time"] + 500 > time()) {
                    $result2 = $db->pdo->prepare("UPDATE " . DB_PREFIX . "user_online SET `time`=:time WHERE `user_id`=:id;");
                    $result2->bindParam(':time', $time);
                    $result2->bindParam(':id', $id);
                    $result2->execute();
                } else {
                    $this->user_online_delete_users($id);
                }
            }
        } else {
            for ($i = 1; $row = $result->fetch(); $i++) {
                if ($row["time"] + 500 < time()) {


                    # Delete from user_online
                    $this->user_online_delete_user();

                    # User is loggout !
                    $this->Logout();
                }
            }
        }

        return false;
    }

    /*
    #	Delete other user from user_online
    */
    private function user_online_delete_users($ids)
    {
        $db = new Framework();

        $user_id = $ids;

        $result = $db->pdo->prepare("DELETE FROM " . DB_PREFIX . "user_online WHERE `user_id`=:id");
        $result->bindParam(':id', $user_id);
        $result->execute();

        return false;
    }

    /*
    #	Users add to online database
    */
    public function UsersAddOnlineDatabase($id_user)
    {
        $db = new Framework();

        if (LOGIN_USE_ALL_BROWSER == 1) {
            $time = time();
            $salt = $this->salt_cript($id_user);

            $query2 = $db->pdo->prepare("INSERT INTO " . DB_PREFIX . "user_online (`user_id`, `time`, `salt`) VALUES (:id, :time, :salt);");
            $query2->bindParam(':id', $id_user);
            $query2->bindParam(':time', $time);
            $query2->bindParam(':salt', $salt);
            $query2->execute();
        } else {
            //Result database
            $result = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user_online WHERE user_id=:id");
            $result->bindParam(':id', $id_user);
            $result->execute();

            if ($result->rowCount() > 0) {
                for ($i = 0; $row = $result->fetch(); $i++) {
                    $this->update_online_time_database($row["user_id"]);
                }
            } else {
                //Add user
                $time = time();
                $salt = $this->salt_cript($id_user);

                //INSERT
                $query2 = $db->pdo->prepare("INSERT INTO " . DB_PREFIX . "user_online (`user_id`, `time`, `salt`) VALUES (:id, :time, :salt);");
                $query2->bindParam(':id', $id_user);
                $query2->bindParam(':time', $time);
                $query2->bindParam(':salt', $salt);
                $query2->execute();
            }
        }

        return false;
    }

    /*
    #	Salt cript
    */
    private function salt_cript($id)
    {
        $salt_math = $_SERVER['REMOTE_ADDR'] . ";" . $_SERVER['HTTP_USER_AGENT'] . ";" . $id;
        $salt = Functions::EnCript($salt_math);

        return $salt;
    }

    /*
    #	Salt Decript
    */
    public static function salt_decript($salt)
    {
        $salt = Functions::DeCript($salt);

        return $salt;
    }


    /*
    #	LostPw2
    */
    public static function lostpw2()
    {
        $db = new Framework();
        $urls = new simpleurl("");

        $hash = NULL;
        for ($i = 0; $i < 40; $i++) {
            # code...
            if ($i > 2) {
                if ($urls->segment($i)) {
                    if ($i == 3) {
                        $hash .= $urls->segment($i);
                    } else {
                        $hash .= "/" . $urls->segment($i);
                    }
                }
            }
        }

        $hash = Functions::DeCript($hash);
        $hash = explode("/", $hash);

        $nick = $hash[0];
        $email = $hash[1];
        $time = $hash[2];

        $password = NULL;
        for ($i = 0; $i < 40; $i++) {
            # code...
            if ($i > 2) {
                if (@$hash[$i]) {
                    if ($i == 3) {
                        $password .= $hash[$i];
                    } else {
                        $password .= "/" . $hash[$i];
                    }
                }
            }
        }

        $password2 = Functions::EnCript($password);


        if ($time + 300 > time()) {

            $result = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user WHERE nick=:nick AND email=:email AND password=:password");
            $result->bindParam(':nick', $nick);
            $result->bindParam(':email', $email);
            $result->bindParam(':password', $password2);
            $result->execute();

            if ($result->rowCount() > 0) {
                for ($i = 0; $row = $result->fetch(); $i++) {

                    $new_pw = bin2hex(openssl_random_pseudo_bytes(6));

                    $email = CONTACT_EMAIL;
                    $subject = TITLE . " | Žiadosť o nové heslo";
                    $massage = "Vážený zákazník,<br><br>

					bolo Vám vygenerované nové heslo !<br><br>
					<strong>
					Login: " . $row["nick"] . "<br>
					Heslo: " . $new_pw . "<br>
					</strong><br>

					Môžete sa prihlásiť na adrese " . WEB . "<br><br>

					Príjemný deň praje<br>
					--<br>
					" . TITLE . " team <br>
					--<br>
					Kontakt<br>
					email: " . $email;

                    $to = $row["email"];
                    $subject = $subject;
                    $message = $massage;

                    $headers = 'MIME-Version: 1.0' . "\r\n";
                    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                    $headers .= 'To:' . "\r\n";
                    $headers .= 'From: Admin<' . $email . '>' . "\r\n";

                    mail($to, $subject, $message, $headers);


                    $id = $row["id"];
                    $password = Functions::EnCript($new_pw);

                    $result2 = $db->pdo->prepare("UPDATE " . DB_PREFIX . "user SET password=:password WHERE id=:id;");
                    $result2->bindParam(':password', $password);
                    $result2->bindParam(':id', $id);
                    $result2->execute();

                    #Všetko ok
                    Header::location(WEB);
                }
            } else {
                Header::location(WEB);
            }
        } else {
            Bootstrap::alert("čas ubehol !", "warning");
        }
    }


    /*
    #	Lostpw
    */
    public static function lostpw()
    {
        if (isset($_POST["submit"]) && !empty($_POST["email"])) {
            $db = new Framework();
            $nick = strip_tags($_POST["email"]);

            $result = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user WHERE nick=:nick OR email=:email");
            $result->bindParam(':nick', $nick);
            $result->bindParam(':email', $nick);
            $result->execute();

            if ($result->rowCount() > 0) {
                for ($i = 0; $row = $result->fetch(); $i++) {

                    $pw = Functions::DeCript($row["password"]);
                    $hash = Functions::EnCript($row["nick"] . "/" . $row["email"] . "/" . time() . "/" . $pw);

                    $email = CONTACT_EMAIL;
                    $subject = TITLE . " | Žiadosť o nové heslo";
                    $massage = "<span style='font-size:12px;font-family:Arial;'>Vážený zákazník,<br><br>

vyžiadali ste si zaslanie nového hesla pre login <strong>" . $row["nick"] . "</strong>. Nové heslo Vám bude vygenerované a zaslané po kliknutí na nasledujúci odkaz.<br>

V prípade že ste o nové heslo nežiadali ignorujte túto správu resp. neklikajte na odkaz napísaný vyššie !<br>
(Link funguje len 3 minúty po odoslaní žiadosti !)<br><br><br>

<a href='" . WEB . "/lostpw/changepw/" . $hash . "'>Poslať nové heslo</a>

<br><br><br>Príjemný deň praje<br>
--<br>
" . TITLE . " team <br>
--<br>
Kontakt<br>
email: " . $email . "</span>";

                    $to = $row["email"];
                    $subject = $subject;
                    $message = $massage;

                    $headers = 'MIME-Version: 1.0' . "\r\n";
                    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                    $headers .= 'To:' . "\r\n";
                    $headers .= 'From: Admin<' . $email . '>' . "\r\n";

                    mail($to, $subject, $message, $headers);

                    Bootstrap::alert("Vaše nové heslo bolo odoslané na váš mail.", "success");
                }
            } else {
                Bootstrap::alert("Užívateľ s takýmto emailom sa nenašiel v našej databáze.", "warning");
            }
        } else {
            if (isset($_POST["submit"])) {
                Bootstrap::alert("Nevyplnili ste povinné údaje.", "warning");
            }
        }
    }


    /*
    #	REGEX
    */
    public static function regex()
    {
        $regex = "/[a-zA-Z0-9]{8,40}$/";

        return $regex;
    }

    /*
    #	User in role
    */
    public function isInRole($role)
    {
        $id = $this->me_id();

        $user = new User();
        if ($user->isLoggedIn()) {
            if ($role = "admin") {
                $role3 = $this->GetUserData($this->me_id(), "user_right");
                if ($role3 !== NULL) {
                    if ($role3 > 0) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            } else if ($role = "member") {
                $role3 = $this->GetUserData($this->me_id(), "user_right");
                if ($role3 !== NULL) {
                    if ($role3 < 1) {
                        return true;
                    } else {
                        return true;
                    }
                } else {
                    return true;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
        return false;
    }

    /*
    #	User data add to database to registration
    */
    public static function data_registration($id)
    {
        $db = new Framework();

        $null = "Empty";
        $result = $db->pdo->prepare("INSERT INTO " . DB_PREFIX . "user_data 
		        (`id`, `gets`, `skype`, `about_us`, `web`) VALUES (
		        NULL, :id, :skype, :about_us, :web);");
        $result->bindParam(':id', $id);
        $result->bindParam(':skype', $null);
        $result->bindParam(':about_us', $null);
        $result->bindParam(':web', $null);
        $result->execute();

        return false;
    }

    /*
    #	Login post data to login form
    */
    public static function LoginPostData()
    {
        if (isset($_POST["loginforms"]) && !empty($_POST["nick"]) && !empty($_POST["pass"])) {

            //All data post
            $password = Functions::EnCript($_POST["pass"]);
            $nick = trim(htmlentities($_POST["nick"]));

            //Controllers
            $db = new Framework();
            $user = new User();

            //Database
            $result = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user 
	            WHERE nick=:nick OR email=:email AND password=:password 
	            ORDER BY id DESC LIMIT 0,1");
            $result->bindParam(':password', $password);
            $result->bindParam(':nick', $nick);
            $result->bindParam(':email', $nick);
            $result->execute();

            if ($result->rowCount() > 0) {
                for ($i = 0; $row = $result->fetch(); $i++) {
                    $ip_adress = $_SERVER['REMOTE_ADDR'];
                    if (!user::banned_check($ip_adress)) {
                        $nick = $row["nick"];
                        $password = $row["password"];
                        $regex = User::regex();

                        if (preg_match($regex, Functions::DeCript($row["password"]))) {
                            if (Functions::EnCript($_POST["pass"]) == $row["password"]) {
                                if (Functions::EnCript($_POST["nick"]) == Functions::EnCript($row["nick"]) OR
                                    Functions::EnCript($_POST["nick"]) == Functions::EnCript($row["email"])
                                ) {


                                    /*
                                    #	Delete user from user online
                                    */
                                    $result23 = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user_online WHERE `user_id`=:id");
                                    $result23->bindParam(":id", $row["id"]);
                                    $result23->execute();

                                    if ($result->rowCount() > 0) {
                                        for ($i2 = 0; $row23 = $result23->fetch(); $i2++) {
                                            if ($row23["time"] + 500 < time()) {
                                                $user_id = $row["id"];
                                                $result = $db->pdo->prepare("DELETE FROM " . DB_PREFIX . "user_online WHERE `user_id`=:id");
                                                $result->bindParam(':id', $user_id);
                                                $result->execute();
                                            }
                                        }
                                    }


                                    //Create Session
                                    $_SESSION["user_id"] = Functions::EnCript($row["id"]);
                                    $_SESSION["user_broser"] = Functions::EnCript($_SERVER['HTTP_USER_AGENT']);

                                    //Users add to online database
                                    $user = new user();
                                    $user->UsersAddOnlineDatabase($row["id"]);

                                    Header::location(WEB);
                                } else {
                                    Bootstrap::Alert2("Heslo alebo nick sa nezhoduje !", "warning");
                                }
                            } else {
                                Bootstrap::Alert2("Heslo sa nezhoduje !", "warning");
                            }
                        } else {
                            Bootstrap::Alert2("Heslo musí obsahovať <br>1. Musí obsahovať aspoň jednu číslicu<br>2. Musí obsahovať aspoň jedno veľké písmeno<br>3. Musí mať minimálne 8 - 40 znakov<br>4. Povolené znaky sú len a-z A-Z 0-9", "warning");
                        }
                    } else {
                        Bootstrap::Alert2("Váš účet bol permanentne zabanovaný ! <br>Dôvod: " . user::banned_reason($ip_adress), "warning");
                    }
                }
            } else {
                Bootstrap::Alert2(Locale_Theme_21, "warning");
            }
        } else {
            if (isset($_POST["loginforms"])) {
                Bootstrap::Alert2(Locale_Theme_22, "warning");
            }
        }

        return false;
    }


    /*
    #	Login post data to login form
    */
    public static function AdminLoginPostData()
    {
        if (isset($_POST["admin_loginforms"]) && !empty($_POST["nick"]) && !empty($_POST["pass"])) {

            //All data post
            $password = Functions::EnCript($_POST["pass"]);
            $nick = trim(htmlentities($_POST["nick"]));

            //Controllers
            $db = new Framework();
            $user = new User();

            //Database
            $result = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user 
	            WHERE nick=:nick OR email=:email AND password=:password 
	            ORDER BY id DESC LIMIT 0,1");
            $result->bindParam(':password', $password);
            $result->bindParam(':nick', $nick);
            $result->bindParam(':email', $nick);
            $result->execute();

            if ($result->rowCount() > 0) {
                for ($i = 0; $row = $result->fetch(); $i++) {
                    $ip_adress = $_SERVER['REMOTE_ADDR'];
                    if (!user::banned_check($ip_adress)) {

                        //if($user->GetUserData($row["id"], "user_right") > 1){
                        $nick = $row["nick"];
                        $password = $row["password"];
                        $regex = User::regex();

                        if (preg_match($regex, Functions::DeCript($row["password"]))) {
                            if (Functions::EnCript($_POST["pass"]) == $row["password"]) {
                                if (Functions::EnCript($_POST["nick"]) == Functions::EnCript($row["nick"]) OR
                                    Functions::EnCript($_POST["nick"]) == Functions::EnCript($row["email"])
                                ) {

                                    /*
                                    #	Delete user from user online
                                    */
                                    $result23 = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user_online 
								       	WHERE `user_id`=:id");
                                    $result23->bindParam(":id", $row["id"]);
                                    $result23->execute();

                                    if ($result->rowCount() > 0) {
                                        for ($i2 = 0; $row23 = $result23->fetch(); $i2++) {
                                            if ($row23["time"] + 500 < time()) {
                                                $user_id = $row["id"];
                                                $result = $db->pdo->prepare("DELETE FROM " . DB_PREFIX . "user_online 
												    WHERE `user_id`=:id");
                                                $result->bindParam(':id', $user_id);
                                                $result->execute();
                                            }
                                        }
                                    }

                                    //Create Session
                                    $_SESSION["user_id"] = Functions::EnCript($row["id"]);
                                    $_SESSION["user_broser"] = Functions::EnCript($_SERVER['HTTP_USER_AGENT']);

                                    //Users add to online database
                                    $user = new user();
                                    $user->UsersAddOnlineDatabase($row["id"]);

                                    Header::location(WEB . DS . "admin");
                                } else {
                                    Bootstrap::Alert2("Heslo alebo nick sa nezhoduje !", "warning");
                                }
                            } else {
                                Bootstrap::Alert2("Heslo sa nezhoduje !", "warning");
                            }
                        } else {
                            Bootstrap::Alert2("Heslo musí obsahovať <br>1. Musí obsahovať aspoň jednu číslicu<br>2. Musí obsahovať aspoň jedno veľké písmeno<br>3. Musí mať minimálne 8 - 40 znakov<br>4. Povolené znaky sú len a-z A-Z 0-9", "warning");
                        }
                        /*}else{
                            Bootstrap::Alert2("Nemáte dostatočné práva", "warning");
                        }*/
                    } else {
                        Bootstrap::Alert2("Váš účet bol permanentne zabanovaný ! <br>Dôvod: " . user::banned_reason($ip_adress), "warning");
                    }
                }
            } else {
                Bootstrap::Alert2(Locale_Theme_21, "warning");
            }
        } else {
            if (isset($_POST["loginforms"])) {
                Bootstrap::Alert2(Locale_Theme_22, "warning");
            }
        }

        return false;
    }


    /*
    #	Register user
    */
    public static function user_register()
    {
        //Controllers
        $db = new Framework();
        $user = new User();
        $error = 0;
        if (isset($_POST["submit"]) && !empty($_POST["nick"]) && !empty($_POST["email"]) && !empty($_POST["email_check"])
            && !empty($_POST["password"]) && !empty($_POST["password_check"])
        ) {
            if (!user::banned_check($_SERVER['HTTP_USER_AGENT'])) {
                if ($_POST["email"] == $_POST["email_check"]) {
                    if (Functions::EnCript($_POST["password"]) == Functions::EnCript($_POST["password_check"])) {
                        $regex = User::regex();
                        $nick = $_POST["nick"];
                        $pass = $_POST["password"];
                        if (preg_match($regex, $pass)) {

                            $regex = "/[a-zA-Z0-9]{3,30}$/";
                            if (preg_match($regex, $nick)) {

                                $result2 = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user 
								WHERE nick=:nick");
                                $result2->bindParam(':nick', $nick);
                                $result2->execute();

                                $count = $result2->rowCount();

                                if ($count == NULL AND $nick !== NULL) {
                                    $email = strip_tags($_POST["email"]);
                                    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                                        $email = $_POST["email"];
                                        $result22 = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user 
										WHERE email=:email ORDER BY id DESC LIMIT 0,1");
                                        $result22->bindParam(':email', $email);
                                        $result22->execute();

                                        $count = $result22->rowCount();

                                        if ($count == NULL AND $email !== NULL) {
                                            for ($i = 0; $row23 = $result22->fetch(); $i++) {
                                                $email = str_replace(".", "", $_POST["email"]);
                                                $email2 = str_replace(".", "", $row23["email"]);

                                                if ($email == $email2) {
                                                    $error = 1;
                                                }
                                            }

                                            if ($error == 0) {
                                                $result22 = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user");
                                                $result22->execute();
                                                $register_count_user = $result22->rowCount();

                                                //Transform
                                                $nick = strip_tags($_POST["nick"]);
                                                $password = Functions::EnCript($_POST["password"]);
                                                $email = strip_tags($_POST["email"]);
                                                $ip = $_SERVER['REMOTE_ADDR'];
                                                $avatar = "noavatar.png";
                                                $user_group = "0";
                                                $user_right = "0";
                                                $facebook_profile = "0";
                                                $facebook_id = "0";
                                                $facebook_name = 0;
                                                $salt = "0";
                                                $id = $register_count_user + 1;

                                                $result222 = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user 
															WHERE id=:id");
                                                $result222->bindParam(":id", $id);
                                                $result222->execute();

                                                if ($result222->rowCount() > 0) {
                                                    for ($i = 0; $row = $result222->fetch(); $i++) {
                                                        $id = time();
                                                    }
                                                } else {
                                                    $id = $register_count_user + 1;
                                                }

                                                $result = $db->pdo->prepare("INSERT INTO " . DB_PREFIX . "user (
                                                    `id`, 
                                                    `nick`, 
                                                    `password`, 
                                                    `email`, 
                                                    `ip`, 
                                                    `avatar`, 
                                                    `user_group`, 
                                                    `user_right`, 
                                                    `time_register`, 
                                                    `latest_logged`, 				
                                                    `facebook_profile`, 
                                                    `facebook_id`, 
                                                    `facebook_name`, 
                                                    `salt`
                                                    ) VALUES (
                                                    :id, 
                                                    :nick, 
                                                    :password, 
                                                    :email, 
                                                    :ip, 
                                                    :avatar, 
                                                    :usergroup, 
                                                    :userright, 
                                                    CURRENT_TIMESTAMP, 
                                                    CURRENT_TIMESTAMP, 
                                                    :facebookprofile, 
                                                    :facebookid, 
                                                    :facebookname, 
                                                    :salt);
												");
                                                $result->bindParam(':nick', $nick);
                                                $result->bindParam(':password', $password);
                                                $result->bindParam(':email', $email);
                                                $result->bindParam(':ip', $ip);
                                                $result->bindParam(':avatar', $avatar);
                                                $result->bindParam(':usergroup', $user_group);
                                                $result->bindParam(':userright', $user_right);
                                                $result->bindParam(':facebookprofile', $facebook_profile);
                                                $result->bindParam(':facebookid', $facebook_id);
                                                $result->bindParam(':facebookname', $facebook_name);
                                                $result->bindParam(':salt', $salt);
                                                $result->bindParam(':id', $id);
                                                $result->execute();

                                                //Add registration
                                                $user->data_registration($id);

                                                Bootstrap::Alert("Bol si úspešne zaregistrovaný", "success");


                                            } else {
                                                Bootstrap::Alert("Zadaný email sa už nachádza v databáze !", "warning");
                                            }

                                        } else {
                                            Bootstrap::Alert("Zadaný email sa už nachádza v databáze !", "warning");
                                        }
                                    } else {
                                        Bootstrap::Alert("Zadaný email nieje valídny !", "warning");
                                    }
                                } else {
                                    Bootstrap::Alert("Tykýto nick sa v našej databáze už nachádza", "warning");
                                }
                            } else {
                                Bootstrap::Alert("Nick musí obsahovať minimálne 3 - 30 znakov a môže obsahovať len a-zA-Z0-9", "warning");
                            }
                        } else {
                            Bootstrap::Alert("Heslo musí obsahovať <br>1. Musí obsahovať aspoň jednu číslicu<br>2. Musí obsahovať aspoň jedno veľké písmeno<br>3. Musí mať minimálne 8 - 40 znakov<br>4. Povolené znaky sú len a-z A-Z 0-9", "warning");
                        }
                    } else {
                        Bootstrap::Alert("Heslá sa nezhodujú", "warning");
                    }
                } else {
                    Bootstrap::Alert("Email sa nezhoduje", "warning");
                }
            } else {
                Bootstrap::Alert("Bohužiaľ vaša ip má BAN", "warning");
            }
        } else {
            Bootstrap::Alert("Všetky údaje sú povinné", "warning");
        }

        return false;
    }

    /*
    #
    */
    public function delete_user_online_database($id)
    {
        $result = $this->pdo->prepare("DELETE FROM " . DB_PREFIX . "user_online WHERE user_id=:id");
        $result->bindParam(':id', $id);
        $result->execute();
    }

    /*
    #	Logout users
    */
    public function Logout()
    {

        $id = $this->me_id();
        $this->delete_user_online_database($id);


        session_destroy();

        Header::Location(WEB);

        exit();
    }

    /*
    #	Admin Logout users
    */
    public function AdminLogout()
    {

        $id = $this->me_id();
        $this->delete_user_online_database($id);

        session_destroy();

        Header::Location(WEB . DS . "admin");

        exit();
    }


    /*
    #	GET LOGGED USER
    */
    public function isLoggedIn()
    {
        //Controllers
        $user = new User();

        $sessions = $this->me_id();
        $get_user_id = $user->GetUserData($sessions, "id");

        //Database
        $result = $this->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user WHERE id=:id ORDER BY id DESC LIMIT 0,1");
        $result->bindParam(':id', $get_user_id);
        $result->execute();

        $count = $result->rowCount();

        if ($count > 0) {
            if (Functions::DeCript($_SESSION["user_broser"]) == $_SERVER['HTTP_USER_AGENT']) {
                if (isset($_SESSION['user_id'])) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    /*
    #	LOAD DATA FROM USER DATABASE
    */
    public function GetUserData2($id, $row)
    {
        $user_db233 = $this->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user_data WHERE gets=:id");
        $user_db233->bindParam(':id', $id);
        $user_db233->execute();

        if ($user_db233->rowCount() > 0) {
            for ($i = 0; $user_data = $user_db233->fetch(); $i++) {
                return $user_data[$row];
            }
        } else {
            return false;
        }
    }

    /*
    #	LOAD DATA FROM USER DATABASE
    */
    public function GetUserData($id, $row)
    {
        //Controllers
        $user_db233 = $this->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user WHERE facebook_id=:id OR id=:id");
        $user_db233->bindParam(':id', $id);
        $user_db233->execute();


        if ($user_db233->rowCount() > 0) {
            for ($i = 0; $user_data = $user_db233->fetch(); $i++) {
                //Avatar
                if ($row == "avatar") {
                    $no_avatar = WEB . "/media/img/avatar/noavatar.png";
                    $avatar = WEB . "/media/img/avatar/" . $user_data["avatar"];

                    if ($user_data["avatar"] == NULL) {
                        return $no_avatar;
                    } else {
                        $path = ROOT . DS . "www" . DS . "media" . DS . "img" . DS . "avatar" . DS . $user_data["avatar"];

                        if (file_exists($path)) {
                            return $avatar;
                        } else {
                            $url = "//graph.facebook.com/" . $user_data["facebook_id"] . "/picture?type=large";

                            if ($user_data["facebook_profile"] !== 0) {
                                return $url;
                            } else {
                                return $no_avatar;
                            }
                        }
                    }
                } elseif ($row == "nick") {
                    if ($user_data["nick"] !== NULL) {
                        return $user_data["nick"];
                    } else {
                        return $user_data["facebook_name"];
                    }
                } else {
                    if ($user_data[$row] == NULL) {
                        //Row no exist
                        return false;
                    } else {
                        return $user_data[$row];
                    }
                }
            }
        } else {
            return false;
        }
    }

    /*
    #	Users Status
    */
    public function get_user_status($id)
    {
        $user = new User();
        $time = time();

        $query = $this->pdo->prepare("SELECT * FROM " . DB_PREFIX . "user_online WHERE user_id=:id ORDER BY id DESC LIMIT 0,1");
        $query->bindParam(':id', $id);
        $query->execute();

        if ($query->rowCount() > 0) {
            for ($i = 0; $row = $query->fetch(); $i++) {
                if ($row["time"] + 100 > $time) {
                    echo "<span class='green'>" . Locale_Theme_24 . "</span>";
                } elseif ($row["time"] + 500 > $time) {
                    echo "<span class='orange'>" . Locale_Theme_25 . "</span>";
                } else {
                    echo "<span class='red'>" . Locale_Theme_23 . "</span>";
                }
            }
        } else {
            echo "<span class='red'>" . Locale_Theme_23 . "</span>";
        }

        return false;
    }
}