<?php

Class Template
{

    /*
    # Head Tag and check update
    */
    public static function head_tag()
    {

        /*
         * Load Template presenter
         * With meta tag
         */
        Presenter::loading_presenter("Template");

        /*
         * Check update for framework
         */
        Framework::updateFrameworkVersion();
    }

    /*
    #	Footer static end
    */
    public static function footer()
    {

        /*
         * Lood font with url
         */
        ?>
        <style>
            @font-face {
                font-family: 'FontAwesome';
                src: url('<? echo WEB; ?>/media/fonts/fontawesome-webfont.eot?v=4.6.3');
                src: url('<? echo WEB; ?>/media/fonts/fontawesome-webfont.eot?#iefix&v=4.6.3') format('embedded-opentype'),
                url('<? echo WEB; ?>/media/fonts/fontawesome-webfont.woff2?v=4.6.3') format('woff2'),
                url('<? echo WEB; ?>/media/fonts/fontawesome-webfont.woff?v=4.6.3') format('woff'),
                url('<? echo WEB; ?>/media/fonts/fontawesome-webfont.ttf?v=4.6.3') format('truetype'),
                url('<? echo WEB; ?>/media/fonts/fontawesome-webfont.svg?v=4.6.3#fontawesomeregular') format('svg');
            }

            @font-face {
                font-family: 'Glyphicons Halflings';
                src: url("<? echo WEB; ?>/media/fonts/glyphicons-halflings-regular.eot");
                src: url("<? echo WEB; ?>/media/fonts/glyphicons-halflings-regular.eot?#iefix") format('embedded-opentype'),
                url("<? echo WEB; ?>/media/fonts/glyphicons-halflings-regular.woff2") format('woff2'),
                url("<? echo WEB; ?>/media/fonts/glyphicons-halflings-regular.woff") format('woff'),
                url("<? echo WEB; ?>/media/fonts/glyphicons-halflings-regular.ttf") format('truetype'),
                url("<? echo WEB; ?>/media/fonts/glyphicons-halflings-regular.svg#glyphicons_halflingsregular") format('svg')
            }
        </style><?


        /*
         * Require script
         */
        echo "<script src='" . WEB . "/media/js/npm.min.js' type='text/javascript' async></script>";
        echo "<script src='" . WEB . "/media/js/jquery-v1.12.4.min.js' type='text/javascript'></script>";
        echo "<script src='" . WEB . "/media/js/bootstrap.min.js' type='text/javascript'></script>";

        $user = new User();
        if ($user->isLoggedIn()) {
            echo '<script type="text/javascript">function count(){$("#user-online").load("' . WEB . '/ajax/user-online.php");}var auto_refresh = setInterval(count, 500);count();</script>';
            echo "<div id='user-online'></div>";
        }

        //Loading CSS
        ?>
        <script>var loadDeferredStyles = function () {
                var e = document.getElementById("deferred-styles"), t = document.createElement("div");
                t.innerHTML = e.textContent, document.body.appendChild(t), e.parentElement.removeChild(e)
            }, raf = requestAnimationFrame || mozRequestAnimationFrame || webkitRequestAnimationFrame || msRequestAnimationFrame;
            raf ? raf(function () {
                window.setTimeout(loadDeferredStyles, 0)
            }) : window.addEventListener("load", loadDeferredStyles);</script><?

        session_write_close();

        exit();
    }

    /*
    #	Check left panel
    */
    public static function Left_panel_check()
    {
        $db = new Framework();

        $enbl = 1;
        $content = 1;
        $lol = 0;

        /*
         * Connect with database _panel
         */
        $query = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "panel WHERE content=:content AND enabled=:enabled ORDER BY numer ASC");
        $query->bindParam(":content", $content);
        $query->bindParam(":enabled", $enbl);
        $query->execute();

        if ($query->rowCount() > 0) {
            for ($i = 0; $row = $query->fetch(); $i++) {
                if ($row["active"] == 1) {

                    $urls = new Simpleurl("home");

                    $pole = explode(",", $row["enabled_panel"]);

                    foreach ($pole as $cast) {
                        if ($row["sub_enabled"] == 0) {
                            if ($cast == "all" OR $cast == "/all") {
                                $lol++;
                            } else if ($urls->segment(1) == $cast AND $urls->segment(2) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) == $cast AND $urls->segment(3) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) == $cast AND $urls->segment(4) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) == $cast AND $urls->segment(5) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) . "/" . $urls->segment(5) == $cast AND $urls->segment(6) == NULL) {
                                $lol++;
                            } else {
                                $lol = 0;
                            }
                        } else {
                            if ($cast == "all" OR $cast == "/all") {
                                $lol++;
                            } else if ($urls->segment(1) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) . "/" . $urls->segment(5) == $cast) {
                                $lol++;
                            } else {
                                $lol = 0;
                            }
                        }
                    }

                    if ($lol > 0) {
                        $pole = explode(",", $row["enabled_panel"]);
                        $path = ROOT . DS . 'www' . DS . 'aps' . DS . $row["name_panel"] . DS . "panel.php";
                        if (file_exists($path)) {
                            return true;
                        } else if ($row["content2"] !== NULL) {
                            return true;
                        }
                    }
                }
            }
        } else {
            return false;
        }
    }


    /*
    #	Content Left Panel
    */
    public static function Left_panel()
    {
        $db = new Framework();

        $enbl = 1;
        $content = 1;
        $lol = 0;

        //Database connect
        $query = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "panel WHERE content=:content AND enabled=:enabled ORDER BY numer ASC");
        $query->bindParam(":content", $content);
        $query->bindParam(":enabled", $enbl);
        $query->execute();

        if ($query->rowCount() > 0) {
            for ($i = 0; $row = $query->fetch(); $i++) {
                if ($row["active"] == 1) {
                    $urls = new simpleurl("home");

                    $pole = explode(",", $row["enabled_panel"]);

                    foreach ($pole as $cast) {
                        if ($row["sub_enabled"] == 0) {
                            if ($cast == "all" OR $cast == "/all") {
                                $lol++;
                            } else if ($urls->segment(1) == $cast AND $urls->segment(2) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) == $cast AND $urls->segment(3) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) == $cast AND $urls->segment(4) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) == $cast AND $urls->segment(5) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) . "/" . $urls->segment(5) == $cast AND $urls->segment(6) == NULL) {
                                $lol++;
                            } else {
                                $lol = 0;
                            }
                        } else {
                            if ($cast == "all" OR $cast == "/all") {
                                $lol++;
                            } else if ($urls->segment(1) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) . "/" . $urls->segment(5) == $cast) {
                                $lol++;
                            } else {
                                $lol = 0;
                            }
                        }
                    }

                    if ($lol > 0) {
                        $pole = explode(",", $row["enabled_panel"]);
                        $path = ROOT . DS . 'www' . DS . 'aps' . DS . $row["name_panel"] . DS . "panel.php";
                        if (file_exists($path)) {
                            include_once($path);
                        } else if ($row["content2"] !== NULL) {

                            echo eval("?>" . $row["content2"] . "<?");
                            Bootstrap::close_table();
                        }
                    }

                }
            }
        }
    }

    /*
    #	Content Bottom panel
    */
    public static function Center_Bottom_panel()
    {
        $db = new Framework();

        $enbl = 1;
        $content = 3;
        $lol = 0;

        //Database connect
        $query = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "panel WHERE content=:content AND enabled=:enabled ORDER BY numer ASC");
        $query->bindParam(":content", $content);
        $query->bindParam(":enabled", $enbl);
        $query->execute();

        if ($query->rowCount() > 0) {
            for ($i = 0; $row = $query->fetch(); $i++) {
                if ($row["active"] == 1) {

                    $urls = new simpleurl("home");

                    $pole = explode(",", $row["enabled_panel"]);


                    //Povolené
                    foreach ($pole as $cast) {
                        if ($row["sub_enabled"] == 0) {
                            if ($cast == "all" OR $cast == "/all") {
                                $lol++;
                            } else if ($urls->segment(1) == $cast AND $urls->segment(2) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) == $cast AND $urls->segment(3) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) == $cast AND $urls->segment(4) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) == $cast AND $urls->segment(5) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) . "/" . $urls->segment(5) == $cast AND $urls->segment(6) == NULL) {
                                $lol++;
                            } else {
                                $lol = 0;
                            }
                        } else {
                            if ($cast == "all" OR $cast == "/all") {
                                $lol++;
                            } else if ($urls->segment(1) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) . "/" . $urls->segment(5) == $cast) {
                                $lol++;
                            } else {
                                $lol = 0;
                            }
                        }
                    }


                    if ($lol > 0) {
                        $pole = explode(",", $row["enabled_panel"]);
                        $path = ROOT . DS . 'www' . DS . 'aps' . DS . $row["name_panel"] . DS . "panel.php";
                        if (file_exists($path)) {
                            include_once($path);
                        } else if ($row["content2"] !== NULL) {

                            echo eval("?>" . $row["content2"] . "<?");

                        }
                    }


                }
            }
        }
    }

    /*
    #	Content Top panel
    */
    public static function Center_Top_panel()
    {
        $db = new Framework();

        $enbl = 1;
        $content = 2;
        $lol = 0;

        //Database connect
        $query = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "panel WHERE content=:content AND enabled=:enabled ORDER BY numer ASC");
        $query->bindParam(":content", $content);
        $query->bindParam(":enabled", $enbl);
        $query->execute();

        if ($query->rowCount() > 0) {
            for ($i = 0; $row = $query->fetch(); $i++) {
                if ($row["active"] == 1) {


                    $urls = new simpleurl("home");

                    $pole = explode(",", $row["enabled_panel"]);

                    foreach ($pole as $cast) {
                        if ($row["sub_enabled"] == 0) {
                            if ($cast == "all" OR $cast == "/all") {
                                $lol++;
                            } else if ($urls->segment(1) == $cast AND $urls->segment(2) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) == $cast AND $urls->segment(3) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) == $cast AND $urls->segment(4) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) == $cast AND $urls->segment(5) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) . "/" . $urls->segment(5) == $cast AND $urls->segment(6) == NULL) {
                                $lol++;
                            } else {
                                $lol = 0;
                            }
                        } else {
                            if ($cast == "all" OR $cast == "/all") {
                                $lol++;
                            } else if ($urls->segment(1) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) . "/" . $urls->segment(5) == $cast) {
                                $lol++;
                            } else {
                                $lol = 0;
                            }
                        }
                    }

                    if ($lol > 0) {
                        $pole = explode(",", $row["enabled_panel"]);
                        $path = ROOT . DS . 'www' . DS . 'aps' . DS . $row["name_panel"] . DS . "panel.php";
                        if (file_exists($path)) {
                            include_once($path);
                        } else if ($row["content2"] !== NULL) {
                            echo eval("?>" . $row["content2"] . "<?");
                        }
                    }


                }
            }
        }
    }


    /*
    #	Content Right Panel
    */
    public static function Right_panel()
    {
        $db = new Framework();

        $enbl = 1;
        $content = 4;
        $lol = 0;

        //Database connect
        $query = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "panel WHERE content=:content AND enabled=:enabled ORDER BY numer ASC");
        $query->bindParam(":content", $content);
        $query->bindParam(":enabled", $enbl);
        $query->execute();

        if ($query->rowCount() > 0) {
            for ($i = 0; $row = $query->fetch(); $i++) {
                if ($row["active"] == 1) {

                    $urls = new simpleurl("home");

                    $pole = explode(",", $row["enabled_panel"]);

                    foreach ($pole as $cast) {
                        if ($row["sub_enabled"] == 0) {
                            if ($cast == "all" OR $cast == "/all") {
                                $lol++;
                            } else if ($urls->segment(1) == $cast AND $urls->segment(2) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) == $cast AND $urls->segment(3) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) == $cast AND $urls->segment(4) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) == $cast AND $urls->segment(5) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) . "/" . $urls->segment(5) == $cast AND $urls->segment(6) == NULL) {
                                $lol++;
                            } else {
                                $lol = 0;
                            }
                        } else {
                            if ($cast == "all" OR $cast == "/all") {
                                $lol++;
                            } else if ($urls->segment(1) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) . "/" . $urls->segment(5) == $cast) {
                                $lol++;
                            } else {
                                $lol = 0;
                            }
                        }
                    }


                    if ($lol > 0) {
                        $pole = explode(",", $row["enabled_panel"]);
                        $path = ROOT . DS . 'www' . DS . 'aps' . DS . $row["name_panel"] . DS . "panel.php";
                        if (file_exists($path)) {
                            include_once($path);
                        } else if ($row["content2"] !== NULL) {
                            echo eval("?>" . $row["content2"] . "<?");
                        }
                    }
                }
            }
        }
    }

    /*
    #	Check left panel
    */
    public static function Right_panel_check()
    {
        $db = new Framework();

        $enbl = 1;
        $content = 4;
        $lol = 0;

        //Database connect
        $query = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "panel WHERE content=:content AND enabled=:enabled ORDER BY numer ASC");
        $query->bindParam(":content", $content);
        $query->bindParam(":enabled", $enbl);
        $query->execute();

        if ($query->rowCount() > 0) {
            for ($i = 0; $row = $query->fetch(); $i++) {
                if ($row["active"] == 1) {

                    $urls = new simpleurl("home");

                    $pole = explode(",", $row["enabled_panel"]);

                    foreach ($pole as $cast) {
                        if ($row["sub_enabled"] == 0) {
                            if ($cast == "all" OR $cast == "/all") {
                                $lol++;
                            } else if ($urls->segment(1) == $cast AND $urls->segment(2) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) == $cast AND $urls->segment(3) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) == $cast AND $urls->segment(4) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) == $cast AND $urls->segment(5) == NULL) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) . "/" . $urls->segment(5) == $cast AND $urls->segment(6) == NULL) {
                                $lol++;
                            } else {
                                $lol = 0;
                            }
                        } else {
                            if ($cast == "all" OR $cast == "/all") {
                                $lol++;
                            } else if ($urls->segment(1) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) == $cast) {
                                $lol++;
                            } else if ($urls->segment(1) . "/" . $urls->segment(2) . "/" . $urls->segment(3) . "/" . $urls->segment(4) . "/" . $urls->segment(5) == $cast) {
                                $lol++;
                            } else {
                                $lol = 0;
                            }
                        }
                    }


                    if ($lol > 0) {
                        $pole = explode(",", $row["enabled_panel"]);
                        $path = ROOT . DS . 'www' . DS . 'aps' . DS . $row["name_panel"] . DS . "panel.php";
                        if (file_exists($path)) {
                            return true;
                        } else if ($row["content2"] !== NULL) {
                            return true;
                        }
                    }
                }
            }
        } else {
            return false;
        }
    }

    /*
    #	Minifer folder
    */
    public static function minifer($text)
    {
        $buffer = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $text);
        $buffer = str_replace(': ', ':', $buffer);
        $buffer = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $buffer);

        return $buffer;
    }

}