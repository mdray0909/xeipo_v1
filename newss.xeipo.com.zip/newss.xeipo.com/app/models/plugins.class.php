<?php

Class plugins
{
    public function see_news()
    {
        $feed = new DOMDocument();
        $feed->load('http://plugins.xeipo.com/news.xml');
        $items = $feed->getElementsByTagName('channel')->item(0)->getElementsByTagName('item');

        foreach ($items as $key => $item) {
            $title = $item->getElementsByTagName('title')->item(0)->firstChild->nodeValue;
            $pubDate = $item->getElementsByTagName('pubDate')->item(0)->firstChild->nodeValue;
            $description = $item->getElementsByTagName('description')->item(0)->textContent; // textContent
            $link = $item->getElementsByTagName('link')->item(0)->textContent; // textContent
            $img = $item->getElementsByTagName('img')->item(0)->firstChild->nodeValue; // textContent

            echo "<div class='col-lg-6'>   
                    <div class='panel panel-default'>
                     <div class='panel-body'>
                     
                      <div class='col-lg-2'>
                        <img src='" . $img . "' alt='" . strip_tags($title) . "' class='img-responsive'>
                      </div>
                      <div class='col-lg-10'>
                        <h4 style='color: #21759b;text-decoration: none;font-weight: normal;font-size: 18px;line-height: 1.3;margin: 0px 0px 15px;'>" . strip_tags($title) . "</h4>
                        <p>" . strip_tags($description) . "</p>
                        <a href='" . $link . "' target='blank_'>Viac sem</a>
                      </div>
            </div>
          </div>
        </div>";


        }
    }

    public function see_plugin()
    {
        $feed = new DOMDocument();
        $feed->load('http://plugins.xeipo.com/plugins.xml');
        $items = $feed->getElementsByTagName('channel')->item(0)->getElementsByTagName('item');

        foreach ($items as $key => $item) {
            $title = $item->getElementsByTagName('title')->item(0)->firstChild->nodeValue;
            $pubDate = $item->getElementsByTagName('pubDate')->item(0)->firstChild->nodeValue;
            $description = $item->getElementsByTagName('description')->item(0)->textContent; // textContent
            $link = $item->getElementsByTagName('link')->item(0)->textContent; // textContent
            $img = $item->getElementsByTagName('img')->item(0)->firstChild->nodeValue; // textContent

            echo "<div class='col-lg-6'>   
          <div style='padding: 20px 20px 10px;background-color: #fff;border: 1px solid #dedede;display:table;margin-bottom:24px;width: 100%;'>
            <div class='row pull-left col-lg-2'>
              <img src='" . $img . "' alt='" . strip_tags($title) . "' style='width: 128px;height: 128px;'>
            </div>
            <div class='row pull-right col-lg-10'>
              <h4 style='color: #21759b;text-decoration: none;font-weight: normal;font-size: 18px;line-height: 1.3;margin: 0px 0px 15px;'>" . strip_tags($title) . "</h4>
              <p>" . strip_tags($description) . "</p>
              <a href='" . $link . "' target='blank_'>Stiahnúť</a>
            </div>
          </div>
        </div>";
        }
    }

    public static function app_enabled($name)
    {
        $db = new Framework();

        $result4 = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "addon WHERE name=:name");
        $result4->bindParam(':name', $name);
        $result4->execute();
        $row = $result4->fetch();

        if ($result4->rowCount() > 0) {
            if ($row["enabled"] == 0) {
                Header::location(WEB);
            }
        } else {
            Header::location(WEB);
        }
    }
}