<?php

Class Setup
{
    /*
    #	Normal installation
    */
    private function Installer()
    {
        $url = new simpleurl("");
        $lang = $url->segment(2);
        $page = $url->segment(3);

        //Loading
        if ($page > 0) {
            $path_lang1 = ROOT . DS . 'app' . DS . 'language' . DS . $lang . DS . "setup.php";
            $path_lang2 = ROOT . DS . 'app' . DS . 'language' . DS . $lang . DS . "global.php";
            $path_lang3 = ROOT . DS . 'app' . DS . 'language' . DS . $lang . DS . "theme.php";

            if (file_exists($path_lang1) AND file_exists($path_lang2) AND file_exists($path_lang3)) {
                include($path_lang1);
                include($path_lang2);
            }
        }

        if ($page == 1) {
            echo " <div class='container'>\n";
            echo "   <div class='pull-left'>\n";
            echo "     <span>16.6%</span>\n";
            echo "   </div>\n";
            echo "   <div class='pull-right'>\n";
            echo "     <div class='name-step'>" . $locale["setup_1"] . "</div>\n";
            echo "   </div>\n";
            echo " </div>\n";
            echo " <div class='container'>\n";
            echo "   <div class='progress'>\n";
            echo "     <div class='progress-bar' role='progressbar' aria-valuenow='33' aria-valuemin='0' aria-valuemax='100' style='width: 16.6%;'>\n";
            echo "     </div>\n";
            echo "   </div>\n";
            echo " </div>\n";
            echo " <div class='container'>\n";

            $check_arr = array(
                "media/css/bootstrap.min.css" => false,
                "media/css/setup.min.css" => false,
                "media/fonts/glyphicons-halflings-regular.eot" => false,
                "media/fonts/glyphicons-halflings-regular.svg" => false,
                "media/fonts/glyphicons-halflings-regular.ttf" => false,
                "media/fonts/glyphicons-halflings-regular.woff" => false,
                "media/fonts/glyphicons-halflings-regular.woff2" => false,
                "media/img/avatar/noavatar.png" => false,
                "media/img/other/favicon.ico" => false,
                "media/img/other/loading.png" => false,
                "media/js/bootstrap.min.js" => false,
                "media/js/npm.min.js" => false,
                "../config/config.php" => false
            );

            $write_check = true;

            foreach ($check_arr as $key => $value) {
                if (file_exists($key) && is_writable($key)) {
                    $check_arr[$key] = true;
                    @chmod($check_arr, 0777);
                } else {
                    if (file_exists($key) && function_exists("chmod") && @chmod($key, 0777) && is_writable($key)) {
                        $check_arr[$key] = true;
                        @chmod($check_arr, 0777);
                    } else {
                        $write_check = false;
                    }
                }

                echo "<div class='row'>\n";
                echo " <div class='col-lg-1 text-center'>\n";
                echo " " . ($check_arr[$key] == true ? "<span class='material-icons'>&#xE876;</span>" : "<span class='material-icons'>&#xE000;</span>") . "\n";
                echo " </div>\n";
                echo " <div class='col-lg-11'>" . $key . "</div>\n";
                echo "</div>\n";
            }

            echo "</div>\n";


            if ($write_check) {
                echo "   <div class='container'>\n";
                echo "   <div class='row'>\n";
                echo "    <div class='col-lg-12 text-right'>\n";
                echo "     <a href='" . WEB . "/setup/" . $lang . "/0' class='rssf2'><span class='material-icons'>&#xE045;</span></a>\n";
                echo "     <a href='" . WEB . "/setup/" . $lang . "/2' class='rssf2'><span class='material-icons'>&#xE044;</span></a>\n";
                echo "    </div>\n";
                echo "   </div>\n";
                echo "   </div>\n";

                $_SESSION["step"] = 2;
            } else {
                echo "   <div class='container'>\n";
                echo "   <div class='row'>\n";
                echo "    <div class='col-lg-12 text-right'>\n";
                echo "     <a href='" . WEB . "/setup/" . $lang . "/0' class='rssf2'><span class='material-icons'>&#xE045;</span></a>\n";
                echo "     <a href='#' class='rssf3'><span class='material-icons'>&#xE044;</span></a>\n";
                echo "    </div>\n";
                echo "   </div>\n";
                echo "   </div>\n";
            }
        } else if ($page == 2) {
            if ($_SESSION["step"] == 2) {
                echo " <div class='container'>\n";
                echo "   <div class='pull-left'>\n";
                echo "     <span>33.2%</span>\n";
                echo "   </div>\n";
                echo "   <div class='pull-right'>\n";
                echo "     <div class='name-step'>" . $locale["setup_2"] . "</div>\n";
                echo "   </div>\n";
                echo " </div>\n";
                echo " <div class='container'>\n";
                echo "   <div class='progress'>\n";
                echo "     <div class='progress-bar' role='progressbar' aria-valuenow='33' aria-valuemin='0' aria-valuemax='100' style='width: 33.2%;'>\n";
                echo "     </div>\n";
                echo "   </div>\n";
                echo " </div>\n";

                if (isset($_POST["submit"])) {
                    if (!empty($_POST["hosting"]) && !empty($_POST["db_user"]) && !empty($_POST["db_pass"]) && !empty($_POST["db_name"])) {

                        //Spojenie prešlo velmi fajn :D
                        $_SESSION["db_host"] = $_POST["hosting"];
                        $_SESSION["db_user"] = $_POST["db_user"];
                        $_SESSION["db_pass"] = $_POST["db_pass"];
                        $_SESSION["db_name"] = $_POST["db_name"];
                        $_SESSION["db_prefix"] = rand(10000, 90000) . "_";
                        $_SESSION["step"] = 3;

                        try {
                            $db = new pdo('mysql:host=' . $_SESSION["db_host"] . ';dbname=' . $_SESSION["db_name"] . '', $_SESSION["db_user"], $_SESSION["db_pass"]);
                            $prefix = $_SESSION["db_prefix"];

                            $query = $db->prepare("SET CHARACTER SET utf8");
                            $query->execute();

                            $pdo = $database->db;

                            echo " <div class='container rssf2'>\n";
                            echo "  <div class='row'>\n";
                            echo "   <div class='alert fade in' role='alert'> \n";
                            echo "    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>\n";
                            echo "    <span aria-hidden='true'>×</span></button> \n";
                            echo "    <strong>" . $locale["setup_9"] . "</strong>\n";
                            echo "   </div>\n";
                            echo "  </div>\n";
                            echo " </div>\n";

                            Header::location(WEB . "/setup/" . $lang . "/3");
                        } catch (PDOException $e) {
                            echo " <div class='container rssf2'>\n";
                            echo "  <div class='row'>\n";
                            echo "   <div class='alert fade in' role='alert'> \n";
                            echo "    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>\n";
                            echo "    <span aria-hidden='true'>×</span></button> \n";
                            echo "    <strong>" . $locale["setup_8"] . "</strong>\n";
                            echo "   </div>\n";
                            echo "  </div>\n";
                            echo " </div>\n";
                        }
                    } else {
                        echo " <div class='container rssf2'>\n";
                        echo "  <div class='row'>\n";
                        echo "   <div class='alert fade in' role='alert'> \n";
                        echo "    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>\n";
                        echo "    <span aria-hidden='true'>×</span></button> \n";
                        echo "    <strong>" . $locale["setup_7"] . "</strong>\n";
                        echo "   </div>\n";
                        echo "  </div>\n";
                        echo " </div>\n";
                    }
                }


                if (!empty($_POST["hosting"])) {
                    $hostings = $_POST["hosting"];
                } else {
                    $hostings = NULL;
                }
                if (!empty($_POST["db_user"])) {
                    $db_users = $_POST["db_user"];
                } else {
                    $db_users = NULL;
                }
                if (!empty($_POST["db_pass"])) {
                    $db_pass = $_POST["db_pass"];
                } else {
                    $db_pass = NULL;
                }
                if (!empty($_POST["db_name"])) {
                    $db_name = $_POST["db_name"];
                } else {
                    $db_name = NULL;
                }


                echo "<form method='post' action='#'>\n";
                echo " <div class='container rssf2'>\n";
                echo "  <div class='row'>\n";
                echo "   <div class='col-lg-12'>\n";
                echo "    <div class='input-group test3'>\n";
                echo "     <input type='text' class='form-control' placeholder='" . $locale["setup_3"] . "' value='" . $hostings . "' name='hosting' aria-describedby='hosting'>\n";
                echo "    </div>\n";
                echo "    <div class='input-group test2'>\n";
                echo "     <input type='text' class='form-control' placeholder='" . $locale["setup_4"] . "' value='" . $db_users . "' name='db_user'  aria-describedby='db_user'>\n";
                echo "    </div>\n";
                echo "    <div class='input-group test2'>\n";
                echo "     <input type='password' class='form-control' placeholder='" . $locale["setup_5"] . "' value='" . $db_pass . "' name='db_pass'  aria-describedby='db_pass'>\n";
                echo "    </div>\n";
                echo "    <div class='input-group test2'>\n";
                echo "     <input type='text' class='form-control' placeholder='" . $locale["setup_6"] . "' value='" . $db_name . "' name='db_name'  aria-describedby='db_name'>\n";
                echo "    </div>\n";
                echo "    <div class='input-group test2'>\n";
                echo "     <input type='text' class='form-control' placeholder='prefix' value='" . rand(10000, 90000) . "_' name='db_prefix'  aria-describedby='db_prefix' disabled>\n";
                echo "    </div>\n";
                echo "   </div>\n";
                echo "  </div>\n";
                echo "  </div>\n";
                echo "  <div class='container'>\n";
                echo "   <div class='row'>\n";
                echo "    <div class='col-lg-12 text-right'>\n";
                echo "     <a href='" . WEB . "/setup/" . $lang . "/1' class='rssf2'><span class='material-icons'>&#xE045;</span></a>\n";
                echo "     <button type='submit' name='submit' class='rssf4'>\n";
                echo "      <span class='material-icons'>&#xE044;</span>\n";
                echo "     </button>\n";
                echo "    </div>\n";
                echo "   </div>\n";
                echo "  </div>\n";
                echo " </div>\n";
                echo "</form>\n";
            } else {
                Header::location(WEB . "/setup/" . $lang . "/1");
            }
        } else if ($page == 3) {
            if ($_SESSION["step"] == 3) {
                $_SESSION["step"] = 4;

                echo " <div class='container'>\n";
                echo "  <div class='pull-left'>\n";
                echo "   <span>49.8%</span>\n";
                echo "  </div>\n";
                echo "  <div class='pull-right'>\n";
                echo "   <div class='name-step'>" . $locale["setup_1"] . "</div>\n";
                echo "  </div>\n";
                echo " </div>\n";
                echo " <div class='container'>\n";
                echo "  <div class='progress'>\n";
                echo "   <div class='progress-bar' role='progressbar' aria-valuenow='33' aria-valuemin='0' aria-valuemax='100' style='width: 49.8%;'>\n";
                echo "  </div>\n";
                echo " </div>\n";
                echo " <div class='container rssf2'>\n";
                echo "  <div class='text-center rssf5'>\n";
                echo "   <img src='" . WEB . "/media/img/other/loading.png' alt='loading...'>\n";
                echo "  </div>\n";
                echo " </div>\n";

                Header::refresh(WEB . "/setup/" . $lang . "/4", 4);
            } else {
                Header::location(WEB . "/setup/" . $lang . "/2");
            }
        } else if ($page == 4) {
            if ($_SESSION["step"] == 4) {
                echo " <div class='container'>\n";
                echo "  <div class='pull-left'>\n";
                echo "   <span>66.4%</span>\n";
                echo "  </div>\n";
                echo "  <div class='pull-right'>\n";
                echo "   <div class='name-step'>" . $locale["setup_10"] . "</div>\n";
                echo "  </div>\n";
                echo " </div>\n";
                echo " <div class='container'>\n";
                echo "  <div class='progress'>\n";
                echo "   <div class='progress-bar' role='progressbar' aria-valuenow='66' aria-valuemin='0' aria-valuemax='100' style='width: 66.4%;'></div>\n";
                echo "  </div>\n";
                echo " </div>\n";

                if (isset($_POST["user_submit"])) {
                    if (!empty($_POST["user_nick"]) && !empty($_POST["email"]) && !empty($_POST["user_pass"]) && !empty($_POST["user_pass2"])) {

                        if ($_POST["user_pass"] == $_POST["user_pass2"]) {
                            //Spojenie prešlo velmi fajn :D
                            $_SESSION["user_nick"] = $_POST["user_nick"];
                            $_SESSION["user_email"] = $_POST["email"];
                            $_SESSION["user_pass"] = Functions::EnCript($_POST["user_pass"]);
                            $_SESSION["step"] = 5;

                            echo " <div class='container'>\n";
                            echo "  <div class='row'>\n";
                            echo "   <div class='alert fade in' role='alert'> \n";
                            echo "    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>\n";
                            echo "    <span aria-hidden='true'>×</span></button> \n";
                            echo "    <strong>" . $locale["setup_11"] . "</strong>\n";
                            echo "   </div>\n";
                            echo "  </div>\n";
                            echo " </div>\n";
                        } else {
                            echo " <div class='container'>\n";
                            echo "  <div class='row'>\n";
                            echo "   <div class='alert fade in' role='alert'> \n";
                            echo "    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>\n";
                            echo "    <span aria-hidden='true'>×</span></button> \n";
                            echo "    <strong>" . $locale["setup_12"] . "</strong>\n";
                            echo "   </div>\n";
                            echo "  </div>\n";
                            echo " </div>\n";
                        }
                    } else {
                        echo " <div class='container'>\n";
                        echo "  <div class='row'>\n";
                        echo "   <div class='alert fade in' role='alert'> \n";
                        echo "    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>\n";
                        echo "    <span aria-hidden='true'>×</span></button> \n";
                        echo "    <strong>" . $locale["setup_7"] . "</strong>\n";
                        echo "   </div>\n";
                        echo "  </div>\n";
                        echo " </div>\n";
                    }
                }

                echo "  <form method='post' action='#'>\n";
                echo "   <div class='container rssf2'>\n";
                echo "    <div class='row'>\n";
                echo "     <div class='col-lg-12'>\n";
                echo "      <div class='input-group test3'>\n";
                echo "       <input type='text' class='form-control' placeholder='" . $locale["setup_14"] . "' value='' name='user_nick' aria-describedby='user_nick'>\n";
                echo "      </div>\n";
                echo "      <div class='input-group test2'>\n";
                echo "       <input type='email' class='form-control' placeholder='" . $locale["setup_15"] . "' value='' name='email' aria-describedby='email'>\n";
                echo "      </div>\n";
                echo "      <div class='input-group test2'>\n";
                echo "       <input type='password' class='form-control' placeholder='" . $locale["setup_16"] . "' value='' name='user_pass' aria-describedby='user_pass'>\n";
                echo "      </div>\n";
                echo "      <div class='input-group test2'>\n";
                echo "       <input type='password' class='form-control' placeholder='" . $locale["setup_17"] . "' value='' name='user_pass2' aria-describedby='user_pass2'>\n";
                echo "      </div>\n";
                echo "     </div>\n";
                echo "    </div>\n";
                echo "   </div>\n";
                echo "   <div class='container'>\n";
                echo "    <div class='row'>\n";
                echo "     <div class='col-lg-12 text-right'>\n";
                echo "      <a href='" . WEB . "/setup/" . $lang . "/1' class='rssf2'><span class='material-icons'>&#xE045;</span></a>\n";
                echo "      <button type='submit' name='user_submit' class='rssf4'>\n";
                echo "       <span class='material-icons'>&#xE044;</span>\n";
                echo "      </button>\n";
                echo "     </div>\n";
                echo "    </div>\n";
                echo "   </div>\n";
                echo "  </form>\n";

                if (isset($_POST["user_submit"])) {
                    if (!empty($_POST["user_nick"]) && !empty($_POST["email"]) && !empty($_POST["user_pass"]) && !empty($_POST["user_pass2"])) {
                        if ($_POST["user_pass"] == $_POST["user_pass2"]) {
                            Header::refresh(WEB . "/setup/" . $lang . "/5", 3);
                        }
                    }
                }
            } else {
                Header::location(WEB . "/setup/" . $lang . "/3");
            }
        } else if ($page == 5) {
            if ($_SESSION["step"] == 5) {
                echo " <div class='container'>\n";
                echo "  <div class='pull-left'>\n";
                echo "   <span>83%</span>\n";
                echo "  </div>\n";
                echo "  <div class='pull-right'>\n";
                echo "   <div class='name-step'>" . $locale["setup_18"] . "</div>\n";
                echo "  </div>\n";
                echo " </div>\n";
                echo " <div class='container rssf2'>\n";
                echo "  <div class='progress'>\n";
                echo "   <div class='progress-bar' role='progressbar' aria-valuenow='83' aria-valuemin='0' aria-valuemax='100' style='width: 83%;'></div>\n";
                echo "  </div>\n";
                echo " </div>\n";
                echo " <div class='container rssf8'>\n";
                echo "  <h2>" . $locale["setup_19"] . "</h2>\n";
                echo "  <small>" . $locale["setup_20"] . "</small>\n";
                echo " </div>\n";
                echo " <form method='post' action='#'>\n";
                echo "  <div class='container rssf2'>\n";
                echo "   <div class='rules'>\n";
                echo "    <small>" . $locale["setup_21"] . "</small> \n";
                echo "   </div>\n";
                echo "  </div>\n";
                echo "  <div class='container'>\n";
                echo "   <div class='row'>\n";
                echo "    <div class='col-lg-12 text-right'>\n";
                echo "     <button type='submit' name='step4' class='rssf4'>\n";
                echo "      <span class='material-icons'>&#xE044;</span>\n";
                echo "     </button>\n";
                echo "    </div>\n";
                echo "   </div>\n";
                echo "  </div>\n";
                echo " </form>\n";

                if (isset($_POST["step4"])) {
                    $_SESSION["step"] = 6;

                    Header::location(WEB . "/setup/" . $lang . "/6");
                }
            } else {
                Header::location(WEB . "/setup/" . $lang . "/4");
            }
        } else if ($page == 6) {
            if ($_SESSION["step"] == 6) {
                echo " <div class='container'>\n";
                echo "  <div class='pull-right'>\n";
                echo "   <div class='name-step'>" . $locale["setup_22"] . "</div>\n";
                echo "  </div>\n";
                echo " </div>\n";
                echo " <div class='container rssf2'>\n";
                echo "  <div class='text-center rssf5'>\n";
                echo "   <img src='" . WEB . "/media/img/other/loading.png' alt='loading...'>\n";
                echo "  </div>\n";
                echo "  <div class='text-center rssf7'>\n";
                echo "   <h3 class='rssf6'>" . $locale["setup_23"] . "</h3>\n";
                echo "   <small class='rssf6'>" . $locale["setup_24"] . " <a href='www.xeipo.com' class='rssf6'>xeipo.com</a></small>\n";
                echo "  </div>\n";
                echo " </div>\n";

                Setup::post_data_config($_SESSION["db_host"], $_SESSION["db_user"], $_SESSION["db_pass"], $_SESSION["db_name"], $_SESSION["db_prefix"]);

                echo " <div class='container'>\n";
                echo "  <div class='row'>\n";
                echo "   <div class='col-lg-12 text-right'>\n";
                echo "    <a href='" . WEB . "' class='rssf2'>" . $locale["setup_25"] . " <span class='material-icons'>&#xE044;</span></a>\n";
                echo "   </div>\n";
                echo "  </div>\n";
                echo " </div>\n";

                session_destroy();

                Header::refresh(WEB, 6);
            } else {
                Header::location(WEB . "/setup/" . $lang . "/5");
            }
        } else {
            echo " <div class='container'>\n";
            echo "  <div class='pull-left'>\n";
            echo "    <span>0.0%</span>\n";
            echo "  </div>\n";
            echo " </div>\n";
            echo " <div class='container'>\n";
            echo "  <div class='progress'>\n";
            echo "   <div class='progress-bar' role='progressbar' aria-valuenow='0' aria-valuemin='0' aria-valuemax='100' style='width: 0%;'></div>\n";
            echo "  </div>\n";
            echo " </div>\n";
            echo " <div class='container'>\n";

            Setup::lang_include();

            echo " </div>\n";
        }
    }


    public static function post_data_config($db_host, $db_user, $db_password, $db_name, $db_prefix)
    {

        try {

            $url = new simpleurl("");
            $lang = $url->segment(2);

            $db2 = new pdo('mysql:host=' . $db_host . ';dbname=' . $db_name . '', $db_user, $db_password);
            $query = $db2->prepare("SET CHARACTER SET utf8");
            $query->execute();

            $config_file = ROOT . DS . 'config' . DS . 'config.php';

            $config = "<?php\n\n";
            $config .= "define('DB_HOST', 	 	'" . $db_host . "');	\n";
            $config .= "define('DB_USER', 	 	'" . $db_user . "');	\n";
            $config .= "define('DB_PASSWORD', 	'" . $db_password . "');	\n";
            $config .= "define('DB_NAME', 	 	'" . $db_name . "');	\n";
            $config .= "define('DB_PREFIX', 	'" . $db_prefix . "');	\n\n";
            $config .= "?>";

            $temp = fopen($config_file, "w");
            if (fwrite($temp, $config)) {
                fclose($temp);

                $sql = "CREATE TABLE IF NOT EXISTS `" . $db_prefix . "addon` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `name` varchar(255) COLLATE utf8_slovak_ci NOT NULL,
				  `enabled` int(1) NOT NULL DEFAULT '0'
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "api_settings` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `value` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "articles` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `text` text CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `description` text CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `autor` int(30) NOT NULL,
				  `time_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
				  `time_add` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
				  `image` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `url_image` int(2) NOT NULL,
				  `read` bigint(20) NOT NULL DEFAULT '0',
				  `cat` int(11) NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "articles_category` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `name_cat` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "banned` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `autor` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `reason` text CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "comment` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `autor` varchar(255) COLLATE utf8_slovak_ci NOT NULL DEFAULT '0',
				  `massage` text COLLATE utf8_slovak_ci NOT NULL,
				  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
				  `gets` varchar(255) COLLATE utf8_slovak_ci NOT NULL DEFAULT '0',
				  `type` varchar(255) COLLATE utf8_slovak_ci NOT NULL DEFAULT '0',
				  `answer` varchar(255) COLLATE utf8_slovak_ci NOT NULL DEFAULT '0'
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "downloads` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `autor` int(30) NOT NULL,
				  `time_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
				  `time_add` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
				  `image` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `url_image` int(2) NOT NULL,
				  `read` bigint(20) NOT NULL DEFAULT '0',
				  `cat` int(11) NOT NULL,
				  `text` text COLLATE utf8_czech_ci NOT NULL,
				  `description` text COLLATE utf8_czech_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "downloads_category` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `name_cat` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "forum` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `autor` bigint(20) NOT NULL,
				  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `cat` bigint(20) NOT NULL,
				  `text` text CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
				  `timestamp_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
				  `read` bigint(20) NOT NULL,
				  `lock` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL DEFAULT '0'
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "forum_category` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "log` (
				  `name` text CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "massage` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `autor` bigint(20) NOT NULL,
				  `gets` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `text` text CHARACTER SET utf8 COLLATE utf8_slovak_ci
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "navigation` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `name_link` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `link` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "news` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `text` text CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `description` text CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `time_add` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
				  `time_update` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
				  `autor` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `image` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `url_image` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL DEFAULT '0',
				  `read` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL DEFAULT '0',
				  `cat` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `original_image` text COLLATE utf8_czech_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "news_category` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "notification` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `gets` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `text` text CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `autor` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `read` int(1) NOT NULL,
				  `see` int(1) NOT NULL,
				  `link` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `time_add` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				INSERT INTO `" . $db_prefix . "notification` (`id`, `gets`, `text`, `autor`, `read`, `see`, `link`, `time_add`) VALUES
				(1, '1', 'Vitaj ! na novom webe vyrobenom prostredníctvom webu xeipo.com :)', '1', 1, 1, '', '2016-10-02 19:34:32');

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "panel` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `name_panel` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `enabled` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `numer` int(11) NOT NULL,
				  `content` int(2) NOT NULL,
				  `enabled_panel` text CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `sub_enabled` int(2) NOT NULL,
				  `content2` text COLLATE utf8_czech_ci NOT NULL,
				  `active` int(1) NOT NULL,
				  `name` varchar(255) COLLATE utf8_czech_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "present` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `web` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `description` text CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `text` text CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `id_autor` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `read` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "product` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `category` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `price` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `picture` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `image_on_web` int(1) NOT NULL DEFAULT '0',
				  `autor` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `name_file` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `count_download` bigint(20) NOT NULL DEFAULT '0',
				  `visible` int(1) NOT NULL DEFAULT '1',
				  `text` mediumtext CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `buy` int(11) NOT NULL,
				  `count_product` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `disposable_product` int(1) NOT NULL,
				  `file_product` int(1) NOT NULL,
				  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `akcia` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `buy_user_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "product_category` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "rating` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `type` varchar(255) COLLATE utf8_slovak_ci NOT NULL,
				  `gets` varchar(255) COLLATE utf8_slovak_ci NOT NULL,
				  `autor` bigint(20) NOT NULL,
				  `rating` varchar(255) COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "server` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `query` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `port` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `game` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `version` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "session` (
				  `id` int(11) NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "settings` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `value` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "shoutbox` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `text` text CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `autor` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `date_add` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "support` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `gets` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `autor` bigint(20) NOT NULL,
				  `text` text CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "tagwall` (
				  `id` int(11) NOT NULL,
				  `autor` varchar(255) COLLATE utf8_czech_ci NOT NULL,
				  `massage` text COLLATE utf8_czech_ci NOT NULL,
				  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
				  `gets` varchar(255) COLLATE utf8_czech_ci NOT NULL,
				  `answer` varchar(255) COLLATE utf8_czech_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "user` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `nick` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `avatar` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `user_group` text CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `user_right` bigint(20) NOT NULL DEFAULT '0',
				  `time_register` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
				  `latest_logged` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
				  `facebook_profile` int(2) NOT NULL DEFAULT '0',
				  `facebook_id` bigint(50) DEFAULT '0',
				  `facebook_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "user_basket` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `gets` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `idproduct` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `count` int(11) NOT NULL DEFAULT '0'
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "user_buy_product` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `id_product` bigint(255) NOT NULL,
				  `id_user` bigint(255) NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "user_data` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `gets` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `skype` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci DEFAULT NULL,
				  `about_us` text CHARACTER SET utf8 COLLATE utf8_slovak_ci,
				  `web` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci DEFAULT NULL,
				  `see_email` varchar(2) COLLATE utf8_czech_ci DEFAULT '1'
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "user_group` (
				  `id` bigint(20) NOT NULL,
				  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "user_online` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `user_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `time` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `salt` text COLLATE utf8_czech_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "user_reset_pw` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
				  `status` int(1) NOT NULL DEFAULT '0',
				  `id_user` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `hash` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "user_right` (
				  `id` int(11) NOT NULL,
				  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `value` text CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "videogallery` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `description` text CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `cat` int(11) NOT NULL,
				  `date_add` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
				  `autor` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `youtube_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "videogallery_category` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `public` int(2) NOT NULL
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;

				CREATE TABLE IF NOT EXISTS `" . $db_prefix . "views` (
				  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				  `ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
				  `browser` text CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `os` text CHARACTER SET utf8 COLLATE utf8_slovak_ci NOT NULL,
				  `timestamp_update` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
				) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_slovak_ci;";


                /*
                #	Insert table
                */
                $sql .= "INSERT INTO `" . $db_prefix . "user_group` (`id`, `name`) VALUES
				(1, 'Užívateľ'),
				(2, 'VIP'),
				(3, 'Programátor'),
				(4, 'Grafik'),
				(5, 'Moderátor'),
				(6, 'Spolumajiteľ'),
				(7, 'Majiteľ');

				INSERT INTO `" . $db_prefix . "videogallery_category` (`id`, `name`, `public`) VALUES (1, 'First cats', 0);
				
				INSERT INTO `" . $db_prefix . "api_settings` (`id`, `name`, `value`) VALUES
				(1, 'GOOGLE_CAPTCHA_SITE_KEY', 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'),
				(2, 'GOOGLE_CAPTCHA_SECRET_KEY', 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'),
				(3, 'FB_LOGIN_APP_ID', 'xxxxxxxxxxxxxxx'),
				(4, 'FB_LOGIN_APP_SECRET', 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'),
				(5, 'GOOGLE_SEARCH_ID', 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'),
				(6, 'GOOGLE_ANALITICS_ID', 'xx-xxxxxxxx-x'),
				(8, 'GOOGLE_TAG_MANAGER_ID', 'xxx-xxxxxx');

				INSERT INTO `" . $db_prefix . "articles_category` (`id`, `name_cat`) VALUES
				(1, 'Kategória č1');

				INSERT INTO `" . $db_prefix . "forum_category` (`id`, `name`) VALUES
				(1, 'Toto je prvá kategória fóra');

				INSERT INTO `" . $db_prefix . "massage` (`id`, `autor`, `gets`, `text`) VALUES
				(1, 1, '1', 'skuska');

				INSERT INTO `" . $db_prefix . "news_category` (`id`, `name`) VALUES
				(1, 'First cat');

				INSERT INTO `" . $db_prefix . "product_category` (`id`, `name`) VALUES
				(1, 'First cattegory');

				INSERT INTO `" . $db_prefix . "settings` (`id`, `name`, `value`) VALUES
				(1, 'TITLE', 'Xeipo.com | Kvalitná tvorba webových stránok'),
				(2, 'TEMPLATES', 'default'),
				(3, 'DESCRIPTION', 'Ponúkame služby o vysokej kvalite, za bezkonkurenčnú cenu. Tvoríme kvalitné bezpečné a rýchle aplikácie.Jednoducho kvalitná tvorba webových (www) stránok.'),
				(4, 'KEYWORDS', 'prinášame, ponúkame, kvalitu,kvalita, bezkonkurenčná, služby, kvalitné, prinášame, vysokej, kvalite,php,html,css,javascript,Kvalitná, tvorba, webových, stránok, www stránok'),
				(5, 'CHARSET', 'UTF-8'),
				(6, 'AUTHOR', 'Jozef Vajdiar'),
				(7, 'CODER', 'R3W0LUT10N '),
				(8, 'FAVICON', 'http://xeipo.com/media/img/other/favicon.png'),
				(9, 'GRAPHICS', 'Andrej Miky Mikula'),
				(10, 'CODER_SKYPE', 'r3w0lut10n'),
				(11, 'CODER_EMAIL', 'ith1ngr@gmail.com'),
				(12, 'ROBOTS', 'index,follow'),
				(13, 'VERSION_WEB', 'v3.0.1'),
				(14, 'GRAPHICS_EMAIL', 'mikino@createx.sk'),
				(15, 'BANNED_LINK', 'https://www.google.sk/'),
				(16, 'LANG', '" . $lang . "'),
				(17, 'REGISTER_MASSAGE', 'Vitaj ! na novom webe createx.sk. Sem nájdeš svoje upozornenia :)'),
				(18, 'COUNT_ARTICLES_WHILE', '6'),
				(19, 'ALL_NOTIFICATION_POST_USER_ID', '3'),
				(20, 'ALL_NOTIFICATION_POST_USER_ID_2', '2'),
				(21, 'CONTACT_EMAIL', 'kontakt@createx.sk'),
				(22, 'CREDITS_EMAIL', 'createx@createx.sk'),
				(23, 'SUPPORT_USER_ID', '1'),
				(24, 'SUPPORT_USER_ID2', '2'),
				(25, 'ADMIN_TEMPLATES', 'admin_template'),
				(26, 'SSL_CERTIFICAT_TRUE', '0'),
				(27, 'DOMAIN_SERVER', 'xeipo.com'),
				(28, 'TITLE_NAME', 'xeipo.com'),
				(29, 'DEVELOPER_MOD', '0'),
				(30, 'ARTICLES_PAGE_PERPAGE', '6'),
				(31, 'ARTICLES_HOME_PERPAGE', '9'),
				(32, 'REGISTER_ENABLED', '1'),
				(33, 'LOGIN_USE_ALL_BROWSER', '1');

				INSERT INTO `" . $db_prefix . "user_data` (`id`, `gets`, `skype`, `about_us`, `web`, `see_email`) VALUES
				(1, '1', NULL, NULL, NULL, '1');

				INSERT INTO `" . $db_prefix . "user_right` (`id`, `name`, `value`) VALUES
				(1, 'Moderátor', 'articles-cat.articles.articles-add.comment.files.files-add.files-cat.homepage.news-add.news.news-cat.tagwall.'),
				(2, 'Spolumajiteľ', 'app.articles-cat.articles.articles-add.backup.comment.files.files-add.files-cat.global-setting.homepage.news-add.news.news-cat.panels.plugin-install.plugin.template.user.tagwall.'),
				(3, 'Majiteľ', 'app.articles-cat.articles.articles-add.backup.comment.files.files-add.files-cat.global-setting.homepage.news-add.news.news-cat.panels.plugin-install.plugin.template.user.tagwall.');

				INSERT INTO `" . $db_prefix . "user` (`id`, `nick`, `password`, `email`, `ip`, `avatar`, `user_group`, `user_right`, `time_register`, `latest_logged`, `facebook_profile`, `facebook_id`, `facebook_name`) VALUES
				(1, '" . $_SESSION["user_nick"] . "', '" . $_SESSION["user_pass"] . "', '" . $_SESSION["user_email"] . "', '" . $_SERVER["REMOTE_ADDR"] . "', 'noavatar.png', '7', 3, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 0, '', '');";


                /*
                #	Crate Index
                */
                $sql .= "";


                $db2->exec($sql);

                #Change charset
                $query = $db2->prepare("SET CHARACTER SET utf8");
                $query->execute();
            }

            if (function_exists("chmod")) {
                @chmod($config_file, 0644);
            }
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }


    public static function lang_include()
    {
        $array1 = Language::lang_define();

        echo "<div class='row'>";

        if (is_array($array1)) {
            foreach ($array1 as $array1_key => $value) {

                $path_lang1 = ROOT . DS . 'app' . DS . 'language' . DS . $array1_key . DS . "setup.php";
                $path_lang2 = ROOT . DS . 'app' . DS . 'language' . DS . $array1_key . DS . "global.php";
                $path_lang3 = ROOT . DS . 'app' . DS . 'language' . DS . $array1_key . DS . "theme.php";


                if (file_exists($path_lang1) AND file_exists($path_lang2) AND file_exists($path_lang3)) {
                    include($path_lang1);
                    include($path_lang2);

                    echo "<a href='" . WEB . "/setup/" . $array1_key . "/1' class='col-lg-12 rssf'>
			              <div class='row'>
			                <div class='col-lg-1'>
			                  <div class='bgs'>" . $array1_key . "</div>
			                </div>
			                <div class='col-lg-11 pull-right'>
			                  <div class='col-lg-12 pull-right'>
			                    <h2>" . $locale["global_0"] . "</h2>
			                    <small>" . $locale["global_1"] . "</small>
			                  </div>
			                </div>
			              </div>
			            </a>";
                }
            }
        } else {
            return false;
        }

        echo "</div>";
    }

    /*
    #	Create config.php
    */
    private function Config_No_Exist()
    {
        $path_lang = ROOT . DS . 'app' . DS . 'language' . DS . LANG . DS . 'setup.php';
        if (file_exists($path_lang)) {
            $lang = LANG;
            include($path_lang);
        } else {
            $lang = GLOBAL_LANG;
            include(ROOT . DS . 'app' . DS . 'language' . DS . GLOBAL_LANG . DS . 'setup.php');
        }

        if (isset($_POST["create_config"])) {
            $c = fopen(ROOT . DS . 'config' . DS . 'config.php', "w");
            Header::location(WEB . "/setup/" . $lang . "/0");
        }

        echo " <div class='container'>\n";
        echo "   <div class='pull-right'>\n";
        echo "     <div class='name-step'>" . $locale["setup_28"] . "</div>\n";
        echo "   </div>\n";
        echo " </div>\n";
        echo " <div class='container'>\n";
        echo "  <form method='post' action='#'>\n";
        echo "   <div class='col-lg-12 rssf8 text-center'>" . $locale["setup_26"] . "</div>\n";
        echo "   <div class='col-lg-12 text-center'>\n";
        echo "    <div class='input-group'>\n";
        echo "     <div class='input-group-btn'>\n";
        echo "      <input type='submit' name='create_config' class='btn btn-default dropdown-toggle' value='" . $locale["setup_27"] . "'>\n";
        echo "     </div>\n";
        echo "    </div>\n";
        echo "   </div>\n";
        echo "  </form>\n";
        echo " </div>\n";
    }

    /*
    #	Loading setup presenter
    */
    public static function Install()
    {
        Presenter::loading_presenter("Setup");

        exit();
    }

    /*
    #	Verification
    */
    public function Install_cms()
    {
        if (!file_exists(ROOT . DS . 'config' . DS . 'config.php')) {
            $this->Config_No_Exist();
        } else {
            $this->Installer();
        }
    }

    /*
    #	Fatall Error
    #	Loading fatal error presenter
    */
    public static function Error($err_msg, $err_code)
    {
        define("err_msg", $err_msg);
        define("err_code", $err_code);

        Presenter::loading_presenter("fatalerror");

        exit();
    }
}