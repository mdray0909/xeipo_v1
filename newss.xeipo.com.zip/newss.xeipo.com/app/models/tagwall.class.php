<?php

Class Tagwall
{

    public function __construct($type, $get)
    {
        $this->see_comment($type, $get);
    }

    public function count_comment($type, $get)
    {
        $r = Result::Tagwall_Count($type, $get);
        $count = $r->rowCount();

        echo $count;
    }

    private function see_comment($type, $get)
    {
        $this->add_comment($type, $get);
        $r = Result::See_All_Tagwall($type, $get);

        if ($r->rowCount() > 0) {
            for ($i = 0; $row = $r->fetch(); $i++) {
                $user = new User();

                $name_nick = $user->GetUserData($row["autor"], "nick");
                $avatar = $user->GetUserData($row["autor"], "avatar");
                $massage = Functions::emoticons(Functions::bbcode(htmlspecialchars($row["massage"]))); //nl2br

                echo "   <div class='media' id='comment-" . $row["id"] . "'>";
                echo "     <div class='media-left'>";
                echo "       <a href='#'>";
                echo "         <img class='media-object' src='" . $avatar . "' alt='avatar' style='width:50px;height:50px'>";
                echo "       </a>";
                echo "     </div>";
                echo "     <div class='media-body'>";


                echo "      <div class='row'>";
                echo "       <div class='col-lg-12 comment-nick'>";
                echo "        <div class='pull-left'>";
                echo "         <div class='media-heading'><a href='" . WEB . "/profil/" . $row["autor"] . "'>" . $name_nick . "</a></div>";
                echo "        </div>";

                //Delete comment
                if ($user->isLoggedIn()) {
                    if ($user->isInRole("admin") OR $row["autor"] == $user->me_id()) {
                        if (!isset($_GET["d"])) {
                            echo "       <div class='pull-right'>";
                            echo "        <div class='media-heading'><a href='" . Functions::form_action() . "/&amp;d=" . $row["id"] . "#addcomments'>X</a></div>";
                            echo "       </div>";
                        }
                    }
                }

                echo "       </div>";
                echo "      </div>";

                echo "       " . $massage . "";

                //Answer link
                if ($user->isLoggedIn()) {
                    if (!isset($_GET["u"])) {
                        echo "<div class='row'><div class='col-lg-12'><a href='" . Functions::form_action() . "/&amp;u=" . $row["id"] . "#addcomments'>Odpovedať</a></div></div>";
                    }
                }


                $answers = Result::Tagwall_answer($row["id"], $type, $get);
                for ($i = 0; $rows = $answers->fetch(); $i++) {
                    $user = new User();

                    $name_nick = $user->GetUserData($rows["autor"], "nick");
                    $avatar = $user->GetUserData($rows["autor"], "avatar");
                    $massage = Functions::emoticons(Functions::bbcode(htmlspecialchars($rows["massage"])));

                    //Answer
                    echo "   <div class='media' id='comment-" . $rows["id"] . "'>";
                    echo "     <div class='media-left'>";
                    echo "       <a href='#'>";
                    echo "         <img class='media-object' src='" . $avatar . "' alt='avatar' style='width:50px;height:50px'>";
                    echo "       </a>";
                    echo "     </div>";
                    echo "     <div class='media-body'>";

                    echo "      <div class='row'>";
                    echo "       <div class='col-lg-12 comment-nick'>";
                    echo "        <div class='pull-left'>";
                    echo "         <div class='media-heading'><a href='" . WEB . "/profil/" . $row["autor"] . "'>" . $name_nick . "</a></div>";
                    echo "        </div>";

                    //Delete comment
                    if ($user->isLoggedIn()) {
                        if ($user->isInRole("admin") OR $rows["autor"] == $user->me_id()) {
                            if (!isset($_GET["ud"])) {
                                echo "       <div class='pull-right'>";
                                echo "        <div class='media-heading'><a href='" . Functions::form_action() . "/&amp;ud=" . $rows["id"] . "#addcomments'>X</a></div>";
                                echo "       </div>";
                            }
                        }
                    }

                    echo "       </div>";
                    echo "      </div>";

                    echo "       " . $massage . "";
                    echo "     </div>";
                    echo "   </div>";
                }

                echo "     </div>";
                echo "   </div>";
            }

        } else {
            echo "<small>Nič sa nenachádza v tejto nástenke</small>";
        }
    }

    private function add_comment($type, $get)
    {
        $user = new User();
        if ($user->isLoggedIn()) {


            if (isset($_GET["u"])) {
                $answer = strip_tags($_GET["u"]);

                echo "<div id='massage'>Odpovedám na komentár č " . $answer . "!</div>";

                if (isset($_POST["u_massage"])) {
                    if (!empty($_POST["u_massage"])) {
                        if (stripslashes(strip_tags($_POST["u_massage"])) !== NULL) {
                            $db = new Framework();
                            $user = new User();

                            $massage = htmlspecialchars($_POST["u_massage"]);
                            $regex = "/[A-Za-z0-9]/";

                            if (preg_match($regex, $massage)) {
                                if (!empty($_POST["u_massage"])) {

                                    $massage = $_POST["u_massage"];
                                    $sessions = $user->me_id();
                                    $autor = $user->GetUserData($sessions, "id");

                                    $result = $db->pdo->prepare("INSERT INTO `" . DB_PREFIX . "tagwall` (`id`, `autor`, `massage`, `date`, `gets`, `answer`) VALUES (NULL, :autor, :massage, CURRENT_TIMESTAMP, :get, :answer);");
                                    $result->bindParam(":massage", $massage);
                                    $result->bindParam(":get", $get);
                                    $result->bindParam(":autor", $autor);
                                    $result->bindParam(":answer", $answer);
                                    $result->execute();

                                    $bad_entities = array("&u=" . $answer, "#addcomments");
                                    $safe_entities = array("", "");
                                    $url = Functions::form_action();
                                    $matematics = str_replace($bad_entities, $safe_entities, $url);

                                    Header::location($matematics);
                                }
                            } else {
                                Bootstrap::Alert("Správa obsahuje nepovolené znaky !");
                            }
                        } else {
                            Bootstrap::Alert("Správa obsahuje nepovolené znaky !");
                        }
                    } else {
                        Bootstrap::Alert("Správa nemôže byť prázdna !");
                    }
                }


                echo "<div class='row' id='addcomments'>";
                echo "<form action='" . Functions::form_action() . "' method='post'>";
                echo "<div class='col-lg-12'>";
                echo "<textarea id='u_massage'  class='form-control' placeholder='správa...' style='width: 100%; height: 117px;resize: vertical;overflow: auto;' maxlength='2000000' name='u_massage'></textarea>";
                echo "</div>";
                echo "<div class='col-lg-6'>";

                //BTN GROUP
                echo "<div class='btn-group'>";
                echo "<button type='button' class='btn btn-primary navbar-btn btn-sm' data-toggle='dropdown'> ";
                echo "<img alt=':)' src='" . WEB . "/media/img/emoticons/smile.png' />";
                echo "</button> ";
                echo "<ul class='dropdown-menu'> ";
                echo "<a href='#addcomments' onclick='formatText(\":)\");'><img src='" . WEB . "/media/img/emoticons/smile.png' alt=':)' class='emoticons'> </a>";
                echo "<a href='#addcomments' onclick='formatText(\":D\");'><img src='" . WEB . "/media/img/emoticons/grin.png' alt=':D' class='emoticons'> </a>";
                echo "<a href='#addcomments' onclick='formatText(\":P\");'><img src='" . WEB . "/media/img/emoticons/tongue.png' alt=':´(' class='emoticons'> </a>";
                echo "<a href='#addcomments' onclick='formatText(\":*\");'><img src='" . WEB . "/media/img/emoticons/kiss.png' alt=':´(' class='emoticons'> </a>";
                echo "<a href='#addcomments' onclick='formatText(\":(\");'><img src='" . WEB . "/media/img/emoticons/frown.png' alt=':(' class='emoticons'> </a>";
                echo "<a href='#addcomments' onclick='formatText(\"8)\");'><img src='" . WEB . "/media/img/emoticons/glasses.png' alt=':´(' class='emoticons'> </a>";
                echo "<a href='#addcomments' onclick='formatText(\"(y)\");'><img src='" . WEB . "/media/img/emoticons/like.png' alt=':´(' class='emoticons'> </a>";
                echo "<a href='#addcomments' onclick='formatText(\"(n)\");'><img src='" . WEB . "/media/img/emoticons/dislike.png' alt=':´(' class='emoticons'></a>";
                echo "</ul> ";
                echo "<button type='button' class='btn btn-primary navbar-btn btn-sm' data-original-title='Bold' data-toggle='tooltip' data-placement='right' title='' onclick='formatText (\"[b]text[/b]\");'><span class='glyphicon glyphicon-bold'></span></button>";
                echo "<button type='button' class='btn btn-primary navbar-btn btn-sm' data-original-title='italic' data-toggle='tooltip' data-placement='right' title='' onclick='formatText (\"[i]text[/i]\");'><span class='glyphicon glyphicon-italic'></span></button>";
                echo "<button type='button' class='btn btn-primary navbar-btn btn-sm' data-original-title='Underline' data-toggle='tooltip' data-placement='right' title='' onclick='formatText (\"[u]text[/u]\");'><span class='glyphicon glyphicon-text-width'></span></button>";
                echo "<button type='button' class='btn btn-primary navbar-btn btn-sm' data-original-title='Link' data-toggle='tooltip' data-placement='right' title='' onclick='formatText (\"[url]Link[/url]\");'><i class='glyphicon glyphicon-globe'></i></button>";
                echo "<button type='button' class='btn btn-primary navbar-btn btn-sm' data-original-title='Code' data-toggle='tooltip' data-placement='right' title='' onclick='formatText (\"[code]kód[/code]\");'><i class='glyphicon glyphicon-link'></i></button>";
                echo "<button type='button' class='btn btn-primary navbar-btn btn-sm' data-original-title='Quote' data-toggle='tooltip' data-placement='right' title='' onclick='formatText (\"[quote]Otázka[/quote]\");'><i class='glyphicon glyphicon-question-sign'></i></button>";
                echo "<button type='button' class='btn btn-primary navbar-btn btn-sm' data-original-title='Image' data-toggle='tooltip' data-placement='right' title='' onclick='formatText (\"[img]Obrázok[/img]\");'><i class='glyphicon glyphicon-picture'></i></button>";
                echo "<button type='button' class='btn btn-primary navbar-btn btn-sm' data-original-title='Yotube video' data-toggle='tooltip' data-placement='right' title='' onclick='formatText (\"[youtube]Link[/youtube]\");'><i class='glyphicon glyphicon-film'></i></button>";

                echo "</div>";


                echo "</div>";
                echo "<div class='col-lg-6 text-right'>";
                echo "<input type='submit' class='btn btn-primary navbar-btn btn-sm' value='Odoslať'>";
                echo "</div>";
                echo "</form>";
                echo "</div>";

            } else if (isset($_GET["d"])) {
                $user = new User();
                if ($user->isLoggedIn()) {


                    $db = new Framework();

                    $ids = strip_tags($_GET["d"]);
                    $result = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "tagwall WHERE id=:ids ORDER BY id");
                    $result->bindParam(":ids", $ids);
                    $result->execute();

                    for ($i = 0; $row = $result->fetch(); $i++) {
                        if ($user->isInRole("admin") OR $row["autor"] == $user->me_id()) {
                            $id = strip_tags($_GET["d"]);

                            Result::Delete_Tagwall($id, $type, $get);
                            Result::Delete_Answer_Tagwall($id, $type, $get);

                            $bad_entities = array("&d=" . $id, "#addcomments");
                            $safe_entities = array("", "");
                            $url = Functions::form_action();
                            $matematics = str_replace($bad_entities, $safe_entities, $url);

                            Header::location($matematics);
                        }
                    }

                }
            } else if (isset($_GET["ud"])) {
                $user = new User();
                if ($user->isLoggedIn()) {
                    if ($user->isInRole("admin")) {

                        $db = new Framework();

                        $ids = strip_tags($_GET["ud"]);
                        $result = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "tagwall WHERE id=:ids ORDER BY id");
                        $result->bindParam(":ids", $ids);
                        $result->execute();

                        for ($i = 0; $row = $result->fetch(); $i++) {
                            if ($user->isInRole("admin") OR $row["autor"] == $user->me_id()) {
                                $id = strip_tags($_GET["ud"]);

                                Result::Delete_Tagwall($id, $type, $get);

                                $bad_entities = array("&ud=" . $id, "#addcomments");
                                $safe_entities = array("", "");
                                $url = Functions::form_action();
                                $matematics = str_replace($bad_entities, $safe_entities, $url);

                                Header::location($matematics);
                            }
                        }

                    }
                }
            } else {

                if (isset($_POST["massage"])) {
                    if (!empty($_POST["massage"])) {
                        if (stripslashes(strip_tags($_POST["massage"])) !== NULL) {
                            $db = new Framework();
                            $user = new User();

                            $massage = htmlspecialchars($_POST["massage"]);
                            $regex = "/[A-Za-z0-9]/";

                            if (preg_match($regex, $massage)) {
                                if (!empty($_POST["massage"])) {

                                    $massage = $_POST["massage"];
                                    $sessions = $user->me_id();
                                    $autor = $user->GetUserData($sessions, "id");

                                    $result = $db->pdo->prepare("INSERT INTO `" . DB_PREFIX . "tagwall` (`id`, `autor`, `massage`, `date`, `gets`, `answer`) VALUES (NULL, :autor, :massage, CURRENT_TIMESTAMP, :get, '0');");
                                    $result->bindParam(":massage", $massage);
                                    $result->bindParam(":get", $get);
                                    $result->bindParam(":autor", $autor);
                                    $result->execute();

                                    Header::location(Functions::form_action() . "#addcomments");
                                }
                            } else {
                                Bootstrap::Alert("Správa obsahuje nepovolené znaky !");
                            }
                        } else {
                            Bootstrap::Alert("Správa obsahuje nepovolené znaky !");
                        }
                    } else {
                        Bootstrap::Alert("Správa nemôže byť prázdna !");
                    }
                }


                echo "<div class='row' id='addcomments'>";
                echo "<form action='" . Functions::form_action() . "' method='post'>";
                echo "<div class='col-lg-12'>";
                echo "<textarea id='u_massage'  class='form-control' placeholder='správa...' style='width: 100%; height: 117px;resize: vertical;overflow: auto;' maxlength='2000000' name='massage'></textarea>";
                echo "</div>";
                echo "<div class='col-lg-6'>";

                //BTN GROUP
                echo "<div class='btn-group'>";
                echo "<button type='button' class='btn btn-primary navbar-btn btn-sm' data-toggle='dropdown'> ";
                echo "<img alt=':)' src='" . WEB . "/media/img/emoticons/smile.png' />";
                echo "</button> ";
                echo "<ul class='dropdown-menu'> ";
                echo "<a href='#addcomments' onclick='formatText(\":)\");'><img src='" . WEB . "/media/img/emoticons/smile.png' alt=':)' class='emoticons'> </a>";
                echo "<a href='#addcomments' onclick='formatText(\":D\");'><img src='" . WEB . "/media/img/emoticons/grin.png' alt=':D' class='emoticons'> </a>";
                echo "<a href='#addcomments' onclick='formatText(\":P\");'><img src='" . WEB . "/media/img/emoticons/tongue.png' alt=':´(' class='emoticons'> </a>";
                echo "<a href='#addcomments' onclick='formatText(\":*\");'><img src='" . WEB . "/media/img/emoticons/kiss.png' alt=':´(' class='emoticons'> </a>";
                echo "<a href='#addcomments' onclick='formatText(\":(\");'><img src='" . WEB . "/media/img/emoticons/frown.png' alt=':(' class='emoticons'> </a>";
                echo "<a href='#addcomments' onclick='formatText(\"8)\");'><img src='" . WEB . "/media/img/emoticons/glasses.png' alt=':´(' class='emoticons'> </a>";
                echo "<a href='#addcomments' onclick='formatText(\"(y)\");'><img src='" . WEB . "/media/img/emoticons/like.png' alt=':´(' class='emoticons'> </a>";
                echo "<a href='#addcomments' onclick='formatText(\"(n)\");'><img src='" . WEB . "/media/img/emoticons/dislike.png' alt=':´(' class='emoticons'></a>";
                echo "</ul> ";
                echo "<button type='button' class='btn btn-primary navbar-btn btn-sm' data-original-title='Bold' data-toggle='tooltip' data-placement='right' title='' onclick='formatText (\"[b]text[/b]\");'><span class='glyphicon glyphicon-bold'></span></button>";
                echo "<button type='button' class='btn btn-primary navbar-btn btn-sm' data-original-title='italic' data-toggle='tooltip' data-placement='right' title='' onclick='formatText (\"[i]text[/i]\");'><span class='glyphicon glyphicon-italic'></span></button>";
                echo "<button type='button' class='btn btn-primary navbar-btn btn-sm' data-original-title='Underline' data-toggle='tooltip' data-placement='right' title='' onclick='formatText (\"[u]text[/u]\");'><span class='glyphicon glyphicon-text-width'></span></button>";
                echo "<button type='button' class='btn btn-primary navbar-btn btn-sm' data-original-title='Link' data-toggle='tooltip' data-placement='right' title='' onclick='formatText (\"[url]Link[/url]\");'><i class='glyphicon glyphicon-globe'></i></button>";
                echo "<button type='button' class='btn btn-primary navbar-btn btn-sm' data-original-title='Code' data-toggle='tooltip' data-placement='right' title='' onclick='formatText (\"[code]kód[/code]\");'><i class='glyphicon glyphicon-link'></i></button>";
                echo "<button type='button' class='btn btn-primary navbar-btn btn-sm' data-original-title='Quote' data-toggle='tooltip' data-placement='right' title='' onclick='formatText (\"[quote]Otázka[/quote]\");'><i class='glyphicon glyphicon-question-sign'></i></button>";
                echo "<button type='button' class='btn btn-primary navbar-btn btn-sm' data-original-title='Image' data-toggle='tooltip' data-placement='right' title='' onclick='formatText (\"[img]Obrázok[/img]\");'><i class='glyphicon glyphicon-picture'></i></button>";
                echo "<button type='button' class='btn btn-primary navbar-btn btn-sm' data-original-title='Yotube video' data-toggle='tooltip' data-placement='right' title='' onclick='formatText (\"[youtube]Link[/youtube]\");'><i class='glyphicon glyphicon-film'></i></button>";
                echo "</div>";

                echo "</div>";
                echo "<div class='col-lg-6 text-right'>";
                echo "<input type='submit' class='btn btn-primary navbar-btn btn-sm' value='Odoslať'>";
                echo "</div>";
                echo "</form>";
                echo "</div>";

            }
        } else {
            Bootstrap::Alert("Pre pridanie príspevku do nástenky sa musíš prihlásiť !", "info");
        }
    }
}