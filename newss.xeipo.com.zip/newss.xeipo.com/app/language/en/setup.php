<?php

/**
**********************************************************
* Xeipo FREE VERSION CMS 
* @version FREE CMS BETA
* @author Jozef Vajdiar
* @copyright Copyright (C) 2015 - 2016 
**********************************************************
* Tento program je slobodný softvér: môžete ho šíriť a upravovať podľa ustanovení Všeobecnej verejnej 
* licencie GNU (GNU General Public Licence), vydávanej nadáciou Free Software Foundation a to podľa 3. verzie tejto Licencie
* Tento program je rozširovaný v nádeji, že bude užitočný, avšak BEZ AKEJKOĽVEK ZÁRUKY. 
* Neposkytujú sa ani odvodené záruky PREDAJNOSTI alebo VHODNOSTI PRE URČITÝ ÚČEL. 
* Ďalšie podrobnosti hľadajte vo Všeobecnej verejnej licencii GNU.
**********************************************************
* Kópiu Všeobecnej verejnej licencie GNU ste mali dostať spolu s týmto programom. (license.txt)
* Ak sa tak nestalo, nájdete ju tu: <http://www.gnu.org/licenses/>
* Tento system nájdete ZADARMO na webovej stránke www.xeipo.com
**********************************************************
**/

//Setup.php
$locale["setup_1"] = "setting chmod";
$locale["setup_2"] = "Set the database connection";
$locale["setup_3"] = "Hosting";
$locale["setup_4"] = "User";
$locale["setup_5"] = "Password";
$locale["setup_6"] = "database name";
$locale["setup_7"] = "All fields are required !";
$locale["setup_8"] = "We were unable to connect to database , please set these fields again.";
$locale["setup_9"] = "Everything was successful .";
$locale["setup_10"] = "Setting up your account";
$locale["setup_11"] = "Everything was successful";
$locale["setup_12"] = "Passwords do not match , please check this formr !";
$locale["setup_13"] = "All fields are required";
$locale["setup_14"] = "Fill nickname - nickname";
$locale["setup_15"] = "Fill in your new account email";
$locale["setup_16"] = "Set password";
$locale["setup_17"] = "Set the password again";
$locale["setup_18"] = "Licence";
$locale["setup_19"] = "Read the license terms";
$locale["setup_20"] = "If you accept the terms below , click on the arrow to the right direction !";
$locale["setup_21"] = "






<h4> Free License (AGPL) </h4> hotels xeipe is released under the terms of version 3 of the GNU Affero General Public License.
For further information visit <a href='http://www.gnu.org/licenses/agpl-3.0.html'> http://www.gnu.org/licenses/agpl-3.0.html or </a> Read the license.txt file that is included in the installation package.
You can change the code page as you like, the only condition is that you leave in your page footer copyright 'Powered by xeipe' as referred to in AGPL license.
Copyright is copyright of the person who created some work, in our case xeipe system. Team of authors is Joseph Vajdiar.
Copyright xeipe in the footer site is strictly forbidden to change or delete.
Deleting or overwriting the copyright of their sites infringing autora.Copyright in the footer site should look as follows (references must be official thus www.xeipo.com)
Powered by <a href='//xeipo.com' target='blank_'> xeipe </a> © Copyright 2015 - ".date("Y", time()).". Released as free software under the 
<a href='https://www.gnu.org/licenses/agpl-3.0.html' target='blank_'> GNU Affero GPL v3. </a> Hotels <br><br>
<h4> Remove copyright </h4> hotels
Copyright can legally remove, but only if you have written permission by e-mail about the payment of the amount demanded. Hotels
The fee is for each domain separately. Hotels
<strong> For more information contact us at r3w0lut10ns@gmail.com </strong>





";	
$locale["setup_22"] = "Successfully installed";	
$locale["setup_23"] = "Thank you for using our content management system";	
$locale["setup_24"] = "Potrebné akutalizácie nájdete na-nejde prelozit";	
$locale["setup_25"] = "Go to web";	
$locale["setup_26"] = "To your FTP server not found config.php file , please create it by clicking the button below !";	
$locale["setup_27"] = "Create file";	
$locale["setup_28"] = "create config.php";	
$locale["setup_29"] = "Go to the installation of";	

?>