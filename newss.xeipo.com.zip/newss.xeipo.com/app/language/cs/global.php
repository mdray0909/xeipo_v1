<?php

/**
 **********************************************************
 * Xeipo FREE VERSION CMS
 * @version FREE CMS BETA
 * @author Jozef Vajdiar
 * @copyright Copyright (C) 2015 - 2016
 **********************************************************
 * Tento program je slobodný softvér: môžete ho šíriť a upravovať podľa ustanovení Všeobecnej verejnej
 * licencie GNU (GNU General Public Licence), vydávanej nadáciou Free Software Foundation a to podľa 3. verzie tejto Licencie
 * Tento program je rozširovaný v nádeji, že bude užitočný, avšak BEZ AKEJKOĽVEK ZÁRUKY.
 * Neposkytujú sa ani odvodené záruky PREDAJNOSTI alebo VHODNOSTI PRE URČITÝ ÚČEL.
 * Ďalšie podrobnosti hľadajte vo Všeobecnej verejnej licencii GNU.
 **********************************************************
 * Kópiu Všeobecnej verejnej licencie GNU ste mali dostať spolu s týmto programom. (license.txt)
 * Ak sa tak nestalo, nájdete ju tu: <http://www.gnu.org/licenses/>
 * Tento system nájdete ZADARMO na webovej stránke www.xeipo.com
 **********************************************************
 **/

//Default language
$locale["global_0"] = "Český jazyk";
$locale["global_1"] = "Vyberte si jazyk který chcete mít při instalaci.";


?>