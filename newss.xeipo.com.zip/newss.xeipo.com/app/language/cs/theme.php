<?php

/**
**********************************************************
* Xeipo FREE VERSION CMS 
* @version FREE CMS BETA
* @author Jozef Vajdiar
* @copyright Copyright (C) 2015 - 2016 
**********************************************************
* Tento program je slobodný softvér: môžete ho šíriť a upravovať podľa ustanovení Všeobecnej verejnej 
* licencie GNU (GNU General Public Licence), vydávanej nadáciou Free Software Foundation a to podľa 3. verzie tejto Licencie
* Tento program je rozširovaný v nádeji, že bude užitočný, avšak BEZ AKEJKOĽVEK ZÁRUKY. 
* Neposkytujú sa ani odvodené záruky PREDAJNOSTI alebo VHODNOSTI PRE URČITÝ ÚČEL. 
* Ďalšie podrobnosti hľadajte vo Všeobecnej verejnej licencii GNU.
**********************************************************
* Kópiu Všeobecnej verejnej licencie GNU ste mali dostať spolu s týmto programom. (license.txt)
* Ak sa tak nestalo, nájdete ju tu: <http://www.gnu.org/licenses/>
* Tento system nájdete ZADARMO na webovej stránke www.xeipo.com
**********************************************************
**/

//HomePage
define("Locale_Theme_1", "Hlavní stránka");

//Articles
define("Locale_Theme_3", "Články");
define("Locale_Theme_6", "Žádné články se v naší databázi nenacházíme");
define("Locale_Theme_7", "více článků");
define("Locale_Theme_13", "Nový článek");
define("Locale_Theme_14", "Starší článek");
define("Locale_Theme_41", "Kategorie");

//Comments
define("Locale_Theme_10", "Komentáře");
define("Locale_Theme_43", "Pro přidání komentáře se musíš přihlásit !");
define("Locale_Theme_44", "Zpráva nemůže být prázdná !");
define("Locale_Theme_45", "Správa obsahuje nepovolené znaky !");
define("Locale_Theme_11", "Žádný komentář ještě nebyl přidán . Buďte první kdo přidá komentář.");
define("Locale_Theme_12", "Pro přidání komentáře se musíš přihlásit !");
define("Locale_Theme_46", "Odpovídám na komentář č");
define("Locale_Theme_47", "Správa...");

//User
define("Locale_Theme_15", "přihlašovací panel");
define("Locale_Theme_16", "Nick");
define("Locale_Theme_17", "Zadejte přezdívku");
define("Locale_Theme_18", "Heslo");
define("Locale_Theme_19", "Sem zadejte heslo");
define("Locale_Theme_20", "Přihlásit");
define("Locale_Theme_21", "Heslo nebylo zadáno správně !");
define("Locale_Theme_22", "Nevyplnili jste všechna pole !");
define("Locale_Theme_23", "Offline");
define("Locale_Theme_24", "Online");
define("Locale_Theme_25", "5 min");
define("Locale_Theme_8", "Autor");
define("Locale_Theme_9", "počet komentářů");
define("Locale_Theme_34", "administrace");
define("Locale_Theme_35", "Odhlásit se");
define("Locale_Theme_36", "Profil používateľa");

//Panely
define("Locale_Theme_48", "Nejnovější témata fóra");
define("Locale_Theme_49", "Nejčtenější témata fóra");










//Forum
define("Locale_Theme_2", "Fórum");
define("Locale_Theme_26", "Všechna témata fóra" );
define("Locale_Theme_27", "odpovědi");
define("Locale_Theme_28", "žádná témata ve fóru se v naší databázi nenacházejí.");
define("Locale_Theme_50", "Zpráva nemůže být prázdná a musí obsahovat 8 max 400 znaků !");
define("Locale_Theme_51", "Název tématu obsahuje nepovoelé znaky nebo nesplnuje počet znaků musí být v rozmezí od 3 - 40!");
define("Locale_Theme_52", "Přidat téma");
define("Locale_Theme_53", "odstranit téma");
define("Locale_Theme_54", "odpovědi");
define("Locale_Theme_55", "V této kategorii se nenachází žádná téma !");
define("Locale_Theme_56", "napísal/a");
define("Locale_Theme_57", "Odpovedať");
define("Locale_Theme_58", "Tato nástěnka je prázdná");
define("Locale_Theme_59", "Odoslať");
define("Locale_Theme_60", "Pro přidání příspěvku do nástěnky se musíš přihlásit !");
define("Locale_Theme_61", "stáhnout soubor");


//Downloads
define("Locale_Theme_4", "ke stažení");
define("Locale_Theme_29", "všechny soubory");
define("Locale_Theme_30", "Žádné downloady se v naší databázi nenacházíme !");

//Addons
define("Locale_Theme_31", "Tato databáze je prázdná !");

//Eshop
define("Locale_Theme_5", "na prodej");
define("Locale_Theme_32", "E-shop");
define("Locale_Theme_33", "Cena s DPH :");

//Administration
define("Locale_Theme_37", "Zpět na hlavní stránku");
define("Locale_Theme_38", "Záloha webu");
define("Locale_Theme_39", "hlavní nastavení");


//News
define("Locale_Theme_40", "Novinky");
define("Locale_Theme_42", "Žádné novinky se v naší databázi nenacházíme");

//Contact
define("Locale_Theme_62", "Po zpracování Vaší zprávy Vám budu odpovídat na Váš email , který jste zadali v kontaktním formuláři . Proto odpověď očekávejte ve své e - mailové schránce .
Nebudu Vás kontaktovat jinak než e - mailem . V případě bližšího kontaktu se můžeme dohodnout individuálně prostřednictvím e - mailové komunikácie.V případě že naleznete chybu v systému xeipo prosím kontaktujte nás na našem webu 
<a href='//xeipo.com/' target='blank_'>Xeipo.com</a> Ďakujeme.");

define("Locale_Theme_63", "Jméno a příjmení");
define("Locale_Theme_64", "Váš email");
define("Locale_Theme_65", "Nadpis vaší zprávy");
define("Locale_Theme_66", "Obsah zprávy");

//Edit profile
define("Locale_Theme_67", "Avatar");
define("Locale_Theme_68", "Nevybrali jste soubor, který chcete nahrát.");
define("Locale_Theme_69", "Soubor se nepodařilo nahrát, kontaktujte prosím správce serveru.");
define("Locale_Theme_70", "Koncovka souboru musí být jedna z:");
define("Locale_Theme_71", "Typ obrázku musí být JPG, PNG nebo GIF.");
define("Locale_Theme_72", "Nahraný soubor není obrázek !");
define("Locale_Theme_73", "Tvořené Chyba s databázov");
define("Locale_Theme_74", "Nebyl vybrán žádný soubor");
define("Locale_Theme_75", "Nahrát");
define("Locale_Theme_76", "hlavní nastavení");
define("Locale_Theme_77", "změnit heslo");
define("Locale_Theme_78", "soukromí");
define("Locale_Theme_79", "O mne");
define("Locale_Theme_80", "hlavní údaje");
define("Locale_Theme_81", "Tvořené Chyba s databázov");
define("Locale_Theme_82", "Nick musí obsahovať minimálne 3 - 30 znakov a môže obsahovať len a-zA-Z0-9");
define("Locale_Theme_83", "Email není validní");
define("Locale_Theme_84", "Nebyly odeslány všechny údaje !");
define("Locale_Theme_85", "přezdívka");
define("Locale_Theme_86", "Email");
define("Locale_Theme_87", "změnit");
define("Locale_Theme_88", "Změň si heslo vyplněním formuláře níže");
define("Locale_Theme_89", "Heslo uživatele bylo změněno !");
define("Locale_Theme_90", "Heslo musí obsahovat<br>1. Musí obsahovat alespoň jednu číslici <br> 2 . Musí obsahovat alespoň jedno velké písmeno 3 . Musí mít minimálně 8 - 40 znaků <br> 4 . Povolené znaky jsou pouze a - z A - Z 0-9 " ) ;
define("Locale_Theme_91", "Hesla se neshodují !");
define("Locale_Theme_92", "Nebyly odeslány všechny údaje!");
define("Locale_Theme_93", "Byly odeslány všechny údaje!");
define("Locale_Theme_94", "Zobrazit email veřejnosti");
define("Locale_Theme_95", "Text obsahuje nepovolené znaky");
define("Locale_Theme_96", "Text o mně musí mít od 100 - 1200 znaků a může obsahovat pouze a - zA - Z0-9");
define("Locale_Theme_97", "Uložit");
define("Locale_Theme_98", "Nastala chyba kontaktuj majitele přes kontaktní formulář.");
define("Locale_Theme_105", "upravit profil");
define("Locale_Theme_106", "Kontaktní informace");
define("Locale_Theme_107", "Uživatel si nepřeje aby byl email zveřejněn.");
define("Locale_Theme_108", "nástěnka");

//Footer
define("Locale_Theme_99", "O nás");
define("Locale_Theme_100", "Kontakt");
define("Locale_Theme_101", "vyhledávání");

//Login
define("Locale_Theme_102", "Vytvořit účet");
define("Locale_Theme_103", "Zadej nick nebo email");
define("Locale_Theme_104", "zapomenuté heslo");
define("Locale_Theme_109", "Registrace");
define("Locale_Theme_110", "Vytvoření nového uživatelského účtu");
define("Locale_Theme_111", "Musíte odeslat všechna pole !");
define("Locale_Theme_112", "Email znovu");
define("Locale_Theme_113", "Heslo znovu");
define("Locale_Theme_114", "Registrace je vypnutá !");

//Search
define("Locale_Theme_115", "Search...");
define("Locale_Theme_116", "vyhledat");
define("Locale_Theme_117", "uživatelé");
define("Locale_Theme_118", "Články");
define("Locale_Theme_119", "Fórum");
define("Locale_Theme_120", "Tento vyhledávač vyhledává uživatelů , témata z fóra a články.");
define("Locale_Theme_121", "Nic jsme nenašli");

?>