<?php

/**
 **********************************************************
 * Xeipo FREE VERSION CMS
 * @version FREE CMS BETA
 * @author Jozef Vajdiar
 * @copyright Copyright (C) 2015 - 2016
 **********************************************************
 * Tento program je slobodný softvér: môžete ho šíriť a upravovať podľa ustanovení Všeobecnej verejnej
 * licencie GNU (GNU General Public Licence), vydávanej nadáciou Free Software Foundation a to podľa 3. verzie tejto Licencie
 * Tento program je rozširovaný v nádeji, že bude užitočný, avšak BEZ AKEJKOĽVEK ZÁRUKY.
 * Neposkytujú sa ani odvodené záruky PREDAJNOSTI alebo VHODNOSTI PRE URČITÝ ÚČEL.
 * Ďalšie podrobnosti hľadajte vo Všeobecnej verejnej licencii GNU.
 **********************************************************
 * Kópiu Všeobecnej verejnej licencie GNU ste mali dostať spolu s týmto programom. (license.txt)
 * Ak sa tak nestalo, nájdete ju tu: <http://www.gnu.org/licenses/>
 * Tento system nájdete ZADARMO na webovej stránke www.xeipo.com
 **********************************************************
 **/

//Setup.php
$locale["setup_1"] = "nastavení chmod";
$locale["setup_2"] = "Nastavte spojení s databází";
$locale["setup_3"] = "Hosting";
$locale["setup_4"] = "Uživatel";
$locale["setup_5"] = "Heslo";
$locale["setup_6"] = "Název databáze";
$locale["setup_7"] = "Všechna pole jsou povinná !";
$locale["setup_8"] = "Nepodařilo se nám spojit s databází , prosím nastavte tato pole ještě jednou.";
$locale["setup_9"] = "Vše proběhlo úspěšně.";
$locale["setup_10"] = "Nastavení Vašeho účtu";
$locale["setup_11"] = "Vše proběhlo úspešne";
$locale["setup_12"] = "Hesla se neshodují prosím zkontrolujte tento formulář !";
$locale["setup_13"] = "Všechna pole jsou povinná";
$locale["setup_14"] = "Vyplnte nick - prezívku";
$locale["setup_15"] = "Vyplňte email Vašeho nového účtu";
$locale["setup_16"] = "Nastavte heslo";
$locale["setup_17"] = "Nastavte heslo ještě jednou";
$locale["setup_18"] = "Licence";
$locale["setup_19"] = "Přečtěte si licenční podmínky";
$locale["setup_20"] = "Ak souhlasíte s podmínkami uvedenými níže klikněte na šipku směrem do prava !";
$locale["setup_21"] = "<h4>Volná Licencia (AGPL) </h4> <br> Xeipo CMS je uvoľnené pod podmienkami verzie 3 GNU General Public License Affero.
Pre ďalšie informácie navštívte <a href='http://www.gnu.org/licenses/agpl-3.0.html'> http://www.gnu.org/licenses/agpl-3.0.html </a> alebo si prečítajte súbor license.txt, ktorý je súčasťou inštalačného balíčka.
Kód stránky môžete zmeniť ako len chcete, jedinou podmienkou je, ZE si necháte vo svojej footeri stránky copyright 'Běží Xeipo' ako je uvedené v licencii AGPL.
Copyright je autorské právo osoby ktorá vytvorila Určitě dielo, v našom prípade systém Xeipo. Tým autorom je Jozef Vajdiar.
Autorské Práva Xeipo vo footeri stránky, je prísne Zakázané zmeniť alebo vymazať.
Odstránením alebo prepísaním copyrightu zo svojej stránky, porušujete autorské právo autora.Copyright vo footeri stránky Má vyzerať nasledovne (Odkaz Musi odkazovať na oficiálnu stranku teda na www.xeipo.com):
Běží na <a href='//xeipo.com' target='blank_'> Xeipo </a> copyright © 2015 - " . date("Y", time()) . ". Vydáno jako svobodný software bez záruk za <a href='https://www.gnu.org/licenses/agpl-3.0.html' target='blank_'> GNU GPL v3 Affero</a>. 
<br><br>
<h4> Odstránenie copyrightu </h4> <br>
Copyright môžete legalne odstrániť len v prípade ak Máte písomné povolenie prostredníctvom e-mailu o zaplatení požadovanej čiastky. <br>
Poplatok je za každú doménu Samostatné. <br>
<strong> Pre viac informácií Nás Kontaktujte na r3w0lut10ns@gmail.com </strong>";
$locale["setup_22"] = "Instalace proběhla úspěšně";
$locale["setup_23"] = "Děkujeme za použití našeho redakčního systému.";
$locale["setup_24"] = "Potřebné akutalizácie najdete na";
$locale["setup_25"] = "Přejít na web";
$locale["setup_26"] = "Na Vašem FTP servery nenalezen soubor config.php prosím vytvořte jej kliknutím na tlačítko níže !";
$locale["setup_27"] = "Vytvořit tento soubor";
$locale["setup_28"] = "Vytvořte config.php";
$locale["setup_29"] = "Přejít na instalaci systému";

?>