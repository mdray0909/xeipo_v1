<?php

define('DS', DIRECTORY_SEPARATOR);
define('ROOT', dirname(dirname(dirname(__FILE__))));

include_once(ROOT . DS . 'loader.php');

$db = new Framework();

if (isset($_SESSION["id_objednavky"])) {
    $id_objednavky = $_SESSION["id_objednavky"];
} else {
    $id_objednavky = array();
}


$produkt = [];

foreach ($id_objednavky as $value) {
    if (isset($produkt[$value])) {
        $produkt[$value] += 1;
    } else {
        $produkt[$value] = 1;
    }
}


foreach ($produkt as $key => $value) {
    $result = $db->pdo->prepare("SELECT * FROM `" . DB_PREFIX . "product` WHERE id=:id");
    $result->bindParam(":id", $key);
    $result->execute();

    for ($i = 0; $row = $result->fetch(); $i++) {

        $pocet_ktory_chyba = $value - $row["count_product"];

        if ($row["disposable_product"] == 0) {
            if ($value > $row["count_product"]) {
                echo '<div class="alert alert-danger alert-dismissible fade in" role = "alert"> 
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden = "true" > ×</span>
                </button> 
                <p>Nedostatok produktov na sklade ! '.$pocet_ktory_chyba.' ks vám príde do 14dní !</p >
            </div >';
            }
        }



        if ($row["disposable_product"] == 1) {
            if ($value > 1) {
                echo '<div class="alert alert-danger alert-dismissible fade in" role = "alert"> 
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden = "true" > ×</span>
                </button> 
                <p>Košík obsahuje produkt, ktorý môže vlastniť iba jedna osoba, s kúpou sa ponáhlaj !</p >
            </div >';
            }
        }


    }
}


echo "<ul class='list-group'>";

echo "<li class='list-group-item'>";
echo "<div class='row'>";
echo "<div class='col-lg-7'>Názov produktu</div>";
echo "<div class='col-lg-4'>Počet ks</div>";
echo "</div>";
echo "</li>";


$celkova_cena = 0;
$celkova_s_dph_s_akciou_cena= 0;
$celkova_s_dph_bez_akcie_cena = 0;
$akciaa = 0;

foreach ($produkt as $key => $value) {

    $result = $db->pdo->prepare("SELECT * FROM `" . DB_PREFIX . "product` WHERE id=:id");
    $result->bindParam(":id", $key);
    $result->execute();

    for ($i = 0; $row = $result->fetch(); $i++) {


        if ($row["disposable_product"] == 0) {

            //Produkty ktoré maju množstvo



            if ($row["akcia"] !== NULL) {
                //Je Akcia
                $celkova_cena += ($value * $row["price"]);
                $celkova_s_dph_bez_akcie_cena += round($value * ($row["price"] * 1.20), 2);
                $celkova_s_dph_s_akciou_cena += round($value * ($row["price"] * 1.20) - $row["akcia"], 2);
                $akciaa += $row["akcia"];
            } else {
                //Nieje akcia
                $celkova_cena += ($value * $row["price"]);
                $celkova_s_dph_bez_akcie_cena += round($value * ($row["price"] * 1.20), 2);
                $celkova_s_dph_s_akciou_cena += round($value * ($row["price"] * 1.20), 2);
            }

            echo "<li class='list-group-item'>";
            echo "<div class='row'>";
            echo "<div class='col-lg-7'>";
            echo Functions::trim_link($row["name"], 10);
            echo "</div>";
            echo "<div class='col-lg-4'>";
            echo "<div class='badge'>" . $value . "</div>";
            echo "</div>";
            echo "</div>";
            echo "</li>";

        } else {
            //Produkty ktoré nemaju množstvo


            if ($row["akcia"] !== NULL) {
                //Je Akcia
                $celkova_cena += ($value * $row["price"]);
                $celkova_s_dph_bez_akcie_cena += round($value * ($row["price"] * 1.20), 2);
                $celkova_s_dph_s_akciou_cena += round($value * ($row["price"] * 1.20) - $row["akcia"], 2);
                $akciaa += round($value * ($row["price"] * 1.20) / $row["akcia"], 2);
            } else {
                //Nieje akcia
                $celkova_cena += ($value * $row["price"]);
                $celkova_s_dph_bez_akcie_cena += round($value * ($row["price"] * 1.20), 2);
                $celkova_s_dph_s_akciou_cena += round($value * ($row["price"] * 1.20), 2);
            }

            echo "<li class='list-group-item'>";
            echo "<div class='row'>";
            echo "<div class='col-lg-7'>";
            echo Functions::trim_link($row["name"], 10);
            echo "</div>";
            echo "<div class='col-lg-4'>";
            echo "<div class='badge'>" . $value . "</div>";
            echo "</div>";
            echo "</div>";
            echo "</li>";

        }
    }
}
echo "</ul>";


echo "<div class='row'>";
echo "<div class='col-lg-12'>Celkom bez DPH : " . $celkova_cena . ",- €</div>";
echo "<div class='col-lg-12'>Celkom s DPH bez Akcie: " . $celkova_s_dph_bez_akcie_cena . ",- €</div>";
echo "<div class='col-lg-12'>Celkom s DPH s Akciou: " . $celkova_s_dph_s_akciou_cena . ",- €</div>";





/*
if ($akciaa !== NULL) {
    echo "<div class='col-lg-12'>Ušetrili ste vdaka akcii: " . $akciaa . ",- €</div>";
}*/


echo "</div>";


?>