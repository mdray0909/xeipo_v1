<?php


Bootstrap::open_table("Nákupný košík");
echo "<div class='nakupnykosik'></div>";


echo "<div class='row'>";
echo "<div class='col-lg-6'>";
echo "<form action='' method='post'>";
echo "<input type='submit' name='zmazat_obj' class='btn btn-danger' value='zmazať objednávku'>";
echo "</form>";
echo "</div>";
echo "<div class='col-lg-6'>";
echo "<form action='' method='post'>";
echo "<input type='submit' name='zaplat_obj' class='btn btn-success' value='Zaplatiť'>";
echo "</form>";
echo "</div>";
echo "</div>";


if (isset($_POST["zmazat_obj"])) {
    unset($_SESSION["id_objednavky"]);
}


Bootstrap::close_table();


?>