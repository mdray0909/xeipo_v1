<?php


//Controller
$db = new Framework();
$user = new User();


$urls = new simpleurl();

if ($urls->segment(4) == "edit") {
    if ($urls->segment(5) !== NULL) {


        $id = $urls->segment(5);
        $result = $db->pdo->prepare("SELECT * FROM `" . DB_PREFIX . "product_category` WHERE id=:id");
        $result->bindParam(":id", $id);
        $result->execute();

        for ($i = 0; $row = $result->fetch(); $i++) {

            if (isset($_POST["submit"]) && !empty($_POST["names"])) {

                $name = $_POST["names"];

                if (!preg_match("/[^A-Za-z0-9 .?()]+$/", $name)) {

                    $name = trim(strip_tags($_POST["names"]));
                    $result = $db->pdo->prepare("
                    UPDATE `" . DB_PREFIX . "product_category` SET `name` =:name WHERE `id`=:id;");
                    $result->bindParam(":id", $id);
                    $result->bindParam(":name", $name);
                    $result->execute();

                    Bootstrap::Alert("kategória bola úspešne upravená.", "success");

                    Header::refresh(WEB . "/admin/app/shop", 2);
                } else {
                    Bootstrap::Alert("Názov kategórie obsahuje nepovolené znaky !", "warning");
                }

            } else {
                if (isset($_POST["submit"])) {
                    Bootstrap::Alert("Musíš vyplniť všetky polia !", "warning");
                }
            }

            echo "<form action='" . Functions::form_action() . "' method='post'>
                    <div class='col-lg-12 input-group'><br>
                        <input type='text' placeholder='názov kategórie' value='" . $row["name"] . "' name='names' class='form-control'>
                    </div>
                    <div class='col-lg-12 input-group'>
                        <input type='submit' value='Pridať kategóriu' name='submit' 
                        class='btn btn-primary navbar-btn btn-sm'>
                    </div>
                </form>
            </div>";
        }
    } else {
        Header::location(WEB . "admin/app/shop");
    }
} else if ($urls->segment(4) == "delete") {
    if ($urls->segment(5) !== NULL) {

        $id = $urls->segment(5);
        $result = $db->pdo->prepare("DELETE FROM `" . DB_PREFIX . "product_category` WHERE `id`=:id");
        $result->bindParam(":id", $id);
        $result->execute();

        //Bootstrap::Alert("kategória bola úspešne zmazaná.", "success");

        Header::location(WEB . "/admin/app/shop");

    } else {
        Header::location(WEB . "admin/app/shop");
    }
} else if ($urls->segment(4) == "pridatkategoriu") {


    echo "pridávame kategóriu";

    if (isset($_POST["submit"]) && !empty($_POST["names"])) {


        $name = $_POST["names"];

        if (!preg_match("/[^A-Za-z0-9 .?()]+$/", $name)) {

            $name = trim(strip_tags($_POST["names"]));
            $result = $db->pdo->prepare("INSERT INTO `" . DB_PREFIX . "product_category` 
          
            (`id`, `name`) VALUES (NULL, :name);");

            $result->bindParam(":name", $name);
            $result->execute();

            Bootstrap::Alert("kategória bola úspešne pridaná.", "success");

            Header::refresh(WEB . "/admin/app/shop", 2);
        } else {
            Bootstrap::Alert("Názov kategórie obsahuje nepovolené znaky !", "warning");
        }

    } else {
        if (isset($_POST["submit"])) {
            Bootstrap::Alert("Musíš vyplniť všetky polia !", "warning");
        }
    }

    echo "<form action='" . Functions::form_action() . "' method='post'>
            <div class='col-lg-12 input-group'><br>
                <input type='text' placeholder='názov kategórie' name='names' class='form-control'>
            </div>
            <div class='col-lg-12 input-group'>
                <input type='submit' value='Pridať kategóriu' name='submit' 
                class='btn btn-primary navbar-btn btn-sm'>
            </div>
        </form>
    </div>";


} else if ($urls->segment(4) == "upravitprodukt") {


    echo "upravujeme produkt !";


} else if ($urls->segment(4) == "zmazatprodukt") {
    if ($urls->segment(5) !== NULL) {

        $id = $urls->segment(5);
        $result = $db->pdo->prepare("DELETE FROM `" . DB_PREFIX . "product` WHERE id=:id");
        $result->bindParam(":id", $id);
        $result->execute();

        Bootstrap::Alert("Produkt bol úspešne zmazaný.");

        Header::location(WEB . "/admin/app/shop/#profile");
    } else {
        Header::location(WEB . "/admin/app/shop");
    }


} else if ($urls->segment(4) == "pridatprodukt") {


    if (isset($_POST["submit"]) && !empty($_POST["names"])
        && !empty($_POST["product-cat"])
        && !empty($_POST["product"])
        && !empty($_POST["product-count"])
        && !empty($_POST["product-price"])
    ) {


        $names = strip_tags($_POST["names"]);
        $product = strip_tags($_POST["product"]);
        $product_cat = strip_tags($_POST["product-cat"]);
        $product_count = strip_tags($_POST["product-count"]);
        $product_price = strip_tags($_POST["product-price"]);
        $user_id = $user->me_id();
        $namesers = trim(strip_tags($_POST["names"]));
        $name = $_POST["names"];
        $nulka = "01";
        $rrss = "1";

        if (!preg_match("/[^A-Za-z0-9 .?()]+$/", $names)) {


            $target_dir = ROOT . DS . "www" . DS . "media" . DS . "img" . DS . "eshop" . DS;
            $koncovka = basename($_FILES["image"]["type"]);
            $name = time() . "-" . mt_rand(0, 10);
            $name_file = $name . "-default." . $koncovka;
            $name_file2 = $name . "-small." . $koncovka;

            $check = @getimagesize($_FILES["image"]["tmp_name"]);
            if ($check !== false) {

                $koncovky = array('jpg', 'jpeg', 'png', 'gif');

                $chyba = "";
                if ($_FILES["image"]["error"] == UPLOAD_ERR_NO_FILE) {
                    Bootstrap::Alert("Nevybrali jste soubor, který chcete nahrát.", "warning");

                    $errrs = 1;
                } elseif ($_FILES["image"]["error"]) {
                    Bootstrap::Alert("Soubor se nepodařilo nahrát, kontaktujte prosím správce serveru.", "warning");

                    $errrs = 1;
                } elseif (!in_array(strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION)), $koncovky)) {
                    Bootstrap::Alert("Koncovka souboru musí být jedna z: " . implode(", ", $koncovky) . ".", "warning");

                    $errrs = 1;
                } elseif (!($imagesize = getimagesize($_FILES["image"]["tmp_name"])) || $imagesize[2] > 3) {
                    Bootstrap::Alert("Typ obrázku musí být JPG, PNG nebo GIF.", "warning");

                    $errrs = 1;
                } else {
                    $errrs = 0;

                    Bootstrap::Alert("Obrázok bol nahraný !", "success");

                    $image = basename($name_file2);
                    $original_image = basename($name_file);
                    $url_image = 0;

                    move_uploaded_file($_FILES['image']['tmp_name'], $target_dir . $name_file);
                    copy($target_dir . $name_file, $target_dir . $name_file2);

                    $img = Functions::Img_Resize($target_dir . $name_file2, 300, 300);
                }
            } else {
                $image = "img-default-small.jpg";
                $original_image = "img-default-small.jpg";
                $url_image = 0;
                $errrs = 0;
            }


            $result = $db->pdo->prepare("

                INSERT INTO `" . DB_PREFIX . "product` 
                (
                `id`, 
                `name`, 
                `category`, 
                `price`, 
                `picture`, 
                `image_on_web`, 
                `autor`, 
                `name_file`, 
                `count_download`,
                 `visible`, 
                 `text`, 
                 `buy`, 
                 `count_product`, 
                 `disposable_product`, 
                 `file_product`, 
                 `description`, 
                 `akcia`, 
                 `buy_user_id`
                 ) VALUES (
                  NULL, 
                  :names, 
                  :product_cat, 
                  :product_price, 
                  :product_picture, 
                  :count_down, 
                  :user_id, 
                  :product3,
                  :count_down,
                  :product, 
                  :count_down, 
                  :product_count, 
                  :count_down, 
                  :produkt2323,
                  :count_down,
                  :product2, 
                  :product_price2, 
                  :count_down);");


            $result->bindParam(":names", $namesers);
            $result->bindParam(":product_cat", $product_cat);
            $result->bindParam(":product_price", $product_price);
            $result->bindParam(":product_price2", $product_price);
            $result->bindParam(":product_picture", $original_image);
            $result->bindParam(":user_id", $user_id);
            $result->bindParam(":product", $product);
            $result->bindParam(":product3", $product);
            $result->bindParam(":product_count", $product_count);
            $result->bindParam(":product_cat", $product_cat);
            $result->bindParam(":product_cat", $product_cat);
            $result->bindParam(":product2", $product);
            $result->bindParam(":count_down", $nulka);
            $result->bindParam(":produkt2323", $rrss);
            $result->execute();

            Bootstrap::Alert("kategória bola úspešne pridaná.", "success");

            Header::refresh(WEB . "/admin/app/shop", 2);
        } else {
            Bootstrap::Alert("Názov kategórie obsahuje nepovolené znaky !", "warning");
        }

    } else {
        if (isset($_POST["submit"])) {
            Bootstrap::Alert("Musíš vyplniť všetky polia !", "warning");
        }
    }

    echo "<form action='" . Functions::form_action() . "' method='post' enctype='multipart/form-data'>
            <div class='col-lg-12 input-group'><br>
                <input type='text' placeholder='názov produktu' name='names' class='form-control' />
            </div>
            <div class='col-lg-12 input-group'><br>
                <select class='form-control' name='product-cat'>";

    $result = $db->pdo->prepare("SELECT * FROM `" . DB_PREFIX . "product_category`");
    $result->execute();

    for ($i = 0; $row = $result->fetch(); $i++) {
        echo "<option value='" . $row["id"] . "'>" . $row["name"] . "</option >";
    }

    echo "</select>
            </div>
            <div class='col-lg-12 input-group'><br>
                <textarea class='form-control' name='product' placeholder='Zadaj informácie o produkte'></textarea>
            </div>
            <div class='col-lg-12 input-group'><br>
                <input type='number' placeholder='počet kusov' name='product-count' class='form-control' />
            </div>
            <div class='col-lg-12 input-group'><br>
                <input type='number' placeholder='cena' name='product-price' class='form-control' />
            </div>
            <div class='col-lg-12 input-group'><br>
                <input type='file' name='image' class='form-control'/>
            </div>
            <div class='col-lg-12 input-group'>
                <input type='submit' value='Pridať produkt' name='submit' 
                class='btn btn-primary navbar-btn btn-sm'>
            </div>
            
        </form>
    </div>";


} else {

    ?>


    <div>

    <!-- Nav tabs -->
    <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active">
            <a href="#home" aria-controls="home" role="tab" data-toggle="tab">Kategórie</a>
        </li>
        <li role="presentation">
            <a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Produkty</a>
        </li>
    </ul>

    <!-- Tab panes -->
    <div class="tab-content">
    <div role="tabpanel" class="tab-pane active" id="home">


        <div class="row">
            <div class="col-lg-12">
                <div class="pull-right">
                    <a href="<?php echo WEB; ?>/admin/app/shop/pridatkategoriu" class="btn btn-default">
                        Pridať kategóriu
                    </a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <?


                $result = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "product_category ORDER BY id");
                $result->execute();

                if ($result->rowCount() > 0) {
                    echo "<div class='list-group'>";

                    for ($i = 0; $row = $result->fetch(); $i++) {


                        echo "
                        <div class='list-group-item'>
                        
                          
                            
                                
                                <a href='" . WEB . "/app/shop/cat/" . $row["id"] . "'>
                                " . $row["name"] . "
                                </a>
                            
                            
                            
                            <div class='pull-right'>
                            
                                <a href='" . WEB . "/admin/app/shop/delete/" . $row["id"] . "'>
                                Delete
                                </a>
                            
                                                        
                                <a href='" . WEB . "/admin/app/shop/edit/" . $row["id"] . "'>
                                Upraviť
                                </a>
                                
                            </div>
                            
                        </div>
                        ";
                    }

                    echo "</div>";
                } else {
                    Bootstrap::Alert2("žiadne kategórie nexistujú");
                }


                ?>
            </div>
        </div>
    </div>
    <div role="tabpanel" class="tab-pane" id="profile">


        <div class="row">
            <div class="col-lg-12">
                <div class="pull-right">
                    <a href="<?php echo WEB; ?>/admin/app/shop/pridatprodukt" class="btn btn-default">
                        Pridať Produkt
                    </a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <?


                $result = $db->pdo->prepare("SELECT 
                  ".DB_PREFIX."product.id,
                  ".DB_PREFIX."product.name,
                  ".DB_PREFIX."product.price,
                  ".DB_PREFIX."product.description,
                  ".DB_PREFIX."product_category.name as name2
                FROM 
                    ".DB_PREFIX."product 
                
                LEFT JOIN 
                
                    ".DB_PREFIX."product_category
                ON
                 
                 ".DB_PREFIX."product.category = ".DB_PREFIX."product_category.id
                 
                 ORDER BY id");
                $result->execute();

                if ($result->rowCount() > 0) {
                    echo "<div class='list-group'>";

                    for ($i = 0; $row = $result->fetch(); $i++) {


                        echo "<div class='list-group-item'>
                          <div class='row'>
                            
                                <div class='col-lg-4'>
                                    <a href='" . WEB . "/app/shop/cat/" . $row["id"] . "'>
                                    ".Functions::trim_link($row["name"], 100)."
                                    
                                    
                                    </a>
                                </div>
                                <div class='col-lg-2'>
                                
                                    ".Functions::trim_link($row["description"], 100)."
                                
                                
                                </div>
                                <div class='col-lg-2'>
                                
                                    ".$row["name2"]."
                                
                                
                                </div>          
                                
                                
                                <div class='pull-right'>
                            
                                    <a href='" . WEB . "/admin/app/shop/zmazatprodukt/" . $row["id"] . "'>
                                    Delete
                                    </a>
                                
                                                            
                                    <a href='" . WEB . "/admin/app/shop/upravitprodukt/" . $row["id"] . "'>
                                    Upraviť
                                    </a>
                                
                                </div>
                            
                           </div>
                        </div>";
                    }

                    echo "</div>";
                } else {
                    Bootstrap::Alert2("žiadne produkty nexistujú");
                }


                ?>
            </div>
        </div>


    </div>

    <?

}

?>