<?php


//Bootstrap::open_table("Eshop kategórie");

$db = new Framework();


$result = $db->pdo->prepare("SELECT * FROM " . DB_PREFIX . "product_category ORDER BY name");
$result->execute();


if ($result->rowCount() > 0) {
    echo "<div class='list-group'>";

    for ($i = 0; $row = $result->fetch(); $i++) {
        echo "<a href='" . WEB . "/app/shop/cat/" . $row["id"] . "' class='list-group-item'>" . $row["name"] . "</a>";
    }

    echo "</div>";
} else {
    Bootstrap::alert2("žiadne kategórie nexistujú");
}


//Bootstrap::close_table();


?>