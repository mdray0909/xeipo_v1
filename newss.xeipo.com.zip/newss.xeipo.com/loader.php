<?php

/**
#	Autoload function
*/
function autoload($class)
{
    $controllers_path = ROOT.DS.'app'.DS.'controllers'.DS.strtolower($class).'.class.php';
    $models_path = ROOT.DS.'app'.DS.'models'.DS.strtolower($class).'.class.php';

    if(file_exists($controllers_path)){
        require_once ($controllers_path);
    }elseif(file_exists($models_path)){
        require_once ($models_path);
    }else{
        $massage = "No loading Controllers or Models name ".strtolower($class).".class.php";
        die($massage);
    }
}

spl_autoload_register("autoload");

/*
#	Config
*/
if(file_exists(ROOT.DS.'config'.DS.'config.php')){
	include_once(ROOT.'/config/config.php');
}

/*
 * Session loading
 */
Framework::session();

/*
#	WebLink
*/
Framework::web_link_define();

/*
#	Framework
*/
new Framework();

/*
#	Developer mod
*/
if(DEVELOPER_MOD == 1){
	error_reporting(E_ALL);
	ini_set("display_errors", 1);
}else{
	error_reporting(E_ALL);
	ini_set("display_errors", 1);
}

/*
#	Loading lang
*/
Language::lang_load();


?>